"""
============================================================
hitung.py -- Semua aturan pembukuan, dalam bahasa Python
============================================================
File ini tidak berisi tampilan (HTML). Isinya hanya hitungan:
stok, jurnal, HPP rata-rata, dan laporan.

Kalau kamu membandingkan dengan versi PHP, isinya sama persis.
Bedanya hanya bahasa pemrogramannya.
"""

import hashlib
import re
import secrets
import sqlite3
from datetime import datetime

# Nama file database. Satu file, isinya semua tabel.
NAMA_DATABASE = "sikoi.db"


# ------------------------------------------------------------
# 1. Menyambung ke database
# ------------------------------------------------------------
def sambung():
    """Membuka koneksi ke SQLite dan mengembalikannya."""
    # row_factory membuat hasil query bisa diakses seperti kamus:
    # baris["nama"], bukan baris[1]
    koneksi = sqlite3.connect(NAMA_DATABASE)
    koneksi.row_factory = sqlite3.Row
    return koneksi


def ambil_semua(sql, parameter=()):
    """Mengambil banyak baris. Hasilnya list."""
    koneksi = sambung()
    try:
        return koneksi.execute(sql, parameter).fetchall()
    finally:
        koneksi.close()          # selalu tutup, walaupun terjadi error


def ambil_satu(sql, parameter=()):
    """Mengambil satu baris. Hasilnya sqlite3.Row atau None."""
    koneksi = sambung()
    try:
        return koneksi.execute(sql, parameter).fetchone()
    finally:
        koneksi.close()


def jalankan(sql, parameter=()):
    """Menjalankan INSERT / UPDATE / DELETE. Mengembalikan id baris baru."""
    koneksi = sambung()
    try:
        kursor = koneksi.execute(sql, parameter)
        koneksi.commit()         # simpan perubahan secara permanen
        return kursor.lastrowid
    finally:
        koneksi.close()


# ------------------------------------------------------------
# 2. Pengguna, login, dan jejak audit
# ------------------------------------------------------------
def sekarang():
    """Waktu sekarang dalam bentuk teks ISO, misalnya 2026-11-11T10:30:00."""
    return datetime.now().isoformat(timespec="seconds")


def hash_pin(pin, salt):
    """
    PIN tidak disimpan sebagai teks biasa.

    Yang disimpan: SHA-256 dari (garam + PIN). Garam berbeda untuk tiap
    pengguna, jadi dua orang dengan PIN sama tetap punya hash berbeda.
    """
    return hashlib.sha256((salt + str(pin)).encode("utf-8")).hexdigest()


def cek_login(nama, jabatan, pin):
    """Mengembalikan baris pengguna kalau nama, jabatan, dan PIN cocok."""
    baris = ambil_satu(
        "SELECT * FROM pengguna WHERE nama = ? AND jabatan = ?",
        (nama, jabatan))
    if not baris:
        return None

    salt = baris["salt"] if "salt" in baris.keys() else ""
    if salt:
        if hash_pin(pin, salt) == baris["pin"]:
            return baris
        return None

    # Database lama: PIN masih teks biasa.
    if str(pin) == baris["pin"]:
        return baris
    return None


def catat_login(pengguna_id, nama, jabatan):
    """Mencatat setiap login yang berhasil (rancangan bagian 2.B.1)."""
    jalankan(
        "INSERT INTO login_log (pengguna_id, nama, jabatan, waktu) "
        "VALUES (?, ?, ?, ?)",
        (pengguna_id, nama, jabatan, sekarang()))


def catat_audit(tabel, aksi, record_id=None, keterangan="", pengguna="",
                nilai_lama="", nilai_baru=""):
    """Mencatat tambah/ubah/hapus ke audit_trail."""
    jalankan(
        """INSERT INTO audit_trail
           (waktu, pengguna, tabel, aksi, record_id, keterangan,
            nilai_lama, nilai_baru)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (sekarang(), pengguna, tabel, aksi, record_id, keterangan,
         str(nilai_lama), str(nilai_baru)))


def daftar_pengguna():
    return ambil_semua(
        "SELECT id, nama, jabatan, aktif FROM pengguna ORDER BY id")


def tambah_pengguna(nama, jabatan, pin):
    salt = secrets.token_hex(8)
    return jalankan(
        "INSERT INTO pengguna (nama, jabatan, pin, salt, aktif) "
        "VALUES (?, ?, ?, ?, 1)",
        (nama, jabatan, hash_pin(pin, salt), salt))


def ubah_pengguna(pengguna_id, nama, jabatan, pin=None):
    """Mengubah data pengguna. PIN hanya diganti kalau diisi."""
    if pin:
        salt = secrets.token_hex(8)
        jalankan(
            "UPDATE pengguna SET nama = ?, jabatan = ?, pin = ?, salt = ? "
            "WHERE id = ?",
            (nama, jabatan, hash_pin(pin, salt), salt, pengguna_id))
    else:
        jalankan(
            "UPDATE pengguna SET nama = ?, jabatan = ? WHERE id = ?",
            (nama, jabatan, pengguna_id))


def hapus_pengguna(pengguna_id):
    jalankan("DELETE FROM pengguna WHERE id = ?", (pengguna_id,))


# ------------------------------------------------------------
# 2a. Menyesuaikan database lama dengan kolom baru
# ------------------------------------------------------------
def pastikan_skema():
    """
    Menambah kolom baru kalau database lama belum memilikinya.

    Tujuannya supaya aplikasi versi baru tetap bisa membuka sikoi.db
    lama tanpa harus membuat ulang database. Untuk database yang baru
    dibuat lewat buat_database.py, fungsi ini tidak mengubah apa pun.
    """
    koneksi = sambung()
    try:
        kolom_barang = {b["name"] for b in koneksi.execute("PRAGMA table_info(barang)")}

        # ukuran_cm: dipakai untuk mencocokkan ukuran ikan yang diketik
        # pengguna ("20") dengan barang yang tersimpan.
        if "ukuran_cm" not in kolom_barang:
            koneksi.execute(
                "ALTER TABLE barang ADD COLUMN ukuran_cm INTEGER NOT NULL DEFAULT 0")
            for barang in koneksi.execute("SELECT id, nama FROM barang").fetchall():
                cocok = re.search(r"(\d+)\s*cm", barang["nama"], re.IGNORECASE)
                if cocok:
                    koneksi.execute(
                        "UPDATE barang SET ukuran_cm = ? WHERE id = ?",
                        (int(cocok.group(1)), barang["id"]))

        # hpp_awal: HPP sebelum pembelian pertama. Dibutuhkan saat
        # pembelian dibatalkan, agar HPP rata-rata bisa dihitung ulang.
        if "hpp_awal" not in kolom_barang:
            koneksi.execute(
                "ALTER TABLE barang ADD COLUMN hpp_awal INTEGER NOT NULL DEFAULT 0")
            koneksi.execute("UPDATE barang SET hpp_awal = hpp")

        kolom_opname = {b["name"] for b in koneksi.execute("PRAGMA table_info(opname)")}
        if "no_bukti" not in kolom_opname:
            koneksi.execute(
                "ALTER TABLE opname ADD COLUMN no_bukti TEXT NOT NULL DEFAULT ''")

        # ----------------------------------------------------
        # Kolom baru untuk jejak audit (rancangan bagian 2.B)
        # ----------------------------------------------------
        _tambah_kolom(koneksi, "pengguna", "salt", "TEXT NOT NULL DEFAULT ''")
        _tambah_kolom(koneksi, "pengguna", "aktif", "INTEGER NOT NULL DEFAULT 1")
        _tambah_kolom(koneksi, "barang", "kolam_id", "INTEGER")
        _tambah_kolom(koneksi, "transaksi", "berat_paket", "REAL NOT NULL DEFAULT 0")
        _tambah_kolom(koneksi, "transaksi", "dibuat_pada", "TEXT")
        _tambah_kolom(koneksi, "transaksi", "diubah_oleh", "TEXT")
        _tambah_kolom(koneksi, "transaksi", "diubah_pada", "TEXT")
        _tambah_kolom(koneksi, "opname", "dibuat_oleh", "TEXT")
        _tambah_kolom(koneksi, "opname", "dibuat_pada", "TEXT")
        _tambah_kolom(koneksi, "jurnal", "dibuat_pada", "TEXT")

        # ----------------------------------------------------
        # Tabel baru (aman dijalankan berulang)
        # ----------------------------------------------------
        koneksi.executescript("""
CREATE TABLE IF NOT EXISTS login_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    pengguna_id INTEGER,
    nama        TEXT NOT NULL,
    jabatan     TEXT NOT NULL,
    waktu       TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_trail (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    waktu      TEXT NOT NULL,
    pengguna   TEXT NOT NULL,
    tabel      TEXT NOT NULL,
    aksi       TEXT NOT NULL,
    record_id  INTEGER,
    keterangan TEXT,
    nilai_lama TEXT,
    nilai_baru TEXT
);

CREATE TABLE IF NOT EXISTS anggota (
    id     INTEGER PRIMARY KEY AUTOINCREMENT,
    kode   TEXT NOT NULL,
    nama   TEXT NOT NULL,
    kontak TEXT NOT NULL DEFAULT '',
    aktif  INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS kolam (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    kode       TEXT NOT NULL,
    ukuran     TEXT NOT NULL,
    anggota_id INTEGER,
    jenis_ikan TEXT NOT NULL DEFAULT 'Kohaku',
    aktif      INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS kebijakan (
    kunci      TEXT PRIMARY KEY,
    nilai      TEXT NOT NULL,
    keterangan TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS ongkir_zona (
    zona       TEXT PRIMARY KEY,
    tarif      INTEGER NOT NULL,
    keterangan TEXT NOT NULL DEFAULT ''
);
""")

        _isi_awal_skema(koneksi)
        _hash_pin_lama(koneksi)
        _perbarui_master_revisi2(koneksi)

        koneksi.commit()
    finally:
        koneksi.close()


def _tambah_kolom(koneksi, tabel, nama_kolom, definisi):
    """ALTER TABLE ... ADD COLUMN hanya kalau kolomnya belum ada."""
    kolom = {b["name"] for b in koneksi.execute(f"PRAGMA table_info({tabel})")}
    if nama_kolom not in kolom:
        koneksi.execute(f"ALTER TABLE {tabel} ADD COLUMN {nama_kolom} {definisi}")


def _isi_awal_skema(koneksi):
    """
    Mengisi tabel master hanya kalau masih kosong.

    Database baru sudah diisi buat_database.py, jadi fungsi ini tidak
    menggandakan data. Untuk database lama, tabelnya baru dibuat dan
    perlu isi awal.
    """
    if koneksi.execute("SELECT COUNT(*) FROM anggota").fetchone()[0] == 0:
        koneksi.executemany(
            "INSERT INTO anggota (kode, nama, kontak) VALUES (?, ?, ?)",
            [(f"A-{i:02d}", f"Anggota {i}", "") for i in range(1, 23)])

    if koneksi.execute("SELECT COUNT(*) FROM kolam").fetchone()[0] == 0:
        koneksi.executemany(
            "INSERT INTO kolam (kode, ukuran, anggota_id, jenis_ikan) "
            "VALUES (?, ?, ?, ?)",
            [("K-01", "6x8 m", 1, "Kohaku"),
             ("K-02", "6x8 m", 2, "Kohaku"),
             ("K-03", "6x8 m", 3, "Kohaku")])

    if koneksi.execute("SELECT COUNT(*) FROM kebijakan").fetchone()[0] == 0:
        koneksi.executemany(
            "INSERT INTO kebijakan (kunci, nilai, keterangan) VALUES (?, ?, ?)",
            [("metode_persediaan", "perpetual_rata_rata",
              "Perpetual, rata-rata bergerak"),
             ("pembayaran", "tunai", "Tunai (kas/transfer bank); kredit nonaktif"),
             ("denda_termin", "0", "Denda dan termin tidak berlaku"),
             ("tarif_retribusi", "125000",
              "Per kolam per bulan, jatuh tempo tanggal 10"),
             ("umur_ekonomis_bulan", "36", "Penyusutan garis lurus 3 tahun"),
             ("batas_kapitalisasi", "500000", "Di atas nilai ini menjadi aset"),
             ("pemakaian_pakan_bulanan_kg", "60",
              "Perkiraan pemakaian pakan per bulan"),
             ("momen_jual_tanggal", "2027-01-01,2027-03-20",
              "Tahun Baru dan Lebaran")])

    if koneksi.execute("SELECT COUNT(*) FROM ongkir_zona").fetchone()[0] == 0:
        koneksi.executemany(
            "INSERT INTO ongkir_zona (zona, tarif, keterangan) VALUES (?, ?, ?)",
            [("dekat", 5000, "Dalam kota, berat 1-3 kg"),
             ("sedang", 10000, "Zona sedang, berat 1-3 kg"),
             ("jauh", 15000, "Luar kota, berat 1-3 kg")])


def _perbarui_master_revisi2(koneksi):
    """
    Menyelaraskan nama barang dengan daftar baku revisi 2.

    Database lama menyimpan "Koi Kohiku" dan kode "KOI-10". Revisi 2
    memakai "Koi Kohaku" dan kode "KOI10" (tanpa tanda hubung), serta
    nama pakan "Pakan koi protein 18-20%". Fungsi ini aman dijalankan
    berulang karena hanya mengubah baris yang masih memakai bentuk lama.
    """
    koneksi.execute(
        "UPDATE barang SET nama = REPLACE(nama, 'Kohiku', 'Kohaku') "
        "WHERE nama LIKE '%Kohiku%'")

    for lama, baru in [("KOI-10", "KOI10"), ("KOI-15", "KOI15"),
                       ("KOI-20", "KOI20"), ("KOI-30", "KOI30"),
                       ("PKN-01", "PKN01")]:
        sudah_ada = koneksi.execute(
            "SELECT id FROM barang WHERE kode = ?", (baru,)).fetchone()
        if sudah_ada is None:
            koneksi.execute(
                "UPDATE barang SET kode = ? WHERE kode = ?", (baru, lama))

    koneksi.execute(
        "UPDATE barang SET nama = 'Pakan koi protein 18-20%' "
        "WHERE nama IN ('Pakan koi/nila', 'Pakan koi protein 18-20%')")


def _hash_pin_lama(koneksi):
    """
    Mengubah PIN teks biasa dari database lama menjadi hash + garam.

    Dipanggil sekali saat aplikasi pertama kali membuka database lama.
    Setelah itu kolom salt terisi, jadi tidak diproses lagi.
    """
    baris = koneksi.execute(
        "SELECT id, pin FROM pengguna WHERE salt = '' OR salt IS NULL").fetchall()
    for pengguna in baris:
        pin = str(pengguna["pin"])
        # Hash SHA-256 panjangnya 64 karakter hex. Kalau panjangnya
        # sudah 64, kemungkinan besar itu hash dari versi lain.
        if len(pin) == 64 and all(c in "0123456789abcdef" for c in pin.lower()):
            continue
        salt = secrets.token_hex(8)
        koneksi.execute(
            "UPDATE pengguna SET pin = ?, salt = ? WHERE id = ?",
            (hash_pin(pin, salt), salt, pengguna["id"]))


# ------------------------------------------------------------
# 2. Mencari id akun dari nomor akun
# ------------------------------------------------------------
def id_akun(no_akun):
    akun = ambil_satu("SELECT id FROM akun WHERE no_akun = ?", (no_akun,))
    if akun is None:
        raise ValueError(f"Akun {no_akun} tidak ditemukan. Jalankan buat_database.py dulu.")
    return akun["id"]


# ------------------------------------------------------------
# 3. Stok sekarang (dihitung, bukan disimpan)
# ------------------------------------------------------------
def stok_sekarang(barang_id):
    """
    Rumus: stok awal + masuk - keluar - hilang.
    Dihitung ulang dari transaksi supaya tidak pernah "bohong".
    """
    barang = ambil_satu("SELECT * FROM barang WHERE id = ?", (barang_id,))
    if barang is None:
        return 0

    masuk = ambil_satu(
        """SELECT COALESCE(SUM(tb.qty), 0) AS jumlah
           FROM transaksi_baris tb
           JOIN transaksi t ON t.id = tb.transaksi_id
           WHERE tb.barang_id = ? AND t.jenis = 'pembelian'""",
        (barang_id,),
    )["jumlah"]

    keluar = ambil_satu(
        """SELECT COALESCE(SUM(tb.qty), 0) AS jumlah
           FROM transaksi_baris tb
           JOIN transaksi t ON t.id = tb.transaksi_id
           WHERE tb.barang_id = ? AND t.jenis = 'penjualan'""",
        (barang_id,),
    )["jumlah"]

    hilang = ambil_satu(
        "SELECT COALESCE(SUM(qty_hilang), 0) AS jumlah FROM opname WHERE barang_id = ?",
        (barang_id,),
    )["jumlah"]

    return barang["stok_awal"] + masuk - keluar - hilang


# ------------------------------------------------------------
# 4. Menyimpan satu baris jurnal
# ------------------------------------------------------------
def simpan_jurnal(tanggal, no_bukti, akun_id, debit, kredit, keterangan):
    """Setiap transaksi memanggil ini 2 kali atau lebih: debit dan kredit."""
    jalankan(
        """INSERT INTO jurnal
           (tanggal, no_bukti, akun_id, debit, kredit, keterangan, dibuat_pada)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (tanggal, no_bukti, akun_id, debit, kredit, keterangan, sekarang()),
    )


# ------------------------------------------------------------
# 5. Nomor bukti otomatis: PJ-001, PJ-002, ...
# ------------------------------------------------------------
def _nomor_terbesar(daftar_no, awalan):
    """
    Mencari nomor urut terbesar dari daftar nomor bukti.

    Dulu aplikasi memakai COUNT(*), sehingga setelah sebuah transaksi
    dihapus nomor berikutnya bisa sama dengan nomor yang masih ada.
    Dengan mengambil nomor terbesar, nomor bukti tidak pernah bertabrakan.
    """
    terbesar = 0
    for no in daftar_no:
        ekor = str(no).rsplit("-", 1)[-1]
        if ekor.isdigit():
            terbesar = max(terbesar, int(ekor))
    return f"{awalan}-{terbesar + 1:03d}"


def nomor_bukti(jenis):
    awalan = {
        "pembelian": "PB",
        "penjualan": "PJ",
        "penerimaan_kas": "PK",
        "pengeluaran_kas": "KK",
    }
    kode = awalan[jenis]

    semua = ambil_semua(
        "SELECT no_bukti FROM transaksi WHERE no_bukti LIKE ?", (kode + "-%",)
    )
    return _nomor_terbesar([b["no_bukti"] for b in semua], kode)


def nomor_ajp():
    """
    Nomor jurnal penyesuaian: AJP-001, AJP-002, ...

    Hanya nomor berbentuk AJP-<angka> yang dihitung. Nomor bulanan seperti
    AJP-PKN-2026-10 tidak ikut, supaya urutannya tidak melompat.
    """
    semua = ambil_semua(
        "SELECT no_bukti FROM jurnal WHERE no_bukti LIKE 'AJP-%'")
    daftar = [j["no_bukti"] for j in semua
              if re.fullmatch(r"AJP-\d+", j["no_bukti"])]
    return _nomor_terbesar(daftar, "AJP")


def nomor_jurnal_umum():
    """Nomor jurnal umum: JU-001, JU-002, ..."""
    semua = ambil_semua(
        "SELECT DISTINCT no_bukti FROM jurnal WHERE no_bukti LIKE 'JU-%'")
    return _nomor_terbesar([j["no_bukti"] for j in semua], "JU")


def simpan_jurnal_umum(tanggal, keterangan, baris, oleh):
    """
    Menyimpan jurnal umum (non-kas) atau koreksi.

    baris = [{"akun_id": 1, "debit": 1000, "kredit": 0}, ...]

    Aturan (rancangan bagian 5.5):
    a. minimal dua baris;
    b. setiap baris hanya boleh berisi debit atau kredit;
    c. total debit harus sama dengan total kredit.
    """
    if len(baris) < 2:
        raise ValueError("Jurnal umum minimal terdiri dari dua baris.")

    total_debit = 0
    total_kredit = 0
    for isi in baris:
        debit = int(isi.get("debit") or 0)
        kredit = int(isi.get("kredit") or 0)
        if debit < 0 or kredit < 0:
            raise ValueError("Debit dan kredit tidak boleh negatif.")
        if (debit > 0) == (kredit > 0):
            raise ValueError(
                "Setiap baris harus berisi debit saja atau kredit saja.")
        total_debit += debit
        total_kredit += kredit

    if total_debit == 0:
        raise ValueError("Jurnal umum tidak boleh bernilai nol.")
    if total_debit != total_kredit:
        raise ValueError(
            f"Jurnal tidak seimbang: debit {total_debit:,} "
            f"kredit {total_kredit:,}.")

    no_bukti = nomor_jurnal_umum()
    for isi in baris:
        simpan_jurnal(tanggal, no_bukti, isi["akun_id"],
                      int(isi.get("debit") or 0), int(isi.get("kredit") or 0),
                      keterangan)

    catat_audit("jurnal", "tambah", None,
                f"{no_bukti}: {keterangan}", oleh,
                nilai_baru=f"debit=kredit={total_debit}")
    return no_bukti


# ------------------------------------------------------------
# 5a. Kas kecil (dana tetap)
# ------------------------------------------------------------
def saldo_kas_kecil():
    """Saldo Kas Kecil (akun 1103): total debit dikurangi total kredit."""
    baris = ambil_satu(
        "SELECT COALESCE(SUM(debit), 0) - COALESCE(SUM(kredit), 0) AS saldo "
        "FROM jurnal WHERE akun_id = ?", (id_akun("1103"),))
    return int(baris["saldo"] if baris else 0)


def _nomor_kas_kecil():
    semua = ambil_semua(
        "SELECT DISTINCT no_bukti FROM jurnal "
        "WHERE no_bukti LIKE 'KKS-%' OR no_bukti LIKE 'KD-%'")
    daftar = [j["no_bukti"] for j in semua if j["no_bukti"].startswith("KKS-")]
    return _nomor_terbesar(daftar, "KKS")


def _nomor_dana_kas_kecil():
    semua = ambil_semua(
        "SELECT DISTINCT no_bukti FROM jurnal WHERE no_bukti LIKE 'KD-%'")
    return _nomor_terbesar([j["no_bukti"] for j in semua], "KD")


def isi_kas_kecil(tanggal, jumlah, akun_sumber_id, keterangan, oleh):
    """
    Mengisi dana kas kecil: Debit Kas Kecil, Kredit Kas/Bank.
    Nomor bukti: KD-001, KD-002, ...
    """
    jumlah = int(jumlah)
    if jumlah <= 0:
        raise ValueError("Jumlah pengisian harus lebih dari nol.")

    no_bukti = _nomor_dana_kas_kecil()
    simpan_jurnal(tanggal, no_bukti, id_akun("1103"), jumlah, 0,
                  keterangan or "Pengisian kas kecil")
    simpan_jurnal(tanggal, no_bukti, akun_sumber_id, 0, jumlah,
                  keterangan or "Pengisian kas kecil")
    catat_audit("kas_kecil", "tambah", None, f"{no_bukti} isi {jumlah}",
                oleh, nilai_baru=str(jumlah))
    return no_bukti


def belanja_kas_kecil(tanggal, akun_beban_id, jumlah, keterangan, oleh):
    """
    Belanja kecil: Debit akun beban, Kredit Kas Kecil.
    Nomor bukti: KKS-001, KKS-002, ...
    """
    jumlah = int(jumlah)
    if jumlah <= 0:
        raise ValueError("Jumlah belanja harus lebih dari nol.")
    if jumlah > saldo_kas_kecil():
        raise ValueError("Saldo kas kecil tidak mencukupi.")

    no_bukti = _nomor_kas_kecil()
    simpan_jurnal(tanggal, no_bukti, akun_beban_id, jumlah, 0, keterangan)
    simpan_jurnal(tanggal, no_bukti, id_akun("1103"), 0, jumlah, keterangan)
    catat_audit("kas_kecil", "tambah", None, f"{no_bukti} belanja {jumlah}",
                oleh, nilai_baru=str(jumlah))
    return no_bukti


def riwayat_kas_kecil():
    """Daftar mutasi kas kecil, satu baris per nomor bukti."""
    return ambil_semua(
        """SELECT j.no_bukti, MIN(j.tanggal) AS tanggal,
                  SUM(j.debit) AS debit, SUM(j.kredit) AS kredit,
                  MIN(j.keterangan) AS keterangan
             FROM jurnal j
            WHERE j.akun_id = ?
            GROUP BY j.no_bukti
            ORDER BY MIN(j.tanggal) DESC, j.no_bukti DESC""",
        (id_akun("1103"),))


def hapus_kas_kecil(no_bukti, oleh=""):
    """Menghapus satu transaksi kas kecil beserta kedua jurnalnya."""
    baris = ambil_satu(
        "SELECT COUNT(*) AS jumlah FROM jurnal WHERE no_bukti = ?", (no_bukti,))
    if not baris or baris["jumlah"] == 0:
        raise ValueError("Transaksi kas kecil tidak ditemukan.")
    jalankan("DELETE FROM jurnal WHERE no_bukti = ?", (no_bukti,))
    catat_audit("kas_kecil", "hapus", None, f"Hapus {no_bukti}", oleh)


# ------------------------------------------------------------
# 5b. Barang berdasarkan ukuran ikan (cm)
# ------------------------------------------------------------
def perkiraan_berat(cm):
    """
    Menebak berat satu ekor dari panjangnya (kg).

    Ini hanya tebakan awal untuk menghitung ongkir; nilainya masih
    bisa diubah di halaman Data Master.
    """
    acuan = {10: 0.02, 15: 0.05, 20: 0.10, 30: 0.40}
    if cm in acuan:
        return acuan[cm]
    # Untuk ukuran lain, berat tumbuh mengikuti kuadrat panjang.
    return round(0.02 * (cm / 10) ** 2, 3)


def perkiraan_harga_jual(harga_beli):
    """Harga acuan awal: 1,5 kali harga beli, dibulatkan ke Rp500."""
    return int(round(harga_beli * 1.5 / 500) * 500)


def barang_ukuran(cm):
    """Mencari ikan yang ukurannya tepat `cm`. Hasilnya None kalau belum ada."""
    return ambil_satu(
        """SELECT * FROM barang
            WHERE satuan = 'ekor' AND ukuran_cm = ?
            ORDER BY id LIMIT 1""", (int(cm),))


def buat_barang_ukuran(cm, harga_beli, berat=None, harga_jual=None):
    """
    Membuat barang baru untuk ukuran ikan yang belum pernah dibeli.

    Dipakai halaman Pembelian: pengguna cukup mengetik ukuran (misal 25 cm),
    sistem menyiapkan barangnya, lalu pembelian biasa menambah stok dan HPP.
    """
    cm = int(cm)

    # Kode dibuat unik walaupun ukuran yang sama pernah dipakai kode lain.
    dasar = f"KOI{cm}"
    kode = dasar
    nomor = 2
    while ambil_satu("SELECT id FROM barang WHERE kode = ?", (kode,)):
        kode = f"{dasar}-{nomor}"
        nomor += 1

    berat = perkiraan_berat(cm) if berat is None else float(berat)
    harga_jual = (perkiraan_harga_jual(harga_beli)
                  if harga_jual is None else int(harga_jual))

    return jalankan(
        """INSERT INTO barang
           (kode, nama, satuan, stok_awal, hpp, hpp_awal, harga_jual,
            stok_minimum, berat, ukuran_cm, akun_persediaan_id)
           VALUES (?, ?, 'ekor', 0, ?, ?, ?, 0, ?, ?, ?)""",
        (kode, f"Koi Kohaku {cm} cm", harga_beli, harga_beli, harga_jual,
         berat, cm, id_akun("1301")))


def hitung_ulang_hpp(barang_id):
    """
    Menghitung ulang HPP rata-rata dari awal.

    Dipakai setelah sebuah pembelian dibatalkan. Penjualan tidak ikut
    dihitung karena menjual barang dengan harga rata-rata tidak mengubah
    harga rata-ratanya.
    """
    barang = ambil_satu("SELECT * FROM barang WHERE id = ?", (barang_id,))
    if barang is None:
        return

    stok = barang["stok_awal"]
    hpp = barang["hpp_awal"] or barang["hpp"]

    for baris in ambil_semua(
        """SELECT tb.qty, tb.harga_satuan
             FROM transaksi_baris tb
             JOIN transaksi t ON t.id = tb.transaksi_id
            WHERE tb.barang_id = ? AND t.jenis = 'pembelian'
            ORDER BY t.tanggal, t.id, tb.id""", (barang_id,)):
        nilai = stok * hpp + baris["qty"] * baris["harga_satuan"]
        stok += baris["qty"]
        hpp = round(nilai / stok) if stok > 0 else baris["harga_satuan"]

    jalankan("UPDATE barang SET hpp = ? WHERE id = ?", (hpp, barang_id))


# ------------------------------------------------------------
# 6. PEMBELIAN
# ------------------------------------------------------------
def simpan_pembelian(tanggal, pemasok_id, akun_kas_id, keterangan, daftar_baris, oleh):
    """
    daftar_baris = [{"barang_id": 1, "qty": 100, "harga": 10000}, ...]

    Jurnal: Debit Persediaan, Kredit Kas/Bank.
    HPP rata-rata dihitung ulang setelah stok bertambah.
    """
    no_bukti = nomor_bukti("pembelian")
    total = sum(b["qty"] * b["harga"] for b in daftar_baris)

    transaksi_id = jalankan(
        """INSERT INTO transaksi
           (tanggal, no_bukti, jenis, pemasok_id, keterangan, akun_kas_id, dibuat_oleh)
           VALUES (?, ?, 'pembelian', ?, ?, ?, ?)""",
        (tanggal, no_bukti, pemasok_id, keterangan, akun_kas_id, oleh),
    )

    for baris in daftar_baris:
        barang = ambil_satu("SELECT * FROM barang WHERE id = ?", (baris["barang_id"],))

        stok_lama = stok_sekarang(baris["barang_id"])
        nilai_lama = stok_lama * barang["hpp"]

        stok_baru = stok_lama + baris["qty"]
        nilai_baru = nilai_lama + (baris["qty"] * baris["harga"])

        # Rata-rata bergerak, dibulatkan ke rupiah penuh.
        hpp_baru = round(nilai_baru / stok_baru) if stok_baru > 0 else baris["harga"]

        jalankan(
            """INSERT INTO transaksi_baris
               (transaksi_id, barang_id, qty, harga_satuan, hpp_satuan)
               VALUES (?, ?, ?, ?, ?)""",
            (transaksi_id, baris["barang_id"], baris["qty"], baris["harga"], hpp_baru),
        )

        jalankan("UPDATE barang SET hpp = ? WHERE id = ?", (hpp_baru, baris["barang_id"]))

    # Jurnal persediaan (dikelompokkan per akun persediaan).
    per_akun = {}
    for baris in daftar_baris:
        barang = ambil_satu("SELECT * FROM barang WHERE id = ?", (baris["barang_id"],))
        akun = barang["akun_persediaan_id"]
        per_akun[akun] = per_akun.get(akun, 0) + baris["qty"] * baris["harga"]

    for akun_id, nilai in per_akun.items():
        simpan_jurnal(tanggal, no_bukti, akun_id, nilai, 0, f"Pembelian {no_bukti}")

    simpan_jurnal(tanggal, no_bukti, akun_kas_id, 0, total, f"Pembayaran {no_bukti}")

    return no_bukti


def simpan_pembelian_indukan(tanggal, pemasok_id, akun_kas_id, jumlah,
                             keterangan, oleh):
    """
    Membeli indukan koi (aset biologis, akun 1401), bukan barang dagang.

    Jurnal: Debit Indukan Koi, Kredit Kas/Bank. Nomor bukti PB-xxx.
    """
    jumlah = int(jumlah)
    if jumlah <= 0:
        raise ValueError("Nilai pembelian indukan harus lebih dari nol.")

    no_bukti = nomor_bukti("pembelian")
    jalankan(
        """INSERT INTO transaksi
           (tanggal, no_bukti, jenis, pemasok_id, keterangan, akun_kas_id,
            dibuat_oleh, dibuat_pada)
           VALUES (?, ?, 'pembelian', ?, ?, ?, ?, ?)""",
        (tanggal, no_bukti, pemasok_id, keterangan or "Pembelian indukan koi",
         akun_kas_id, oleh, sekarang()))

    simpan_jurnal(tanggal, no_bukti, id_akun("1401"), jumlah, 0,
                  keterangan or "Pembelian indukan koi")
    simpan_jurnal(tanggal, no_bukti, akun_kas_id, 0, jumlah,
                  keterangan or "Pembelian indukan koi")
    catat_audit("transaksi", "tambah", None, f"{no_bukti} indukan {jumlah}",
                oleh, nilai_baru=str(jumlah))
    return no_bukti


def void_pembelian(no_bukti, jabatan="Owner"):
    """
    Membatalkan satu pembelian.

    Yang dihapus: baris transaksi, jurnal, dan transaksi induknya.
    Stok langsung kembali karena stok selalu dihitung dari transaksi.
    HPP dihitung ulang karena harga rata-rata ikut berubah.

    Karyawan tidak boleh menghapus atau mengubah transaksi lama
    (rancangan bagian 2.B.2).
    """
    if jabatan != "Owner":
        raise PermissionError(
            "Hanya Owner yang boleh membatalkan transaksi lama.")
    koneksi = sambung()
    try:
        transaksi = koneksi.execute(
            "SELECT id FROM transaksi WHERE no_bukti = ? AND jenis = 'pembelian'",
            (no_bukti,)).fetchone()
        if transaksi is None:
            raise ValueError(f"Pembelian {no_bukti} tidak ditemukan.")

        barang_ids = [r["barang_id"] for r in koneksi.execute(
            """SELECT DISTINCT tb.barang_id
                 FROM transaksi_baris tb
                 JOIN transaksi t ON t.id = tb.transaksi_id
                WHERE t.no_bukti = ?""", (no_bukti,))]

        koneksi.execute("DELETE FROM transaksi_baris WHERE transaksi_id = ?",
                        (transaksi["id"],))
        koneksi.execute("DELETE FROM jurnal WHERE no_bukti = ?", (no_bukti,))
        koneksi.execute("DELETE FROM transaksi WHERE id = ?", (transaksi["id"],))
        koneksi.commit()
    finally:
        koneksi.close()

    for barang_id in barang_ids:
        hitung_ulang_hpp(barang_id)


# ------------------------------------------------------------
# 7. PENJUALAN
# ------------------------------------------------------------
def simpan_penjualan(tanggal, pelanggan_id, akun_kas_id, keterangan, ongkir,
                     daftar_baris, oleh, berat_paket=0.0):
    """
    Jurnal 1: Debit Kas/Bank, Kredit Penjualan (+ Pendapatan Ongkir).
    Jurnal 2: Debit HPP, Kredit Persediaan Ikan Koi.

    Dua jurnal inilah yang membuat metode perpetual berbeda dari
    metode periodik: laba diketahui saat itu juga.
    """
    no_bukti = nomor_bukti("penjualan")

    total_jual = 0
    total_hpp = 0

    for baris in daftar_baris:
        barang = ambil_satu("SELECT * FROM barang WHERE id = ?", (baris["barang_id"],))
        total_jual += baris["qty"] * baris["harga"]
        total_hpp += baris["qty"] * barang["hpp"]

    transaksi_id = jalankan(
        """INSERT INTO transaksi
           (tanggal, no_bukti, jenis, pelanggan_id, keterangan, akun_kas_id,
            ongkir, berat_paket, dibuat_oleh)
           VALUES (?, ?, 'penjualan', ?, ?, ?, ?, ?, ?)""",
        (tanggal, no_bukti, pelanggan_id, keterangan, akun_kas_id, ongkir,
         float(berat_paket or 0), oleh),
    )

    for baris in daftar_baris:
        barang = ambil_satu("SELECT * FROM barang WHERE id = ?", (baris["barang_id"],))
        jalankan(
            """INSERT INTO transaksi_baris
               (transaksi_id, barang_id, qty, harga_satuan, hpp_satuan)
               VALUES (?, ?, ?, ?, ?)""",
            (transaksi_id, baris["barang_id"], baris["qty"], baris["harga"], barang["hpp"]),
        )

    # Jurnal 1: uang masuk
    simpan_jurnal(tanggal, no_bukti, akun_kas_id, total_jual + ongkir, 0,
                  f"Penerimaan {no_bukti}")
    simpan_jurnal(tanggal, no_bukti, id_akun("4101"), 0, total_jual,
                  f"Penjualan {no_bukti}")

    if ongkir > 0:
        simpan_jurnal(tanggal, no_bukti, id_akun("4102"), 0, ongkir,
                      f"Ongkir {no_bukti}")

    # Jurnal 2: HPP dan pengurangan persediaan
    if total_hpp > 0:
        simpan_jurnal(tanggal, no_bukti, id_akun("5101"), total_hpp, 0,
                      f"HPP {no_bukti}")
        simpan_jurnal(tanggal, no_bukti, id_akun("1301"), 0, total_hpp,
                      f"Pengurangan persediaan {no_bukti}")

    return no_bukti


def void_penjualan(no_bukti, jabatan="Owner"):
    """
    Membatalkan satu penjualan.

    Stok kembali otomatis karena stok dihitung dari transaksi.
    HPP tidak perlu dihitung ulang: penjualan tidak mengubah HPP rata-rata.
    """
    if jabatan != "Owner":
        raise PermissionError(
            "Hanya Owner yang boleh membatalkan transaksi lama.")
    koneksi = sambung()
    try:
        transaksi = koneksi.execute(
            "SELECT id FROM transaksi WHERE no_bukti = ? AND jenis = 'penjualan'",
            (no_bukti,)).fetchone()
        if transaksi is None:
            raise ValueError(f"Penjualan {no_bukti} tidak ditemukan.")

        koneksi.execute("DELETE FROM transaksi_baris WHERE transaksi_id = ?",
                        (transaksi["id"],))
        koneksi.execute("DELETE FROM jurnal WHERE no_bukti = ?", (no_bukti,))
        koneksi.execute("DELETE FROM transaksi WHERE id = ?", (transaksi["id"],))
        koneksi.commit()
    finally:
        koneksi.close()


# ------------------------------------------------------------
# 8. PENGELUARAN KAS (beban)
# ------------------------------------------------------------
def simpan_pengeluaran(tanggal, akun_beban_id, akun_kas_id, jumlah, keterangan, oleh):
    no_bukti = nomor_bukti("pengeluaran_kas")

    jalankan(
        """INSERT INTO transaksi
           (tanggal, no_bukti, jenis, keterangan, akun_kas_id, dibuat_oleh)
           VALUES (?, ?, 'pengeluaran_kas', ?, ?, ?)""",
        (tanggal, no_bukti, keterangan, akun_kas_id, oleh),
    )

    simpan_jurnal(tanggal, no_bukti, akun_beban_id, jumlah, 0, keterangan)
    simpan_jurnal(tanggal, no_bukti, akun_kas_id, 0, jumlah, keterangan)

    return no_bukti


# ------------------------------------------------------------
# 9. PENERIMAAN KAS (setoran modal)
# ------------------------------------------------------------
def simpan_penerimaan(tanggal, akun_kas_id, akun_lawan_id, jumlah, keterangan, oleh):
    no_bukti = nomor_bukti("penerimaan_kas")

    jalankan(
        """INSERT INTO transaksi
           (tanggal, no_bukti, jenis, keterangan, akun_kas_id, dibuat_oleh)
           VALUES (?, ?, 'penerimaan_kas', ?, ?, ?)""",
        (tanggal, no_bukti, keterangan, akun_kas_id, oleh),
    )

    simpan_jurnal(tanggal, no_bukti, akun_kas_id, jumlah, 0, keterangan)
    simpan_jurnal(tanggal, no_bukti, akun_lawan_id, 0, jumlah, keterangan)

    return no_bukti


def hapus_transaksi_kas(no_bukti):
    """Menghapus transaksi kas (masuk/keluar) beserta jurnalnya."""
    koneksi = sambung()
    try:
        koneksi.execute("DELETE FROM jurnal WHERE no_bukti = ?", (no_bukti,))
        koneksi.execute(
            "DELETE FROM transaksi WHERE no_bukti = ? AND jenis IN ('pengeluaran_kas', 'penerimaan_kas')",
            (no_bukti,),
        )
        koneksi.commit()
    finally:
        koneksi.close()


def ubah_transaksi_kas(no_bukti, tanggal, jenis, akun_lawan_id,
                       akun_kas_id, jumlah, keterangan, oleh):
    """
    Mengubah transaksi kas yang sudah tercatat.

    Caranya: hapus dua baris jurnal lama, lalu tulis ulang dengan nilai
    baru. Nomor bukti tetap sama supaya riwayatnya tidak terputus.
    jenis: 'masuk' (penerimaan) atau 'keluar' (pengeluaran).
    """
    koneksi = sambung()
    try:
        transaksi = koneksi.execute(
            """SELECT id FROM transaksi
                WHERE no_bukti = ?
                  AND jenis IN ('pengeluaran_kas', 'penerimaan_kas')""",
            (no_bukti,)).fetchone()
        if transaksi is None:
            raise ValueError(f"Transaksi kas {no_bukti} tidak ditemukan.")

        jenis_db = "penerimaan_kas" if jenis == "masuk" else "pengeluaran_kas"

        koneksi.execute("DELETE FROM jurnal WHERE no_bukti = ?", (no_bukti,))
        koneksi.execute(
            """UPDATE transaksi
                  SET tanggal = ?, jenis = ?, keterangan = ?,
                      akun_kas_id = ?, dibuat_oleh = ?
                WHERE id = ?""",
            (tanggal, jenis_db, keterangan, akun_kas_id, oleh, transaksi["id"]))

        if jenis == "masuk":
            debit, kredit = akun_kas_id, akun_lawan_id
        else:
            debit, kredit = akun_lawan_id, akun_kas_id

        koneksi.execute(
            """INSERT INTO jurnal
               (tanggal, no_bukti, akun_id, debit, kredit, keterangan)
               VALUES (?, ?, ?, ?, 0, ?)""",
            (tanggal, no_bukti, debit, jumlah, keterangan))
        koneksi.execute(
            """INSERT INTO jurnal
               (tanggal, no_bukti, akun_id, debit, kredit, keterangan)
               VALUES (?, ?, ?, 0, ?, ?)""",
            (tanggal, no_bukti, kredit, jumlah, keterangan))

        koneksi.commit()
    finally:
        koneksi.close()


def hapus_opname(opname_id):
    """
    Menghapus satu catatan opname (ikan mati atau pemakaian pakan).

    Jurnal penyesuaiannya ikut dihapus lewat nomor bukti yang tersimpan
    di baris opname. Stok kembali karena stok dihitung dari opname.
    """
    baris = ambil_satu("SELECT * FROM opname WHERE id = ?", (opname_id,))
    if baris is None:
        raise ValueError("Catatan opname tidak ditemukan.")
    if not baris["no_bukti"]:
        raise ValueError(
            "Catatan lama ini belum punya nomor jurnal, jadi belum bisa dihapus.")

    jalankan("DELETE FROM jurnal WHERE no_bukti = ?", (baris["no_bukti"],))
    jalankan("DELETE FROM opname WHERE id = ?", (opname_id,))


# ------------------------------------------------------------
# 10. NERACA SALDO
# ------------------------------------------------------------
def neraca_saldo(sebelum_penyesuaian=False):
    """
    Saldo = total debit - total kredit, lalu disesuaikan dengan
    saldo normal akun. Hasilnya list of dict dengan kunci:
    no_akun, nama, kelompok, saldo_normal, debit, kredit.

    Kalau sebelum_penyesuaian=True, jurnal AJP tidak diikutkan.
    Syaratnya ditaruh di ON, bukan WHERE, supaya akun yang belum
    punya saldo tetap muncul.
    """
    syarat = "AND j.no_bukti NOT LIKE 'AJP%'" if sebelum_penyesuaian else ""
    hasil = ambil_semua(
        f"""SELECT a.id, a.no_akun, a.nama, a.kelompok, a.saldo_normal,
                   COALESCE(SUM(j.debit), 0) AS total_debit,
                   COALESCE(SUM(j.kredit), 0) AS total_kredit
            FROM akun a
            LEFT JOIN jurnal j ON j.akun_id = a.id {syarat}
            GROUP BY a.id
            ORDER BY a.no_akun"""
    )

    daftar = []
    for baris in hasil:
        selisih = baris["total_debit"] - baris["total_kredit"]
        debit = 0
        kredit = 0

        if baris["saldo_normal"] == "Debit":
            if selisih >= 0:
                debit = selisih
            else:
                kredit = -selisih
        else:
            if selisih <= 0:
                kredit = -selisih
            else:
                debit = selisih

        daftar.append({
            "id": baris["id"],
            "no_akun": baris["no_akun"],
            "nama": baris["nama"],
            "kelompok": baris["kelompok"],
            "saldo_normal": baris["saldo_normal"],
            "debit": debit,
            "kredit": kredit,
        })

    return daftar


# ------------------------------------------------------------
# 11. NILAI PERSEDIAAN
# ------------------------------------------------------------
def nilai_persediaan():
    daftar = []
    total = 0

    for barang in ambil_semua(
        """SELECT b.*, k.kode AS kolam_kode
             FROM barang b
             LEFT JOIN kolam k ON k.id = b.kolam_id
            ORDER BY b.kode"""):
        stok = stok_sekarang(barang["id"])
        nilai = stok * barang["hpp"]
        total += nilai

        daftar.append({
            "id": barang["id"],
            "kode": barang["kode"],
            "nama": barang["nama"],
            "satuan": barang["satuan"],
            "stok": stok,
            "hpp": barang["hpp"],
            "harga_jual": barang["harga_jual"],
            "stok_minimum": barang["stok_minimum"],
            "berat": barang["berat"],
            "ukuran_cm": barang["ukuran_cm"],
            "nilai": nilai,
            "kolam_id": barang["kolam_id"],
            "kolam": barang["kolam_kode"] or "-",
        })

    return daftar, total


# ------------------------------------------------------------
# 12. LABA RUGI
# ------------------------------------------------------------
def laba_rugi():
    pendapatan = 0
    penjualan_koi = 0
    pendapatan_ongkir = 0
    hpp = 0
    beban = 0
    rincian_beban = []

    for akun in neraca_saldo():
        if akun["kelompok"] == "Pendapatan":
            nilai = akun["kredit"] - akun["debit"]
            pendapatan += nilai

            if akun["no_akun"] == "4101":
                penjualan_koi = nilai
            else:
                pendapatan_ongkir = nilai

        elif akun["kelompok"] == "HPP":
            hpp += akun["debit"]

        elif akun["kelompok"] == "Beban":
            beban += akun["debit"]
            rincian_beban.append(akun)

    return {
        "pendapatan": pendapatan,
        "penjualan_koi": penjualan_koi,
        "pendapatan_ongkir": pendapatan_ongkir,
        "hpp": hpp,
        "laba_kotor": penjualan_koi - hpp,
        "beban": beban,
        "laba_bersih": pendapatan - hpp - beban,
        "rincian_beban": rincian_beban,
    }


# ------------------------------------------------------------
# 13. CRUD DATA MASTER
# ------------------------------------------------------------


def kode_berikut(tabel, awalan):
    """
    Membuat kode urut otomatis, misal C-06 atau S-05.

    Nomor diambil dari kode terbesar yang sudah ada, bukan dari jumlah
    baris, supaya kode tidak pernah dipakai dua kali.
    """
    semua = ambil_semua(f"SELECT kode FROM {tabel}")
    terbesar = 0
    for baris in semua:
        ekor = str(baris["kode"]).rsplit("-", 1)[-1]
        if ekor.isdigit():
            terbesar = max(terbesar, int(ekor))
    return f"{awalan}-{terbesar + 1:02d}"


def tambah_pemasok(nama, jenis):
    kode = kode_berikut("pemasok", "S")
    return jalankan(
        "INSERT INTO pemasok (kode, nama, jenis) VALUES (?, ?, ?)",
        (kode, nama, jenis))


def ubah_pemasok(pemasok_id, nama, jenis):
    jalankan("UPDATE pemasok SET nama = ?, jenis = ? WHERE id = ?",
             (nama, jenis, pemasok_id))


def hapus_pemasok(pemasok_id):
    dipakai = ambil_satu(
        "SELECT COUNT(*) AS n FROM transaksi WHERE pemasok_id = ?",
        (pemasok_id,))["n"]
    if dipakai:
        raise ValueError(
            "Pemasok ini sudah dipakai di transaksi, jadi tidak boleh dihapus.")
    jalankan("DELETE FROM pemasok WHERE id = ?", (pemasok_id,))


def ubah_pelanggan(pelanggan_id, nama, jenis):
    jalankan("UPDATE pelanggan SET nama = ?, jenis = ? WHERE id = ?",
             (nama, jenis, pelanggan_id))


def hapus_pelanggan(pelanggan_id):
    dipakai = ambil_satu(
        "SELECT COUNT(*) AS n FROM transaksi WHERE pelanggan_id = ?",
        (pelanggan_id,))["n"]
    if dipakai:
        raise ValueError(
            "Pelanggan ini sudah dipakai di transaksi, jadi tidak boleh dihapus.")
    jalankan("DELETE FROM pelanggan WHERE id = ?", (pelanggan_id,))


def tambah_barang(kode, nama, satuan, ukuran_cm, hpp, harga_jual,
                  stok_minimum, berat, akun_persediaan_id, kolam_id=None):
    if ambil_satu("SELECT id FROM barang WHERE kode = ?", (kode,)):
        raise ValueError(f"Kode barang {kode} sudah dipakai.")
    return jalankan(
        """INSERT INTO barang
           (kode, nama, satuan, stok_awal, hpp, hpp_awal, harga_jual,
            stok_minimum, berat, ukuran_cm, akun_persediaan_id, kolam_id)
           VALUES (?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (kode, nama, satuan, hpp, hpp, harga_jual, stok_minimum,
         berat, ukuran_cm, akun_persediaan_id, kolam_id))


def ubah_barang(barang_id, kode, nama, satuan, ukuran_cm, hpp, harga_jual,
                stok_minimum, berat, kolam_id=None):
    bentrok = ambil_satu(
        "SELECT id FROM barang WHERE kode = ? AND id <> ?", (kode, barang_id))
    if bentrok:
        raise ValueError(f"Kode barang {kode} sudah dipakai barang lain.")

    jalankan(
        """UPDATE barang
              SET kode = ?, nama = ?, satuan = ?, ukuran_cm = ?, hpp = ?,
                  harga_jual = ?, stok_minimum = ?, berat = ?, kolam_id = ?
            WHERE id = ?""",
        (kode, nama, satuan, ukuran_cm, hpp, harga_jual, stok_minimum,
         berat, kolam_id, barang_id))


def hapus_barang(barang_id):
    dipakai = ambil_satu(
        """SELECT (SELECT COUNT(*) FROM transaksi_baris WHERE barang_id = ?)
                + (SELECT COUNT(*) FROM opname WHERE barang_id = ?) AS n""",
        (barang_id, barang_id))["n"]
    if dipakai:
        raise ValueError(
            "Barang ini sudah dipakai di transaksi atau opname, "
            "jadi tidak boleh dihapus.")
    jalankan("DELETE FROM barang WHERE id = ?", (barang_id,))


def tambah_akun(no_akun, nama, kelompok, saldo_normal, keterangan=""):
    if ambil_satu("SELECT id FROM akun WHERE no_akun = ?", (no_akun,)):
        raise ValueError(f"Nomor akun {no_akun} sudah dipakai.")
    return jalankan(
        """INSERT INTO akun (no_akun, nama, kelompok, saldo_normal, keterangan)
           VALUES (?, ?, ?, ?, ?)""",
        (no_akun, nama, kelompok, saldo_normal, keterangan))


def ubah_akun(akun_id, no_akun, nama, kelompok, saldo_normal, keterangan=""):
    bentrok = ambil_satu(
        "SELECT id FROM akun WHERE no_akun = ? AND id <> ?", (no_akun, akun_id))
    if bentrok:
        raise ValueError(f"Nomor akun {no_akun} sudah dipakai akun lain.")
    jalankan(
        """UPDATE akun
              SET no_akun = ?, nama = ?, kelompok = ?, saldo_normal = ?,
                  keterangan = ?
            WHERE id = ?""",
        (no_akun, nama, kelompok, saldo_normal, keterangan, akun_id))


def hapus_akun(akun_id):
    dipakai = ambil_satu(
        "SELECT COUNT(*) AS n FROM jurnal WHERE akun_id = ?", (akun_id,))["n"]
    if dipakai:
        raise ValueError(
            "Akun ini sudah dipakai di jurnal, jadi tidak boleh dihapus.")
    jalankan("DELETE FROM akun WHERE id = ?", (akun_id,))


# ------------------------------------------------------------
# 11b. Master kolam dan anggota (rancangan bagian 4.7)
# ------------------------------------------------------------
def daftar_kolam():
    return ambil_semua(
        """SELECT k.*, a.nama AS nama_anggota
             FROM kolam k
             LEFT JOIN anggota a ON a.id = k.anggota_id
            ORDER BY k.kode""")


def tambah_kolam(kode, ukuran, anggota_id, jenis_ikan="Kohaku"):
    if ambil_satu("SELECT id FROM kolam WHERE kode = ?", (kode,)):
        raise ValueError(f"Kode kolam {kode} sudah dipakai.")
    return jalankan(
        "INSERT INTO kolam (kode, ukuran, anggota_id, jenis_ikan) "
        "VALUES (?, ?, ?, ?)",
        (kode, ukuran, anggota_id, jenis_ikan or "Kohaku"))


def ubah_kolam(kolam_id, kode, ukuran, anggota_id, jenis_ikan="Kohaku"):
    bentrok = ambil_satu(
        "SELECT id FROM kolam WHERE kode = ? AND id <> ?", (kode, kolam_id))
    if bentrok:
        raise ValueError(f"Kode kolam {kode} sudah dipakai kolam lain.")
    jalankan(
        "UPDATE kolam SET kode = ?, ukuran = ?, anggota_id = ?, "
        "jenis_ikan = ? WHERE id = ?",
        (kode, ukuran, anggota_id, jenis_ikan or "Kohaku", kolam_id))


def hapus_kolam(kolam_id):
    dipakai = ambil_satu(
        "SELECT COUNT(*) AS n FROM barang WHERE kolam_id = ?", (kolam_id,))["n"]
    if dipakai:
        raise ValueError(
            "Kolam ini masih dipakai barang, jadi tidak boleh dihapus.")
    jalankan("DELETE FROM kolam WHERE id = ?", (kolam_id,))


def daftar_anggota():
    return ambil_semua("SELECT * FROM anggota ORDER BY kode")


def tambah_anggota(kode, nama, kontak=""):
    if ambil_satu("SELECT id FROM anggota WHERE kode = ?", (kode,)):
        raise ValueError(f"Kode anggota {kode} sudah dipakai.")
    return jalankan(
        "INSERT INTO anggota (kode, nama, kontak) VALUES (?, ?, ?)",
        (kode, nama, kontak))


def ubah_anggota(anggota_id, kode, nama, kontak=""):
    bentrok = ambil_satu(
        "SELECT id FROM anggota WHERE kode = ? AND id <> ?",
        (kode, anggota_id))
    if bentrok:
        raise ValueError(f"Kode anggota {kode} sudah dipakai anggota lain.")
    jalankan(
        "UPDATE anggota SET kode = ?, nama = ?, kontak = ? WHERE id = ?",
        (kode, nama, kontak, anggota_id))


def hapus_anggota(anggota_id):
    dipakai = ambil_satu(
        "SELECT COUNT(*) AS n FROM kolam WHERE anggota_id = ?",
        (anggota_id,))["n"]
    if dipakai:
        raise ValueError(
            "Anggota ini masih menjadi penanggung jawab kolam, "
            "jadi tidak boleh dihapus.")
    jalankan("DELETE FROM anggota WHERE id = ?", (anggota_id,))


# ------------------------------------------------------------
# 11c. Kebijakan akuntansi dan tarif ongkir (rancangan 4.5-4.6)
# ------------------------------------------------------------
def baca_kebijakan(kunci, default=None):
    """Membaca satu nilai kebijakan dari database."""
    try:
        baris = ambil_satu(
            "SELECT nilai FROM kebijakan WHERE kunci = ?", (kunci,))
    except sqlite3.OperationalError:
        return default
    return baris["nilai"] if baris else default


def simpan_kebijakan(kunci, nilai, keterangan=""):
    jalankan(
        """INSERT INTO kebijakan (kunci, nilai, keterangan)
           VALUES (?, ?, ?)
           ON CONFLICT(kunci) DO UPDATE SET
               nilai = excluded.nilai,
               keterangan = excluded.keterangan""",
        (kunci, str(nilai), keterangan))


def daftar_kebijakan():
    return ambil_semua("SELECT * FROM kebijakan ORDER BY kunci")


def daftar_ongkir():
    return ambil_semua("SELECT * FROM ongkir_zona ORDER BY tarif")


def simpan_ongkir(zona, tarif, keterangan=""):
    if int(tarif) < 0:
        raise ValueError("Tarif ongkir tidak boleh negatif.")
    jalankan(
        """INSERT INTO ongkir_zona (zona, tarif, keterangan)
           VALUES (?, ?, ?)
           ON CONFLICT(zona) DO UPDATE SET
               tarif = excluded.tarif,
               keterangan = excluded.keterangan""",
        (zona, int(tarif), keterangan))


def hitung_ongkir(cara_kirim, zona, berat):
    """
    Ongkir dari tabel 4.5 rancangan.

    Diambil sekali (ambil sendiri) = 0. Di atas 3 kg = gratis ongkir.
    Tarif per zona disimpan di database supaya bisa diubah Owner.
    """
    if cara_kirim == "ambil":
        return 0
    if berat > 3:
        return 0
    try:
        baris = ambil_satu(
            "SELECT tarif FROM ongkir_zona WHERE zona = ?", (zona,))
        if baris:
            return int(baris["tarif"])
    except sqlite3.OperationalError:
        pass
    return {"dekat": 5000, "sedang": 10000, "jauh": 15000}.get(zona, 0)


# ------------------------------------------------------------
# 11d. Ringkasan dashboard (rancangan bagian 3)
# ------------------------------------------------------------
def _saldo_no(daftar_ns, no_akun):
    for a in daftar_ns:
        if a["no_akun"] == no_akun:
            return a["debit"] - a["kredit"]
    return 0


def ringkasan_dashboard():
    """
    Angka utama yang tampil di menu Ringkasan.

    Kunci: stok_ekor, nilai_stok, total_pembelian, total_penjualan,
    kas_bank, utang, piutang, laba_bersih.
    """
    persediaan, _ = nilai_persediaan()
    stok_ekor = sum(b["stok"] for b in persediaan if b["satuan"] == "ekor")
    nilai_stok = sum(b["nilai"] for b in persediaan if b["satuan"] == "ekor")

    pembelian = ambil_satu(
        """SELECT COALESCE(SUM(tb.qty * tb.harga_satuan), 0) AS total
             FROM transaksi t
             JOIN transaksi_baris tb ON tb.transaksi_id = t.id
            WHERE t.jenis = 'pembelian'""")
    laba = laba_rugi()
    ns = neraca_saldo()
    kas_bank = _saldo_no(ns, "1101") + _saldo_no(ns, "1102")

    return {
        "stok_ekor": stok_ekor,
        "nilai_stok": nilai_stok,
        "total_pembelian": int(pembelian["total"] if pembelian else 0),
        "total_penjualan": laba["penjualan_koi"],
        "kas_bank": kas_bank,
        "utang": -_saldo_no(ns, "2101"),
        "piutang": _saldo_no(ns, "1201"),
        "laba_bersih": laba["laba_bersih"],
    }


def mortalitas_bulanan():
    """Jumlah ikan mati per bulan dari stok opname."""
    return ambil_semua(
        """SELECT substr(tanggal, 1, 7) AS bulan,
                  SUM(qty_hilang) AS mati
             FROM opname
            WHERE jenis = 'mati'
            GROUP BY substr(tanggal, 1, 7)
            ORDER BY bulan""")


def estimasi_umur_bulan(ukuran_cm):
    """
    Perkiraan umur menuju ukuran jual.

    Acuan rancangan: 10 cm ke 30 cm sekitar 12 bulan, jadi setiap
    kenaikan 20 cm setara 12 bulan.
    """
    return max(0, round((int(ukuran_cm) - 10) * 12 / 20))


def komposisi_kas():
    """Saldo kas, bank, dan kas kecil."""
    ns = neraca_saldo()
    return {
        "kas": _saldo_no(ns, "1101"),
        "bank": _saldo_no(ns, "1102"),
        "kas_kecil": _saldo_no(ns, "1103"),
    }


def lima_ukuran_terlaris():
    """Lima barang paling banyak terjual (ekor/kg)."""
    return ambil_semua(
        """SELECT b.nama, b.ukuran_cm, SUM(tb.qty) AS qty,
                  SUM(tb.qty * tb.harga_satuan) AS nilai
             FROM transaksi t
             JOIN transaksi_baris tb ON tb.transaksi_id = t.id
             JOIN barang b ON b.id = tb.barang_id
            WHERE t.jenis = 'penjualan'
            GROUP BY b.id
            ORDER BY qty DESC
            LIMIT 5""")


def biaya_pakan_persen():
    """Biaya pakan sebagai persen dari penjualan (0 kalau belum ada jual)."""
    laba = laba_rugi()
    if not laba["penjualan_koi"]:
        return 0.0
    pakan = 0
    for akun in laba["rincian_beban"]:
        if akun["no_akun"] == "6101":
            pakan = akun["debit"]
            break
    return round(pakan * 100 / laba["penjualan_koi"], 1)


def pakan_sisa_bulan():
    """Perkiraan berapa bulan stok pakan masih cukup."""
    stok = 0
    for barang in ambil_semua(
            "SELECT * FROM barang WHERE satuan = 'kg'"):
        stok += stok_sekarang(barang["id"])
    pakai = int(baca_kebijakan("pemakaian_pakan_bulanan_kg", "60") or 60)
    if pakai <= 0:
        return 0.0
    return round(stok / pakai, 1)


def penjualan_harian():
    """Total penjualan per tanggal, untuk grafik batang dashboard."""
    return ambil_semua(
        """SELECT j.tanggal, SUM(j.kredit) AS total
             FROM jurnal j
             JOIN akun a ON a.id = j.akun_id
            WHERE a.no_akun = '4101'
            GROUP BY j.tanggal
            ORDER BY j.tanggal""")


# ------------------------------------------------------------
# 11e. Neraca lajur / worksheet (rancangan bagian 8)
# ------------------------------------------------------------
def neraca_lajur():
    """
    Neraca lajur 10 kolom.

    Kolom: Neraca Saldo, Penyesuaian, Neraca Saldo Setelah
    Disesuaikan, Laba Rugi, dan Neraca. Laba bersih dipindahkan ke
    sisi debit Laba Rugi dan sisi kredit Neraca.
    """
    sebelum = {a["no_akun"]: a for a in neraca_saldo(True)}
    sesudah = {a["no_akun"]: a for a in neraca_saldo()}

    # Penyesuaian diambil mentah dari jurnal AJP, bukan dari selisih
    # saldo bersih. Alasannya: saldo bersih menyembunyikan sisi lawan
    # (misalnya persediaan pakan berkurang di sisi kredit).
    penyesuaian = {}
    for b in ambil_semua(
        """SELECT a.no_akun, SUM(j.debit) AS debit, SUM(j.kredit) AS kredit
             FROM jurnal j
             JOIN akun a ON a.id = j.akun_id
            WHERE j.no_bukti LIKE 'AJP%'
            GROUP BY a.no_akun"""):
        penyesuaian[b["no_akun"]] = (b["debit"], b["kredit"])

    baris = []
    total = dict(ns_d=0, ns_k=0, pen_d=0, pen_k=0, nssd_d=0, nssd_k=0,
                 lr_d=0, lr_k=0, neraca_d=0, neraca_k=0)

    for no_akun in sorted(sesudah):
        a = sesudah[no_akun]
        b = sebelum.get(no_akun, {"debit": 0, "kredit": 0})

        pen_d, pen_k = penyesuaian.get(no_akun, (0, 0))

        isi = {
            "no_akun": no_akun,
            "nama": a["nama"],
            "kelompok": a["kelompok"],
            "ns_d": b["debit"], "ns_k": b["kredit"],
            "pen_d": pen_d, "pen_k": pen_k,
            "nssd_d": a["debit"], "nssd_k": a["kredit"],
            "lr_d": 0, "lr_k": 0, "neraca_d": 0, "neraca_k": 0,
        }

        if a["kelompok"] in ("Pendapatan", "HPP", "Beban"):
            isi["lr_d"] = isi["nssd_d"]
            isi["lr_k"] = isi["nssd_k"]
        else:
            isi["neraca_d"] = isi["nssd_d"]
            isi["neraca_k"] = isi["nssd_k"]

        for kunci in total:
            total[kunci] += isi.get(kunci, 0)
        baris.append(isi)

    laba = total["lr_k"] - total["lr_d"]
    if laba > 0:
        total["lr_d"] += laba
        total["neraca_k"] += laba
    elif laba < 0:
        total["lr_k"] += -laba
        total["neraca_d"] += -laba

    hasil = {"baris": baris, "laba_bersih": laba}
    hasil.update(total)
    return hasil


# ------------------------------------------------------------
# 11f. Laporan arus kas metode langsung (rancangan bagian 9D)
# ------------------------------------------------------------
AKUN_KAS_ARUS = ("1101", "1102")


def arus_kas():
    """
    Arus kas metode langsung dari jurnal.

    Setiap nomor bukti yang menyentuh Kas/Bank dihitung satu kali.
    Lawan akun menentukan kelompoknya: penjualan, bibit, pakan,
    beban operasional, modal, atau prive.
    """
    semua = ambil_semua(
        """SELECT j.no_bukti, j.debit, j.kredit, j.keterangan,
                  a.no_akun, a.nama
             FROM jurnal j
             JOIN akun a ON a.id = j.akun_id
            ORDER BY j.tanggal, j.id""")

    kelompok = {}
    for baris in semua:
        kelompok.setdefault(baris["no_bukti"], []).append(baris)

    hasil = {
        "penerimaan_penjualan": 0,
        "pembelian_bibit": 0,
        "pembelian_pakan": 0,
        "beban_operasional": 0,
        "lain": 0,
        "setoran_modal": 0,
        "prive": 0,
        "saldo_awal": 0,
    }
    rincian_beban = {}

    for no_bukti, baris in kelompok.items():
        kas = [b for b in baris if b["no_akun"] in AKUN_KAS_ARUS]
        if not kas:
            continue

        selisih = sum(b["debit"] - b["kredit"] for b in kas)
        lawan = [b for b in baris if b["no_akun"] not in AKUN_KAS_ARUS]

        if no_bukti.startswith("SA"):
            hasil["saldo_awal"] += selisih
        elif no_bukti.startswith("PJ"):
            hasil["penerimaan_penjualan"] += selisih
        elif no_bukti.startswith("PB"):
            nomor = {b["no_akun"] for b in lawan}
            if "1301" in nomor:
                hasil["pembelian_bibit"] += -selisih
            elif "1302" in nomor:
                hasil["pembelian_pakan"] += -selisih
            else:
                hasil["lain"] += -selisih
        elif no_bukti.startswith("KK"):
            hasil["beban_operasional"] += -selisih
            for b in lawan:
                if b["no_akun"].startswith("61"):
                    rincian_beban[b["no_akun"]] = (
                        rincian_beban.get(b["no_akun"], 0) + b["debit"])
        elif no_bukti.startswith("PK"):
            nomor = {b["no_akun"] for b in lawan}
            if "3101" in nomor:
                hasil["setoran_modal"] += selisih
            elif "3102" in nomor:
                hasil["prive"] += -selisih
            else:
                hasil["lain"] += selisih
        else:
            hasil["lain"] += selisih

    hasil["arus_operasi"] = (
        hasil["penerimaan_penjualan"] - hasil["pembelian_bibit"]
        - hasil["pembelian_pakan"] - hasil["beban_operasional"]
        + hasil["lain"])
    hasil["kenaikan"] = (
        hasil["arus_operasi"] + hasil["setoran_modal"] - hasil["prive"])
    hasil["saldo_akhir"] = hasil["saldo_awal"] + hasil["kenaikan"]
    hasil["rincian_beban"] = rincian_beban
    return hasil