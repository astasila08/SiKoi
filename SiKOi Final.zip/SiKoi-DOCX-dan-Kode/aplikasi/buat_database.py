"""
============================================================
buat_database.py -- Membuat database + data awal
============================================================
Jalankan SEKALI dari terminal:

    python buat_database.py

Kalau dijalankan lagi, file sikoi.db dibuat ulang dari nol.
"""

import os
import secrets
import sqlite3

from hitung import hash_pin

NAMA_DATABASE = "sikoi.db"

# ------------------------------------------------------------
# LANGKAH 1: Hapus file lama (supaya bisa diulang dari nol)
# ------------------------------------------------------------
if os.path.exists(NAMA_DATABASE):
    os.remove(NAMA_DATABASE)
    print("Database lama dihapus.")

koneksi = sqlite3.connect(NAMA_DATABASE)
koneksi.row_factory = sqlite3.Row
koneksi.execute("PRAGMA foreign_keys = ON")

# ------------------------------------------------------------
# LANGKAH 2: Buat tabel
# ------------------------------------------------------------
koneksi.executescript("""
CREATE TABLE pengguna (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    nama    TEXT NOT NULL,
    jabatan TEXT NOT NULL,            -- 'Owner' atau 'Karyawan'
    pin     TEXT NOT NULL,            -- hash SHA-256, bukan teks biasa
    salt    TEXT NOT NULL DEFAULT '', -- garam acak per pengguna
    aktif   INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE login_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    pengguna_id INTEGER,
    nama        TEXT NOT NULL,
    jabatan     TEXT NOT NULL,
    waktu       TEXT NOT NULL
);

CREATE TABLE audit_trail (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    waktu      TEXT NOT NULL,
    pengguna   TEXT NOT NULL,
    tabel      TEXT NOT NULL,
    aksi       TEXT NOT NULL,          -- tambah / ubah / hapus / login
    record_id  INTEGER,
    keterangan TEXT,
    nilai_lama TEXT,
    nilai_baru TEXT
);

CREATE TABLE anggota (
    id     INTEGER PRIMARY KEY AUTOINCREMENT,
    kode   TEXT NOT NULL,
    nama   TEXT NOT NULL,
    kontak TEXT NOT NULL DEFAULT '',
    aktif  INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE kolam (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    kode       TEXT NOT NULL,
    ukuran     TEXT NOT NULL,
    anggota_id INTEGER,
    jenis_ikan TEXT NOT NULL DEFAULT 'Kohaku',
    aktif      INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE kebijakan (
    kunci      TEXT PRIMARY KEY,
    nilai      TEXT NOT NULL,
    keterangan TEXT NOT NULL DEFAULT ''
);

CREATE TABLE ongkir_zona (
    zona       TEXT PRIMARY KEY,
    tarif      INTEGER NOT NULL,
    keterangan TEXT NOT NULL DEFAULT ''
);

CREATE TABLE akun (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    no_akun      TEXT NOT NULL,
    nama         TEXT NOT NULL,
    kelompok     TEXT NOT NULL,
    saldo_normal TEXT NOT NULL,       -- 'Debit' atau 'Kredit'
    keterangan   TEXT NOT NULL DEFAULT ''
);

CREATE TABLE pemasok (
    id    INTEGER PRIMARY KEY AUTOINCREMENT,
    kode  TEXT NOT NULL,
    nama  TEXT NOT NULL,
    jenis TEXT NOT NULL
);

CREATE TABLE pelanggan (
    id    INTEGER PRIMARY KEY AUTOINCREMENT,
    kode  TEXT NOT NULL,
    nama  TEXT NOT NULL,
    jenis TEXT NOT NULL
);

CREATE TABLE barang (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    kode               TEXT NOT NULL,
    nama               TEXT NOT NULL,
    satuan             TEXT NOT NULL,
    stok_awal          INTEGER NOT NULL,
    hpp                INTEGER NOT NULL,      -- HPP rata-rata saat ini
    hpp_awal           INTEGER NOT NULL DEFAULT 0,  -- HPP sebelum pembelian apa pun
    harga_jual         INTEGER NOT NULL,
    stok_minimum       INTEGER NOT NULL,
    berat              REAL NOT NULL,          -- kg per satuan
    ukuran_cm          INTEGER NOT NULL DEFAULT 0,  -- 0 = bukan ikan
    akun_persediaan_id INTEGER NOT NULL,
    kolam_id           INTEGER
);

CREATE TABLE transaksi (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    tanggal      TEXT NOT NULL,                -- YYYY-MM-DD
    no_bukti     TEXT NOT NULL,
    jenis        TEXT NOT NULL,
    pelanggan_id INTEGER,
    pemasok_id   INTEGER,
    keterangan   TEXT,
    akun_kas_id  INTEGER,
    ongkir       INTEGER DEFAULT 0,
    berat_paket  REAL NOT NULL DEFAULT 0,   -- total kg yang dipakai menghitung ongkir
    dibuat_oleh  TEXT,
    dibuat_pada  TEXT,
    diubah_oleh  TEXT,
    diubah_pada  TEXT
);

CREATE TABLE transaksi_baris (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    transaksi_id INTEGER NOT NULL,
    barang_id    INTEGER NOT NULL,
    qty          INTEGER NOT NULL,
    harga_satuan INTEGER NOT NULL,
    hpp_satuan   INTEGER NOT NULL
);

CREATE TABLE opname (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    tanggal    TEXT NOT NULL,
    barang_id  INTEGER NOT NULL,
    qty_hilang INTEGER NOT NULL,
    jenis      TEXT NOT NULL DEFAULT 'mati',   -- 'mati' atau 'pakai'
    no_bukti   TEXT NOT NULL DEFAULT '',       -- nomor jurnal AJP-xxx
    keterangan TEXT,
    dibuat_oleh TEXT,
    dibuat_pada TEXT
);

CREATE TABLE jurnal (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    tanggal    TEXT NOT NULL,
    no_bukti   TEXT NOT NULL,
    akun_id    INTEGER NOT NULL,
    debit      INTEGER NOT NULL DEFAULT 0,
    kredit     INTEGER NOT NULL DEFAULT 0,
    keterangan TEXT,
    dibuat_pada TEXT
);
""")

# ------------------------------------------------------------
# LANGKAH 3: Isi data awal
# ------------------------------------------------------------

# Pengguna (PIN disimpan sebagai hash SHA-256 + garam acak, bukan teks biasa)
daftar_pengguna = [("Pak Hadi", "Owner", "1234"), ("Mas Tono", "Karyawan", "5678")]
for nama, jabatan, pin in daftar_pengguna:
    salt = secrets.token_hex(8)
    koneksi.execute(
        "INSERT INTO pengguna (nama, jabatan, pin, salt) VALUES (?, ?, ?, ?)",
        (nama, jabatan, hash_pin(pin, salt), salt),
    )

# Anggota kelompok (22 orang, sesuai rancangan bagian 4.7)
daftar_anggota = [
    (f"A-{i:02d}", f"Anggota {i}", "") for i in range(1, 23)
]
koneksi.executemany(
    "INSERT INTO anggota (kode, nama, kontak) VALUES (?, ?, ?)",
    daftar_anggota,
)

# Kolam (3 kolam koi 6x8 m). Tiga anggota pertama menjadi penanggung jawab.
koneksi.executemany(
    "INSERT INTO kolam (kode, ukuran, anggota_id, jenis_ikan) VALUES (?, ?, ?, ?)",
    [("K-01", "6x8 m", 1, "Kohaku"),
     ("K-02", "6x8 m", 2, "Kohaku"),
     ("K-03", "6x8 m", 3, "Kohaku")],
)

# Kebijakan akuntansi (rancangan bagian 4.6)
daftar_kebijakan = [
    ("metode_persediaan", "perpetual_rata_rata", "Perpetual, rata-rata bergerak"),
    ("pembayaran", "tunai", "Tunai (kas/transfer bank); kredit nonaktif"),
    ("denda_termin", "0", "Denda dan termin tidak berlaku"),
    ("tarif_retribusi", "125000", "Per kolam per bulan, jatuh tempo tanggal 10"),
    ("umur_ekonomis_bulan", "36", "Penyusutan garis lurus 3 tahun"),
    ("batas_kapitalisasi", "500000", "Di atas nilai ini menjadi aset"),
    ("pemakaian_pakan_bulanan_kg", "60", "Perkiraan pemakaian pakan per bulan"),
    ("momen_jual_tanggal", "2027-01-01,2027-03-20", "Tahun Baru dan Lebaran"),
]
koneksi.executemany(
    "INSERT INTO kebijakan (kunci, nilai, keterangan) VALUES (?, ?, ?)",
    daftar_kebijakan,
)

# Zona ongkir (rancangan bagian 4.5)
koneksi.executemany(
    "INSERT INTO ongkir_zona (zona, tarif, keterangan) VALUES (?, ?, ?)",
    [("dekat", 5000, "Dalam kota, berat 1-3 kg"),
     ("sedang", 10000, "Zona sedang, berat 1-3 kg"),
     ("jauh", 15000, "Luar kota, berat 1-3 kg")],
)

# Daftar akun (mengikuti Rancangan SIA SiKoi Revisi 2, bagian 4.1).
# Nama akun dibuat baku; keterangan tambahan ada di kolom Keterangan.
daftar_akun = [
    ("1101", "Kas", "Aset Lancar", "Debit", ""),
    ("1102", "Bank", "Aset Lancar", "Debit", ""),
    ("1103", "Kas Kecil", "Aset Lancar", "Debit", "Modul sementara"),
    ("1201", "Piutang Usaha", "Aset Lancar", "Debit", "Nonaktif"),
    ("1301", "Persediaan Ikan Koi", "Aset Lancar", "Debit", ""),
    ("1302", "Persediaan Pakan", "Aset Lancar", "Debit", ""),
    ("1401", "Indukan Koi", "Aset Tetap", "Debit", "Aset biologis, tidak disusutkan"),
    ("1501", "Peralatan", "Aset Tetap", "Debit", "Jaring, serok, timbangan, ember"),
    ("1502", "Akumulasi Penyusutan Peralatan", "Aset Tetap", "Kredit", ""),
    ("2101", "Utang Usaha", "Kewajiban", "Kredit", "Nonaktif"),
    ("3101", "Modal", "Ekuitas", "Kredit", ""),
    ("3102", "Prive", "Ekuitas", "Debit", "Penarikan anggota"),
    ("4101", "Penjualan", "Pendapatan", "Kredit", "Penjualan koi"),
    ("4102", "Pendapatan Ongkos Kirim", "Pendapatan", "Kredit", ""),
    ("5101", "Harga Pokok Penjualan", "HPP", "Debit", ""),
    ("6101", "Beban Pakan", "Beban", "Debit", ""),
    ("6102", "Beban Retribusi", "Beban", "Debit", "Retribusi kolam"),
    ("6103", "Beban Perlengkapan", "Beban", "Debit", "Termasuk garam grosok dan perawatan peralatan"),
    ("6104", "Beban Ongkos Kirim", "Beban", "Debit", ""),
    ("6105", "Beban Penyusutan Peralatan", "Beban", "Debit", ""),
    ("6106", "Beban Kerugian Ikan Mati", "Beban", "Debit", ""),
]
koneksi.executemany(
    "INSERT INTO akun (no_akun, nama, kelompok, saldo_normal, keterangan) VALUES (?, ?, ?, ?, ?)",
    daftar_akun,
)

# Pemasok
koneksi.executemany(
    "INSERT INTO pemasok (kode, nama, jenis) VALUES (?, ?, ?)",
    [
        ("S-01", "UD Bibit Koi Sumber Rejeki", "Supplier bibit/induk"),
        ("S-02", "Toko Pakan Ikan Makmur", "Supplier pakan"),
        ("S-03", "Toko Perikanan Tirta", "Supplier peralatan/garam"),
        ("S-04", "Dinas Perikanan Kota Semarang", "Retribusi kolam"),
    ],
)

# Pelanggan
koneksi.executemany(
    "INSERT INTO pelanggan (kode, nama, jenis) VALUES (?, ?, ?)",
    [
        ("C-01", "Pembeli Umum (penghobi)", "Customer"),
        ("C-02", "Pak Darto (pengepul)", "Customer borongan"),
        ("C-03", "Pembeli Online Luar Kota", "Customer"),
        ("C-04", "Kafe Taman Asri", "Customer"),
        ("C-05", "Pemesan Proyek/Bantuan", "Customer pesanan benih"),
    ],
)


def cari_id_akun(no_akun):
    """Mencari id akun dari nomornya, supaya tidak menulis angka ajaib."""
    baris = koneksi.execute(
        "SELECT id FROM akun WHERE no_akun = ?", (no_akun,)
    ).fetchone()
    return baris["id"]


def cari_id_kolam(kode):
    """Mencari id kolam dari kodenya (K-01, K-02, ...)."""
    baris = koneksi.execute(
        "SELECT id FROM kolam WHERE kode = ?", (kode,)
    ).fetchone()
    return baris["id"] if baris else None


akun_koi = cari_id_akun("1301")
akun_pakan = cari_id_akun("1302")
kolam_1 = cari_id_kolam("K-01")
kolam_2 = cari_id_kolam("K-02")
kolam_3 = cari_id_kolam("K-03")

# Barang: (kode, nama, satuan, stok awal, hpp, harga jual, minimum, berat,
#          ukuran cm, akun, kolam)
# hpp_awal diisi sama dengan hpp karena belum ada pembelian.
daftar_barang = [
    ("KOI10", "Koi Kohaku 10 cm", "ekor", 150, 10000, 15000, 100, 0.02, 10, akun_koi, kolam_1),
    ("KOI15", "Koi Kohaku 15 cm", "ekor", 100, 14000, 25000,  60, 0.05, 15, akun_koi, kolam_2),
    ("KOI20", "Koi Kohaku 20 cm", "ekor",  60, 20000, 40000,  30, 0.10, 20, akun_koi, kolam_3),
    ("KOI30", "Koi Kohaku 30 cm", "ekor",  40, 32000, 75000,  15, 0.40, 30, akun_koi, kolam_1),
    ("PKN01", "Pakan koi protein 18-20%", "kg", 40, 11000, 0, 50, 0.00, 0, akun_pakan, None),
]
koneksi.executemany(
    """INSERT INTO barang
       (kode, nama, satuan, stok_awal, hpp, hpp_awal, harga_jual,
        stok_minimum, berat, ukuran_cm, akun_persediaan_id, kolam_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
    [(b[0], b[1], b[2], b[3], b[4], b[4], b[5], b[6], b[7], b[8], b[9], b[10])
     for b in daftar_barang],
)

# ------------------------------------------------------------
# LANGKAH 4: Jurnal saldo awal (1 Oktober 2026)
# ------------------------------------------------------------
# Total debit harus sama dengan total kredit: Rp15.320.000
saldo_awal = [
    ("2026-10-01", "SA-001", cari_id_akun("1101"), 1500000, 0, "Saldo awal kas"),
    ("2026-10-01", "SA-001", cari_id_akun("1102"), 3000000, 0, "Saldo awal bank"),
    ("2026-10-01", "SA-001", cari_id_akun("1301"), 5380000, 0, "Saldo awal persediaan ikan koi"),
    ("2026-10-01", "SA-001", cari_id_akun("1302"), 440000, 0, "Saldo awal persediaan pakan"),
    ("2026-10-01", "SA-001", cari_id_akun("1401"), 3200000, 0, "Saldo awal indukan koi (6 ekor)"),
    ("2026-10-01", "SA-001", cari_id_akun("1501"), 1800000, 0, "Saldo awal peralatan kolam"),
    ("2026-10-01", "SA-001", cari_id_akun("1502"), 0, 600000, "Akumulasi penyusutan peralatan"),
    ("2026-10-01", "SA-001", cari_id_akun("3101"), 0, 14720000, "Modal awal kelompok"),
]

koneksi.executemany(
    """INSERT INTO jurnal (tanggal, no_bukti, akun_id, debit, kredit, keterangan)
       VALUES (?, ?, ?, ?, ?, ?)""",
    saldo_awal,
)

koneksi.commit()

# ------------------------------------------------------------
# LANGKAH 5: Periksa hasilnya sendiri
# ------------------------------------------------------------
total_debit = koneksi.execute("SELECT SUM(debit) FROM jurnal").fetchone()[0]
total_kredit = koneksi.execute("SELECT SUM(kredit) FROM jurnal").fetchone()[0]

koneksi.close()

print("Database dibuat:", NAMA_DATABASE)
print(f"Total debit  : {total_debit:,}".replace(",", "."))
print(f"Total kredit : {total_kredit:,}".replace(",", "."))
print("SEIMBANG" if total_debit == total_kredit else "TIDAK SEIMBANG")