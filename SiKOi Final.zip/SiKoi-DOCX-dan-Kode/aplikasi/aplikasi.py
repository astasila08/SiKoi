"""
============================================================
aplikasi.py -- SiKoi sebagai aplikasi desktop Python
============================================================

Aplikasi ini memakai HANYA Python dan pustaka bawaannya:

    tkinter   -> jendela, tombol, tabel, isian  (sudah ada di Python)
    sqlite3   -> database                       (sudah ada di Python)

Tidak ada HTML, tidak ada CSS, tidak ada JavaScript.
Tidak ada `pip install`.

Cara menjalankan:

    python buat_database.py      (sekali saja)
    python isi_contoh.py         (sekali saja)
    python aplikasi.py

Struktur file ini:

    1. Pengaturan dan alat bantu format
    2. Jendela masuk (login)
    3. Jendela utama + menu
    4. Delapan halaman: Dashboard, Penjualan, Pembelian, Kas,
       Penyesuaian, Jurnal, Laporan, Data
    5. Menjalankan aplikasi

Semua hitungan pembukuan tetap di hitung.py -- file ini hanya
mengurus tampilan dan tombol.
"""

import re
import tkinter as tk
from datetime import date
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from xml.sax.saxutils import escape
from zipfile import ZIP_DEFLATED, ZipFile

import hitung

# ------------------------------------------------------------
# 1. PENGATURAN
# ------------------------------------------------------------
JUDUL = "SiKoi - Sistem Informasi Akuntansi Budidaya Ikan Koi"

# Nomor akun yang sering dipakai.
AKUN_KAS = "1101"
AKUN_BANK = "1102"
AKUN_MODAL = "3101"
AKUN_PERSEDIAAN_KOI = "1301"
AKUN_PERSEDIAAN_PAKAN = "1302"
AKUN_BEBAN_PAKAN = "6101"
AKUN_BEBAN_PENYUSUTAN = "6105"
AKUN_BEBAN_IKAN_MATI = "6106"
AKUN_AKUM_PENYUSUTAN = "1502"

# Warna, dipakai berulang supaya tampilan seragam.
LATAR = "#faf7f1"
LATAR_KARTU = "#ffffff"
GARIS = "#ddd4c5"
TEKS = "#24211d"
TEKS_LEMAH = "#6d665c"
AKSEN = "#8a4b2a"
MERAH = "#b03030"
HIJAU = "#2f7d4f"

FONT = ("DejaVu Sans", 10)
FONT_KECIL = ("DejaVu Sans", 9)
FONT_JUDUL = ("DejaVu Sans", 16, "bold")
FONT_ANGKA = ("DejaVu Sans Mono", 15, "bold")

# Logo ikut dikirim bersama aplikasi. Kalau berkasnya hilang, aplikasi tetap
# dibuka tanpa ikon -- jangan sampai gambar yang tidak penting memblokir kasir.
BERKAS_LOGO = Path(__file__).with_name("logo-sikoi.png")
_LOGO_TERSIMPAN = []  # Tk tidak menyimpan referensi; tanpa ini gambar terhapus GC.


def muat_logo(lebar_maks):
    """Muat logo sebagai PhotoImage, diperkecil mendekati lebar_maks piksel.

    Tk hanya bisa memperkecil dengan kelipatan bilangan bulat (subsample),
    jadi ukuran hasilnya bisa sedikit lebih kecil dari lebar_maks.
    """
    if not BERKAS_LOGO.exists():
        return None
    try:
        gambar = tk.PhotoImage(file=str(BERKAS_LOGO))
        faktor = max(1, round(gambar.width() / lebar_maks))
        if faktor > 1:
            gambar = gambar.subsample(faktor, faktor)
    except tk.TclError:
        return None
    _LOGO_TERSIMPAN.append(gambar)
    return gambar


# ------------------------------------------------------------
# 2. ALAT BANTU FORMAT
# ------------------------------------------------------------
def angka(nilai):
    """2975000 -> '2.975.000'"""
    return f"{int(nilai or 0):,}".replace(",", ".")


def rupiah(nilai):
    """2975000 -> 'Rp2.975.000'"""
    return "Rp" + angka(nilai)


def akun(nilai):
    """Gaya akuntansi: negatif dalam kurung. -378000 -> '(378.000)'"""
    nilai = int(nilai or 0)
    return f"({angka(abs(nilai))})" if nilai < 0 else angka(nilai)


def rupiah_akun(nilai):
    nilai = int(nilai or 0)
    return f"(Rp{angka(abs(nilai))})" if nilai < 0 else "Rp" + angka(nilai)


def tanggal_rapi(teks):
    """'2026-10-07' -> '07 Okt 2026'"""
    bulan = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun",
             "Jul", "Agu", "Sep", "Okt", "Nov", "Des"]
    try:
        tahun, nomor, hari = str(teks).split("-")
        return f"{int(hari):02d} {bulan[int(nomor) - 1]} {tahun}"
    except Exception:
        return str(teks)


def teks_dari(entri):
    """Mengambil isi kotak isian sebagai teks, sudah dipangkas."""
    return entri.get().strip()


def bulat_dari(entri, bawaan=0):
    """Mengambil isi kotak isian sebagai bilangan bulat."""
    try:
        return int(str(entri.get()).strip() or bawaan)
    except ValueError:
        return bawaan


def hitung_ongkir(cara_kirim, zona, berat):
    """Aturan ongkir dari tabel 4.5 dokumen rancangan (disimpan di database)."""
    return hitung.hitung_ongkir(cara_kirim, zona, berat)


# ------------------------------------------------------------
# 3. KERANGKA TAMPILAN
# ------------------------------------------------------------
class Halaman(ttk.Frame):
    """Dasar untuk semua halaman: latar, judul, dan pesan."""

    def __init__(self, induk, aplikasi, judul):
        super().__init__(induk, padding=16)
        self.aplikasi = aplikasi

        ttk.Label(self, text=judul, font=FONT_JUDUL).pack(anchor="w", pady=(0, 10))

        # Tempat pesan berhasil / gagal.
        self.pesan = ttk.Label(self, text="", font=FONT_KECIL)
        self.pesan.pack(anchor="w", pady=(0, 8))

        # Isi halaman ditaruh di area yang bisa digulir.
        self.isi = siapkan_gulir(self)

    def kabar(self, teks, berhasil=True):
        self.pesan.configure(
            text=teks, foreground=HIJAU if berhasil else MERAH
        )

    # --- alat bantu formulir, dipakai semua halaman ---
    def _isian(self, induk, label, kolom, lebar=16, baris=0):
        """Membuat satu kotak isian beserta labelnya di atasnya."""
        tk.Label(induk, text=label, bg=LATAR_KARTU, fg=TEKS_LEMAH,
                 font=("DejaVu Sans", 8)).grid(
            row=baris * 2, column=kolom, sticky="w",
            padx=(0 if kolom == 0 else 12, 0))
        entri = ttk.Entry(induk, width=lebar)
        entri.grid(row=baris * 2 + 1, column=kolom, sticky="w",
                   padx=(0 if kolom == 0 else 12, 0))
        return entri

    def _pilihan(self, induk, label, kolom, pasangan, perintah=None, baris=0):
        tk.Label(induk, text=label, bg=LATAR_KARTU, fg=TEKS_LEMAH,
                 font=("DejaVu Sans", 8)).grid(
            row=baris * 2, column=kolom, sticky="w",
            padx=(0 if kolom == 0 else 12, 0))
        kotak = ttk.Combobox(induk, state="readonly", width=16,
                             values=[p[0] for p in pasangan])
        kotak.grid(row=baris * 2 + 1, column=kolom, sticky="w",
                   padx=(0 if kolom == 0 else 12, 0))
        if pasangan:
            kotak.current(0)
        kotak.daftar = pasangan
        if perintah:
            kotak.bind("<<ComboboxSelected>>", lambda e: perintah())
        return kotak

    def nilai_pilihan(self, kotak):
        """Mengambil nilai kedua dari pasangan yang dipilih."""
        return kotak.daftar[kotak.current()][1]

    def pilih_nilai(self, kotak, nilai):
        """Memilih baris combobox yang nilai keduanya sama dengan `nilai`."""
        for urutan, pasangan in enumerate(kotak.daftar):
            if pasangan[1] == nilai:
                kotak.current(urutan)
                return

    def kosongkan_isian(self, *kotak):
        """Mengosongkan beberapa kotak isian sekaligus."""
        for entri in kotak:
            entri.delete(0, "end")

    def angka_pecahan(self, entri, bawaan=0.0):
        """Membaca angka desimal, misal 0,05 atau 0.05."""
        try:
            teks = str(entri.get()).strip().replace(",", ".")
            return float(teks) if teks else bawaan
        except ValueError:
            return bawaan


def kartu(induk, judul):
    """Kotak putih bergaris, dipakai untuk mengelompokkan isi."""
    luar = tk.Frame(induk, bg=LATAR_KARTU, highlightbackground=GARIS,
                    highlightthickness=1)
    tk.Label(luar, text=judul, bg=LATAR_KARTU, fg=TEKS,
             font=("DejaVu Sans", 11, "bold")).pack(anchor="w", padx=12, pady=(10, 6))
    isi = tk.Frame(luar, bg=LATAR_KARTU)
    isi.pack(fill="both", expand=True, padx=12, pady=(0, 12))
    return luar, isi


def tabel(induk, kolom, lebar=None, tinggi=8):
    """Tabel bergaris (Treeview) dengan penggulung."""
    bingkai = ttk.Frame(induk)
    pohon = ttk.Treeview(bingkai, columns=kolom, show="headings", height=tinggi)

    for i, nama in enumerate(kolom):
        pohon.heading(nama, text=nama)
        lebar_kolom = (lebar[i] if lebar else 110)
        pohon.column(nama, width=lebar_kolom,
                     anchor="e" if lebar_kolom <= 90 else "w")

    gulir = ttk.Scrollbar(bingkai, orient="vertical", command=pohon.yview)
    pohon.configure(yscrollcommand=gulir.set)

    pohon.pack(side="left", fill="both", expand=True)
    gulir.pack(side="right", fill="y")

    pohon.tag_configure("total", background="#f2ece1")
    pohon.tag_configure("merah", foreground=MERAH)
    return bingkai, pohon


def kosongkan(pohon):
    """Menghapus semua baris tabel."""
    for baris in pohon.get_children():
        pohon.delete(baris)


# ------------------------------------------------------------
# 4. JENDELA MASUK
# ------------------------------------------------------------
class JendelaMasuk(tk.Frame):
    def __init__(self, induk, aplikasi):
        super().__init__(induk, bg=LATAR)
        self.aplikasi = aplikasi

        tengah = tk.Frame(self, bg=LATAR_KARTU, highlightbackground=GARIS,
                          highlightthickness=1)
        tengah.place(relx=0.5, rely=0.5, anchor="center")

        dalam = tk.Frame(tengah, bg=LATAR_KARTU)
        dalam.pack(padx=36, pady=30)

        logo = muat_logo(96)
        if logo is not None:
            tk.Label(dalam, image=logo, bg=LATAR_KARTU).pack(
                anchor="w", pady=(0, 6))

        tk.Label(dalam, text="SiKoi", bg=LATAR_KARTU, fg=AKSEN,
                 font=("DejaVu Sans", 22, "bold")).pack(anchor="w")
        tk.Label(dalam, text="Sistem Informasi Akuntansi\nBudidaya Ikan Koi",
                 bg=LATAR_KARTU, fg=TEKS_LEMAH, font=FONT_KECIL,
                 justify="left").pack(anchor="w", pady=(2, 18))

        daftar = hitung.ambil_semua("SELECT nama, jabatan FROM pengguna ORDER BY id")

        tk.Label(dalam, text="Nama", bg=LATAR_KARTU, fg=TEKS,
                 font=FONT_KECIL).pack(anchor="w")
        self.nama = ttk.Combobox(dalam, values=[p["nama"] for p in daftar],
                                 state="readonly", width=28)
        self.nama.pack(anchor="w", pady=(2, 10))
        if daftar:
            self.nama.current(0)

        tk.Label(dalam, text="Jabatan", bg=LATAR_KARTU, fg=TEKS,
                 font=FONT_KECIL).pack(anchor="w")
        self.jabatan = ttk.Combobox(dalam, values=["Owner", "Karyawan"],
                                    state="readonly", width=28)
        self.jabatan.pack(anchor="w", pady=(2, 10))
        self.jabatan.current(0)

        tk.Label(dalam, text="PIN", bg=LATAR_KARTU, fg=TEKS,
                 font=FONT_KECIL).pack(anchor="w")
        self.pin = ttk.Entry(dalam, show="*", width=30)
        self.pin.pack(anchor="w", pady=(2, 6))
        self.pin.bind("<Return>", lambda e: self.masuk())

        self.galat = tk.Label(dalam, text="", bg=LATAR_KARTU, fg=MERAH,
                              font=FONT_KECIL, wraplength=240, justify="left")
        self.galat.pack(anchor="w", pady=(0, 8))

        ttk.Button(dalam, text="Masuk", command=self.masuk).pack(fill="x", pady=(4, 10))

        tk.Label(dalam, text="Contoh akun:\nOwner  -> Pak Hadi / PIN 1234\n"
                             "Karyawan -> Mas Tono / PIN 5678",
                 bg=LATAR_KARTU, fg=TEKS_LEMAH, font=("DejaVu Sans", 8),
                 justify="left").pack(anchor="w")

    def masuk(self):
        pengguna = hitung.cek_login(
            self.nama.get().strip(), self.jabatan.get(), self.pin.get().strip())

        if not pengguna:
            self.galat.configure(text="Nama, jabatan, atau PIN tidak cocok.")
            return

        hitung.catat_login(pengguna["id"], pengguna["nama"], pengguna["jabatan"])
        hitung.catat_audit(
            "pengguna", "login", pengguna["id"],
            f"{pengguna['nama']} ({pengguna['jabatan']}) masuk",
            pengguna["nama"])

        self.aplikasi.sesi = {"nama": pengguna["nama"], "jabatan": pengguna["jabatan"]}
        self.aplikasi.tampilkan_utama()


# ------------------------------------------------------------
# 5. HALAMAN DASHBOARD
# ------------------------------------------------------------
class HalamanDashboard(Halaman):
    def __init__(self, induk, aplikasi):
        super().__init__(induk, aplikasi, "Dashboard")

        tab = ttk.Notebook(self.isi)
        tab.pack(fill="both", expand=True)

        # ---------- tab ringkasan ----------
        halaman = ttk.Frame(tab, padding=8)
        tab.add(halaman, text="Ringkasan")

        self.kotak = tk.Frame(halaman, bg=LATAR)
        self.kotak.pack(fill="x", pady=(0, 10))

        kartu_ringkasan = [
            ("stok", "STOK IKAN", "total ekor"),
            ("beli", "PEMBELIAN", "bibit + pakan"),
            ("jual", "PENJUALAN", "belum termasuk ongkir"),
            ("kas", "KAS + BANK", "uang yang tersedia"),
            ("utang", "UTANG", "semua tunai = Rp0"),
            ("piutang", "PIUTANG", "belum ada piutang"),
            ("laba", "LABA BERSIH", "setelah HPP dan beban"),
        ]
        self.nilai = {}
        for urutan, (kunci, label, catatan) in enumerate(kartu_ringkasan):
            baris = 0 if urutan < 4 else 1
            kolom = urutan if urutan < 4 else urutan - 4
            sel = tk.Frame(self.kotak, bg=LATAR_KARTU, highlightbackground=GARIS,
                           highlightthickness=1)
            sel.grid(row=baris, column=kolom, sticky="nsew",
                     padx=(0 if kolom == 0 else 8, 0),
                     pady=(0 if baris == 0 else 8, 0))
            self.kotak.columnconfigure(kolom, weight=1)

            tk.Label(sel, text=label, bg=LATAR_KARTU, fg=TEKS_LEMAH,
                     font=("DejaVu Sans", 8)).pack(anchor="w", padx=12,
                                                  pady=(10, 0))
            nilai = tk.Label(sel, text="-", bg=LATAR_KARTU, fg=TEKS,
                             font=FONT_ANGKA)
            nilai.pack(anchor="w", padx=12)
            tk.Label(sel, text=catatan, bg=LATAR_KARTU, fg=TEKS_LEMAH,
                     font=("DejaVu Sans", 8)).pack(anchor="w", padx=12,
                                                  pady=(0, 10))
            self.nilai[kunci] = nilai

        luar, isi = kartu(halaman, "Morning brief (pengingat otomatis)")
        luar.pack(fill="x", pady=(0, 10))
        self.peringatan = tk.Label(isi, text="", bg=LATAR_KARTU, fg=TEKS,
                                   font=FONT_KECIL, justify="left", anchor="w")
        self.peringatan.pack(fill="x")

        tombol = tk.Frame(isi, bg=LATAR_KARTU)
        tombol.pack(anchor="w", pady=(8, 0))
        ttk.Button(tombol, text="Penjualan Baru",
                   command=lambda: self.aplikasi.buka("penjualan")).pack(
            side="left")
        ttk.Button(tombol, text="Pembelian Baru",
                   command=lambda: self.aplikasi.buka("pembelian")).pack(
            side="left", padx=(8, 0))
        ttk.Button(tombol, text="Cetak Laporan",
                   command=lambda: self.aplikasi.buka("laporan")).pack(
            side="left", padx=(8, 0))
        ttk.Button(tombol, text="Ekspor Excel",
                   command=self.ekspor_excel).pack(side="left", padx=(8, 0))

        luar, isi = kartu(halaman, "Stok per ukuran dan per kolam")
        luar.pack(fill="both", expand=True)
        bingkai, self.tabel_stok = tabel(
            isi,
            ("Jenis", "Kolam", "Stok", "Minimum", "HPP", "Harga acuan",
             "Margin", "Umur (bln)"),
            (170, 70, 65, 70, 90, 100, 90, 80),
            tinggi=6,
        )
        bingkai.pack(fill="both", expand=True)

        # ---------- tab tambahan ----------
        halaman = ttk.Frame(tab, padding=8)
        tab.add(halaman, text="Tambahan")

        atas = tk.Frame(halaman, bg=LATAR)
        atas.pack(fill="x", pady=(0, 8))

        luar, isi = kartu(atas, "Komposisi kas dan biaya pakan")
        luar.pack(side="left", fill="both", expand=True)
        self.info_kas = tk.Label(isi, text="", bg=LATAR_KARTU, fg=TEKS,
                                 font=FONT_KECIL, justify="left", anchor="w")
        self.info_kas.pack(fill="x")

        luar, isi = kartu(atas, "Mortalitas per bulan")
        luar.pack(side="left", fill="both", expand=True, padx=(8, 0))
        bingkai, self.tabel_mati = tabel(
            isi, ("Bulan", "Ikan mati"), (120, 90), tinggi=4)
        bingkai.pack(fill="both", expand=True)

        luar, isi = kartu(halaman, "Grafik penjualan harian")
        luar.pack(fill="x", pady=(0, 8))
        self.grafik = tk.Canvas(isi, height=130, bg=LATAR_KARTU,
                                highlightthickness=0)
        self.grafik.pack(fill="x")

        luar, isi = kartu(halaman, "Lima ukuran terlaris")
        luar.pack(fill="both", expand=True)
        bingkai, self.tabel_laris = tabel(
            isi, ("Jenis", "Terjual", "Nilai"), (240, 90, 120), tinggi=5)
        bingkai.pack(fill="both", expand=True)

        self.muat()

    def muat(self):
        ringkasan = hitung.ringkasan_dashboard()
        persediaan, _ = hitung.nilai_persediaan()

        self.nilai["stok"].configure(
            text=f"{angka(ringkasan['stok_ekor'])} ekor")
        self.nilai["beli"].configure(text=angka(ringkasan["total_pembelian"]))
        self.nilai["jual"].configure(text=angka(ringkasan["total_penjualan"]))
        self.nilai["kas"].configure(text=angka(ringkasan["kas_bank"]))
        self.nilai["utang"].configure(text=angka(ringkasan["utang"]))
        self.nilai["piutang"].configure(text=angka(ringkasan["piutang"]))
        self.nilai["laba"].configure(
            text=akun(ringkasan["laba_bersih"]),
            fg=MERAH if ringkasan["laba_bersih"] < 0 else TEKS,
        )

        peringatan = []
        for b in persediaan:
            if b["stok"] <= b["stok_minimum"]:
                peringatan.append(
                    f"• Stok menipis: {b['nama']} tersisa {b['stok']} "
                    f"{b['satuan']} (batas minimum {b['stok_minimum']}).")

        sisa_pakan = hitung.pakan_sisa_bulan()
        peringatan.append(
            f"• Pakan: cukup sekitar {sisa_pakan:.0f} bulan lagi "
            f"(pemakaian {hitung.baca_kebijakan('pemakaian_pakan_bulanan_kg', '60')} kg/bulan).")

        hari = date.today().day
        if hari <= 10:
            peringatan.append(
                "• Jatuh tempo retribusi kolam tanggal 10: "
                "3 kolam x Rp125.000 = Rp375.000.")
        if hari >= 25:
            peringatan.append(
                "• Akhir bulan: waktunya stok opname dan jurnal penyesuaian.")

        if ringkasan["utang"] or ringkasan["piutang"]:
            peringatan.append(
                f"• Utang {rupiah(ringkasan['utang'])}, piutang "
                f"{rupiah(ringkasan['piutang'])} perlu ditindaklanjuti.")
        else:
            peringatan.append("• Utang dan piutang jatuh tempo: tidak ada.")

        siap_jual = [b for b in persediaan
                     if b["satuan"] == "ekor" and b["ukuran_cm"] >= 20
                     and b["stok"] > 0]
        momen = []
        for teks in (hitung.baca_kebijakan("momen_jual_tanggal", "") or "").split(","):
            try:
                tanggal_momen = date.fromisoformat(teks.strip())
            except ValueError:
                continue
            selisih = (tanggal_momen - date.today()).days
            if 0 <= selisih <= 60:
                momen.append(f"{teks.strip()} ({selisih} hari lagi)")
        if momen:
            peringatan.append(
                "• Pengingat momen jual " + ", ".join(momen) + ": "
                + (", ".join(f"{b['nama']} {b['stok']} ekor" for b in siap_jual)
                   if siap_jual else "belum ada stok 20 cm ke atas."))

        self.peringatan.configure(text="\n".join(peringatan))

        kosongkan(self.tabel_stok)
        for b in persediaan:
            if b["satuan"] != "ekor":
                continue
            margin = b["harga_jual"] - b["hpp"] if b["harga_jual"] else 0
            self.tabel_stok.insert(
                "", "end",
                values=(b["nama"], b["kolam"], b["stok"], b["stok_minimum"],
                        angka(b["hpp"]),
                        angka(b["harga_jual"]) if b["harga_jual"] else "-",
                        angka(margin) if b["harga_jual"] else "-",
                        hitung.estimasi_umur_bulan(b["ukuran_cm"])),
                tags=("merah",) if b["stok"] <= b["stok_minimum"] else (),
            )

        kas = hitung.komposisi_kas()
        self.info_kas.configure(
            text=(f"Kas        : {rupiah(kas['kas'])}\n"
                  f"Bank       : {rupiah(kas['bank'])}\n"
                  f"Kas kecil  : {rupiah(kas['kas_kecil'])}\n"
                  f"Total      : {rupiah(kas['kas'] + kas['bank'] + kas['kas_kecil'])}\n"
                  f"Biaya pakan: {hitung.biaya_pakan_persen()}% dari penjualan"))

        kosongkan(self.tabel_mati)
        for b in hitung.mortalitas_bulanan():
            self.tabel_mati.insert(
                "", "end", values=(b["bulan"], b["mati"]))

        kosongkan(self.tabel_laris)
        for b in hitung.lima_ukuran_terlaris():
            self.tabel_laris.insert(
                "", "end", values=(b["nama"], b["qty"], angka(b["nilai"])))

        self.gambar_grafik()

    def gambar_grafik(self):
        """Grafik batang sederhana tanpa library tambahan."""
        self.grafik.delete("all")
        data = hitung.penjualan_harian()
        if not data:
            self.grafik.create_text(10, 10, anchor="nw",
                                    text="Belum ada penjualan.",
                                    fill=TEKS_LEMAH,
                                    font=("DejaVu Sans", 9))
            return

        lebar = max(self.grafik.winfo_width(), 600)
        tinggi = 130
        margin_kiri = 40
        margin_bawah = 18
        puncak = max(int(b["total"]) for b in data) or 1
        jarak = (lebar - margin_kiri - 10) / max(len(data), 1)
        lebar_batang = max(min(jarak - 6, 40), 4)

        for urutan, b in enumerate(data):
            x = margin_kiri + urutan * jarak
            nilai = int(b["total"])
            panjang = (tinggi - margin_bawah - 10) * nilai / puncak
            self.grafik.create_rectangle(
                x, tinggi - margin_bawah - panjang,
                x + lebar_batang, tinggi - margin_bawah,
                fill=AKSEN, outline="")
            self.grafik.create_text(
                x + lebar_batang / 2, tinggi - 9,
                text=b["tanggal"][8:10], fill=TEKS_LEMAH,
                font=("DejaVu Sans", 7))
        self.grafik.create_text(
            6, 6, anchor="nw", text=angka(puncak), fill=TEKS_LEMAH,
            font=("DejaVu Sans", 7))

    def ekspor_excel(self):
        """Ekspor cepat dari Dashboard, tanpa membuka halaman Laporan."""
        try:
            berkas = ekspor_laporan_excel(self, self.aplikasi.sesi)
        except OSError as galat:
            messagebox.showerror("Ekspor Excel",
                                 f"Gagal menyimpan: {galat}", parent=self)
            return

        if berkas:
            messagebox.showinfo(
                "Ekspor Excel",
                f"Laporan keuangan disimpan ke\n{berkas}", parent=self)


# ------------------------------------------------------------
# 6. HALAMAN PENJUALAN
# ------------------------------------------------------------
class HalamanPenjualan(Halaman):
    def __init__(self, induk, aplikasi):
        super().__init__(induk, aplikasi, "Penjualan")

        luar, isi = kartu(self.isi, "Stok siap jual")
        luar.pack(fill="x", pady=(0, 10))

        tk.Label(isi, text="Ukuran boleh diketik langsung. Ikan yang dijual "
                           "harus sudah punya stok dari halaman Pembelian; "
                           "harga deal tetap kesepakatan dengan pembeli. "
                           "Berat per ekor terisi dari data barang; ubah kalau "
                           "hasil timbangan berbeda karena berat inilah yang "
                           "menentukan ongkir.",
                 bg=LATAR_KARTU, fg=TEKS_LEMAH, font=("DejaVu Sans", 8),
                 wraplength=760, justify="left").pack(anchor="w", pady=(0, 6))

        bingkai, self.tabel_stok = tabel(
            isi,
            ("Kode", "Jenis", "Stok", "HPP/ekor", "Harga acuan", "Berat/ekor"),
            (80, 190, 80, 100, 110, 100),
            tinggi=4,
        )
        bingkai.pack(fill="x")

        luar, isi = kartu(self.isi, "Penjualan baru")
        luar.pack(fill="both", expand=True)

        baris = tk.Frame(isi, bg=LATAR_KARTU)
        baris.pack(fill="x", pady=(0, 10))

        self.tanggal = self._isian(baris, "Tanggal", 0, lebar=12)
        self.tanggal.insert(0, date.today().isoformat())

        pelanggan = hitung.ambil_semua("SELECT * FROM pelanggan ORDER BY kode")
        self.pelanggan = self._pilihan(
            baris, "Pembeli", 1, [(p["nama"], p["id"]) for p in pelanggan])

        self.kas = self._pilihan(
            baris, "Uang masuk ke", 2,
            [("Kas", hitung.id_akun(AKUN_KAS)),
             ("Bank", hitung.id_akun(AKUN_BANK))])

        self.cara = self._pilihan(
            baris, "Pengiriman", 3,
            [("Ambil sendiri", "ambil"), ("Dikirim", "kirim")], perintah=self.hitung_ulang)

        self.zona = self._pilihan(
            baris, "Zona kirim", 4,
            [("Dekat", "dekat"), ("Sedang", "sedang"), ("Jauh", "jauh")],
            perintah=self.hitung_ulang)

        tk.Label(isi, text="Tambah ikan yang dijual", bg=LATAR_KARTU, fg=TEKS,
                 font=("DejaVu Sans", 10, "bold")).pack(anchor="w", pady=(6, 4))

        # Satu baris penjualan: ukuran, jumlah, dan harga deal.
        # Daftar ukuran diisi dari database, bukan dari daftar tetap di kode.
        tambah = tk.Frame(isi, bg=LATAR_KARTU)
        tambah.pack(fill="x")

        tk.Label(tambah, text="Ukuran (cm)", bg=LATAR_KARTU, fg=TEKS_LEMAH,
                 font=("DejaVu Sans", 8)).grid(row=0, column=0, sticky="w")
        self.ukuran = ttk.Combobox(tambah, width=8)
        self.ukuran.grid(row=1, column=0, sticky="w")
        self.ukuran.bind("<<ComboboxSelected>>", lambda e: self.isi_berat())

        self.qty = self._isian(tambah, "Jumlah (ekor)", 1, lebar=8)
        self.harga = self._isian(tambah, "Harga deal/ekor", 2, lebar=12)
        self.berat = self._isian(tambah, "Berat/ekor (kg)", 3, lebar=8)

        ttk.Button(tambah, text="Tambah baris",
                   command=self.tambah_baris).grid(row=1, column=4, sticky="w",
                                                   padx=(12, 0))

        bingkai, self.tabel_rincian = tabel(
            isi, ("Ukuran", "Jumlah", "Berat/ekor", "Harga/ekor", "Subtotal"),
            (110, 80, 90, 120, 140), tinggi=4)
        bingkai.pack(fill="x", pady=(10, 0))

        self.total = tk.Label(isi, text="", bg="#f2ece1", fg=TEKS, font=FONT_KECIL,
                              anchor="w", padx=10, pady=6)
        self.total.pack(fill="x", pady=(8, 6))

        aksi = tk.Frame(isi, bg=LATAR_KARTU)
        aksi.pack(fill="x")
        ttk.Button(aksi, text="Hapus baris",
                   command=self.hapus_baris).pack(side="left")
        ttk.Button(aksi, text="Simpan penjualan",
                   command=self.simpan).pack(side="left", padx=(8, 0))

        # Riwayat penjualan: bagian "Read" dan "Delete" dari CRUD.
        luar, isi = kartu(self.isi, "Penjualan terakhir")
        luar.pack(fill="both", expand=True, pady=(10, 0))

        bingkai, self.tabel_riwayat = tabel(
            isi, ("Tanggal", "Bukti", "Pembeli", "Ekor", "Nilai"),
            (110, 90, 230, 80, 120), tinggi=4)
        bingkai.pack(fill="both", expand=True)

        self.tombol_void = ttk.Button(isi, text="Batalkan penjualan terpilih",
                                      command=self.void)
        self.tombol_void.pack(anchor="w", pady=(8, 0))
        if self.aplikasi.sesi["jabatan"] != "Owner":
            self.tombol_void.pack_forget()

        # Baris yang sedang disusun pengguna, belum disimpan ke database.
        self.baris = []
        self.muat()

    # --- menyusun baris penjualan ---
    def isi_berat(self):
        """Mengisi berat per ekor dari data barang saat ukuran dipilih."""
        cocok = re.search(r"\d+", teks_dari(self.ukuran))
        if not cocok:
            return
        barang = hitung.barang_ukuran(int(cocok.group()))
        if barang is None:
            return
        self.kosongkan_isian(self.berat)
        self.berat.insert(0, f"{barang['berat']:.2f}")

    def tambah_baris(self):
        cocok = re.search(r"\d+", teks_dari(self.ukuran))
        if not cocok:
            self.kabar("Isi ukuran ikan dalam cm, misal 20.", berhasil=False)
            return

        cm = int(cocok.group())
        barang = hitung.barang_ukuran(cm)
        if barang is None:
            self.kabar(f"Ukuran {cm} cm belum punya stok. Catat pembeliannya "
                       "dulu supaya HPP dan stoknya benar.", berhasil=False)
            return

        qty = bulat_dari(self.qty)
        harga = bulat_dari(self.harga)
        if qty <= 0:
            self.kabar("Jumlah ekor harus lebih dari nol.", berhasil=False)
            return
        if harga <= 0:
            self.kabar("Harga deal per ekor harus diisi.", berhasil=False)
            return

        # Berat boleh dikoreksi sesuai timbangan; kalau kosong, pakai
        # berat standar barang supaya ongkir tetap bisa dihitung.
        berat = self.angka_pecahan(self.berat, None)
        if berat is None or berat <= 0:
            berat = barang["berat"]

        # Stok yang tersisa dikurangi baris yang sudah ada di daftar.
        sudah = sum(b["qty"] for b in self.baris
                    if b["barang_id"] == barang["id"])
        sisa = hitung.stok_sekarang(barang["id"]) - sudah
        if qty > sisa:
            self.kabar(f"Stok {barang['nama']} tinggal {sisa} ekor.", berhasil=False)
            return

        self.baris.append({
            "barang_id": barang["id"],
            "cm": cm,
            "qty": qty,
            "harga": harga,
            "hpp": barang["hpp"],
            "berat": berat,
        })

        self.kosongkan_isian(self.ukuran, self.qty, self.harga, self.berat)
        self.tampilkan_rincian()
        self.hitung_ulang()

    def hapus_baris(self):
        terpilih = self.tabel_rincian.selection()
        if not terpilih:
            self.kabar("Pilih baris pada rincian yang ingin dihapus.", berhasil=False)
            return
        urutan = self.tabel_rincian.index(terpilih[0])
        del self.baris[urutan]
        self.tampilkan_rincian()
        self.hitung_ulang()

    def tampilkan_rincian(self):
        kosongkan(self.tabel_rincian)
        for b in self.baris:
            self.tabel_rincian.insert(
                "", "end",
                values=(f"{b['cm']} cm", b["qty"], f"{b['berat']:.2f}",
                        angka(b["harga"]), angka(b["qty"] * b["harga"])))

    # --- hitungan di layar ---
    def hitung_ulang(self):
        total_ikan = sum(b["qty"] for b in self.baris)
        total_berat = sum(b["qty"] * b["berat"] for b in self.baris)
        total_jual = sum(b["qty"] * b["harga"] for b in self.baris)

        ongkir = hitung_ongkir(self.nilai_pilihan(self.cara),
                               self.nilai_pilihan(self.zona), total_berat)

        if not self.baris:
            self.total.configure(
                text="Belum ada baris. Isi ukuran, jumlah, dan harga, "
                     "lalu tekan Tambah baris.")
            return

        self.total.configure(
            text=f"Total {total_ikan} ekor  |  berat {total_berat:.2f} kg  |  "
                 f"nilai {rupiah(total_jual)}  |  ongkir {rupiah(ongkir)}  |  "
                 f"DITAGIHKAN {rupiah(total_jual + ongkir)}"
        )

    def muat(self):
        kosongkan(self.tabel_stok)
        daftar = hitung.ambil_semua(
            "SELECT * FROM barang WHERE satuan = 'ekor' ORDER BY ukuran_cm, kode")

        for b in daftar:
            sisa = hitung.stok_sekarang(b["id"])
            self.tabel_stok.insert(
                "", "end",
                values=(b["kode"], b["nama"], f"{sisa} ekor", angka(b["hpp"]),
                        angka(b["harga_jual"]), f"{b['berat']:.2f}"),
                tags=("merah",) if sisa <= b["stok_minimum"] else (),
            )

        # Pilihan ukuran ikut berubah kalau ada ukuran baru dari Pembelian.
        self.ukuran.configure(
            values=[str(b["ukuran_cm"]) for b in daftar if b["ukuran_cm"] > 0])

        kosongkan(self.tabel_riwayat)
        for t in hitung.ambil_semua(
            """SELECT t.no_bukti, t.tanggal, t.ongkir,
                      COALESCE(p.nama, '-') AS pembeli,
                      COALESCE(SUM(tb.qty), 0) AS ekor,
                      COALESCE(SUM(tb.qty * tb.harga_satuan), 0) AS nilai
                 FROM transaksi t
                 LEFT JOIN pelanggan p ON p.id = t.pelanggan_id
                 LEFT JOIN transaksi_baris tb ON tb.transaksi_id = t.id
                WHERE t.jenis = 'penjualan'
                GROUP BY t.id
                ORDER BY t.tanggal DESC, t.id DESC
                LIMIT 15"""):
            self.tabel_riwayat.insert(
                "", "end",
                values=(tanggal_rapi(t["tanggal"]), t["no_bukti"], t["pembeli"],
                        f"{t['ekor']} ekor", angka(t["nilai"] + t["ongkir"])))

        self.hitung_ulang()

    def simpan(self):
        if not self.baris:
            self.kabar("Tambahkan minimal satu baris ikan yang dijual.", berhasil=False)
            return

        # Peringatan kalau harga deal di bawah HPP (rancangan 4.4).
        rugi = [b for b in self.baris if b["harga"] < b.get("hpp", 0)]
        if rugi:
            rincian = "\n".join(
                f"- {b['cm']} cm: harga {rupiah(b['harga'])}, "
                f"HPP {rupiah(b['hpp'])}" for b in rugi)
            if not messagebox.askyesno(
                "Harga di bawah HPP",
                "Ada harga deal yang lebih rendah dari HPP:\n"
                f"{rincian}\n\nTetap simpan penjualan ini?"):
                return

        total_berat = sum(b["qty"] * b["berat"] for b in self.baris)
        daftar_baris = [{"barang_id": b["barang_id"], "qty": b["qty"],
                         "harga": b["harga"]} for b in self.baris]

        ongkir = hitung_ongkir(self.nilai_pilihan(self.cara),
                               self.nilai_pilihan(self.zona), total_berat)

        no_bukti = hitung.simpan_penjualan(
            teks_dari(self.tanggal),
            self.nilai_pilihan(self.pelanggan),
            self.nilai_pilihan(self.kas),
            "",
            ongkir,
            daftar_baris,
            self.aplikasi.sesi["nama"],
            berat_paket=total_berat,
        )

        self.kabar(f"Penjualan {no_bukti} tersimpan. Ongkir {rupiah(ongkir)}.")
        self.baris = []
        self.tampilkan_rincian()
        self.muat()
        self.aplikasi.segarkan_semua()

    def void(self):
        terpilih = self.tabel_riwayat.selection()
        if not terpilih:
            self.kabar("Pilih penjualan yang ingin dibatalkan.", berhasil=False)
            return

        if self.aplikasi.sesi["jabatan"] != "Owner":
            self.kabar("Hanya Owner yang boleh membatalkan transaksi lama.",
                       berhasil=False)
            return

        nilai = self.tabel_riwayat.item(terpilih[0], "values")
        no_bukti = nilai[1]

        if not messagebox.askyesno(
            "Batalkan Penjualan",
            f"Batalkan penjualan {no_bukti}?\n\nStok ikan akan kembali dan "
            "jurnal penjualan dihapus. Kalau salah isi, catat ulang setelah ini.",
        ):
            return

        try:
            hitung.void_penjualan(no_bukti, self.aplikasi.sesi["jabatan"])
        except (ValueError, PermissionError) as galat:
            self.kabar(str(galat), berhasil=False)
            return

        self.kabar(f"Penjualan {no_bukti} dibatalkan. Stok sudah kembali.")
        self.muat()
        self.aplikasi.segarkan_semua()


# ------------------------------------------------------------
# 7. HALAMAN PEMBELIAN
# ------------------------------------------------------------
class HalamanPembelian(Halaman):
    def __init__(self, induk, aplikasi):
        super().__init__(induk, aplikasi, "Pembelian")

        luar, isi = kartu(self.isi, "HPP rata-rata saat ini")
        luar.pack(fill="x", pady=(0, 10))

        bingkai, self.tabel_hpp = tabel(
            isi, ("Kode", "Barang", "Stok", "HPP", "Nilai stok"),
            (80, 200, 100, 110, 120), tinggi=5)
        bingkai.pack(fill="x")

        luar, isi = kartu(self.isi, "Pembelian baru")
        luar.pack(fill="both", expand=True)

        baris = tk.Frame(isi, bg=LATAR_KARTU)
        baris.pack(fill="x", pady=(0, 10))

        self.tanggal = self._isian(baris, "Tanggal", 0, lebar=12)
        self.tanggal.insert(0, date.today().isoformat())

        pemasok = hitung.ambil_semua("SELECT * FROM pemasok ORDER BY kode")
        self.pemasok = self._pilihan(
            baris, "Pemasok", 1, [(p["nama"], p["id"]) for p in pemasok])

        self.kas = self._pilihan(
            baris, "Dibayar dari", 2,
            [("Kas", hitung.id_akun(AKUN_KAS)),
             ("Bank", hitung.id_akun(AKUN_BANK))])

        tk.Label(isi, text="Tambah barang yang dibeli", bg=LATAR_KARTU, fg=TEKS,
                 font=("DejaVu Sans", 10, "bold")).pack(anchor="w", pady=(6, 4))

        # Barang dipilih dari database. Kalau ukuran ikan belum ada,
        # pilih "Ukuran ikan baru" lalu ketik cm-nya.
        tambah = tk.Frame(isi, bg=LATAR_KARTU)
        tambah.pack(fill="x")

        tk.Label(tambah, text="Barang", bg=LATAR_KARTU, fg=TEKS_LEMAH,
                 font=("DejaVu Sans", 8)).grid(row=0, column=0, sticky="w")
        self.barang = ttk.Combobox(tambah, state="readonly", width=32)
        self.barang.grid(row=1, column=0, sticky="w")
        self.barang.bind("<<ComboboxSelected>>", lambda e: self.ganti_barang())

        self.cm = self._isian(tambah, "Ukuran baru (cm)", 1, lebar=8)
        self.qty = self._isian(tambah, "Jumlah", 2, lebar=8)
        self.harga = self._isian(tambah, "Harga/satuan", 3, lebar=12)
        self.berat = self._isian(tambah, "Berat/ekor (kg)", 4, lebar=8)

        ttk.Button(tambah, text="Tambah baris",
                   command=self.tambah_baris).grid(row=1, column=5, sticky="w",
                                                   padx=(12, 0))

        bingkai, self.tabel_rincian = tabel(
            isi, ("Barang", "Jumlah", "Harga/satuan", "Subtotal"),
            (220, 90, 130, 140), tinggi=4)
        bingkai.pack(fill="x", pady=(10, 0))

        aksi = tk.Frame(isi, bg=LATAR_KARTU)
        aksi.pack(fill="x", pady=(8, 0))
        ttk.Button(aksi, text="Hapus baris",
                   command=self.hapus_baris).pack(side="left")
        ttk.Button(aksi, text="Simpan pembelian",
                   command=self.simpan).pack(side="left", padx=(8, 0))

        # --- pembelian indukan (aset biologis, bukan barang dagang) ---
        luar, isi = kartu(self.isi, "Pembelian indukan koi (aset)")
        luar.pack(fill="x", pady=(10, 0))
        baris = tk.Frame(isi, bg=LATAR_KARTU)
        baris.pack(fill="x")
        self.ind_tanggal = self._isian(baris, "Tanggal", 0, lebar=12)
        self.ind_tanggal.insert(0, date.today().isoformat())
        self.ind_jumlah = self._isian(baris, "Nilai (Rp)", 1, lebar=12)
        self.ind_ket = self._isian(baris, "Keterangan", 2, lebar=34)
        self.ind_ket.insert(0, "Beli indukan koi")
        ttk.Button(isi, text="Simpan pembelian indukan",
                   command=self.simpan_indukan).pack(anchor="w", pady=(10, 0))

        # Riwayat pembelian: bagian "Read" dan "Delete" dari CRUD.
        luar, isi = kartu(self.isi, "Pembelian terakhir")
        luar.pack(fill="both", expand=True, pady=(10, 0))

        bingkai, self.tabel_riwayat = tabel(
            isi, ("Tanggal", "Bukti", "Pemasok", "Jumlah", "Nilai"),
            (110, 90, 230, 80, 120), tinggi=4)
        bingkai.pack(fill="both", expand=True)

        self.tombol_void = ttk.Button(isi, text="Batalkan pembelian terpilih",
                                      command=self.void)
        self.tombol_void.pack(anchor="w", pady=(8, 0))
        if self.aplikasi.sesi["jabatan"] != "Owner":
            self.tombol_void.pack_forget()

        self.baris = []
        self.pilihan_barang = []
        self.daftar_barang = []
        self.muat()

    def ganti_barang(self):
        """Mengaktifkan kolom ukuran hanya saat memilih ukuran baru."""
        if not self.pilihan_barang:
            return
        urutan = self.barang.current()
        barang_id = self.pilihan_barang[urutan][1]

        if barang_id is None:
            self.cm.configure(state="normal")
            self.kosongkan_isian(self.harga)
            self.harga.insert(0, "0")
            return

        self.cm.configure(state="disabled")
        self.kosongkan_isian(self.cm)
        barang = next((b for b in self.daftar_barang if b["id"] == barang_id), None)
        if barang:
            self.kosongkan_isian(self.harga)
            self.harga.insert(0, str(barang["hpp"]))

    def tambah_baris(self):
        if not self.pilihan_barang:
            self.kabar("Belum ada barang. Tambahkan dulu di Data Master.",
                       berhasil=False)
            return

        urutan = self.barang.current()
        if urutan < 0:
            self.kabar("Pilih barang yang dibeli.", berhasil=False)
            return

        label, barang_id = self.pilihan_barang[urutan][0], self.pilihan_barang[urutan][1]
        qty = bulat_dari(self.qty)
        harga = bulat_dari(self.harga)

        if qty <= 0 or harga <= 0:
            self.kabar("Jumlah dan harga harus lebih dari nol.", berhasil=False)
            return

        if barang_id is None:
            cocok = re.search(r"\d+", teks_dari(self.cm))
            if not cocok:
                self.kabar("Isi ukuran ikan baru dalam cm, misal 25.",
                           berhasil=False)
                return
            cm = int(cocok.group())
            berat = self.angka_pecahan(self.berat, None)
            self.baris.append({
                "barang_id": None,
                "cm": cm,
                "nama": f"Koi Kohaku {cm} cm (baru)",
                "qty": qty,
                "harga": harga,
                "berat": berat,
            })
        else:
            barang = hitung.ambil_satu("SELECT * FROM barang WHERE id = ?",
                                       (barang_id,))
            self.baris.append({
                "barang_id": barang_id,
                "cm": barang["ukuran_cm"],
                "nama": barang["nama"],
                "qty": qty,
                "harga": harga,
                "berat": None,
            })

        self.kosongkan_isian(self.cm, self.qty, self.harga, self.berat)
        self.tampilkan_rincian()

    def hapus_baris(self):
        terpilih = self.tabel_rincian.selection()
        if not terpilih:
            self.kabar("Pilih baris pada rincian yang ingin dihapus.", berhasil=False)
            return
        del self.baris[self.tabel_rincian.index(terpilih[0])]
        self.tampilkan_rincian()

    def tampilkan_rincian(self):
        kosongkan(self.tabel_rincian)
        for b in self.baris:
            self.tabel_rincian.insert(
                "", "end",
                values=(b["nama"], b["qty"], angka(b["harga"]),
                        angka(b["qty"] * b["harga"])))

    def muat(self):
        self.daftar_barang = hitung.ambil_semua("SELECT * FROM barang ORDER BY kode")
        pilihan_lama = self.barang.get()

        kosongkan(self.tabel_hpp)
        for b in self.daftar_barang:
            sisa = hitung.stok_sekarang(b["id"])
            self.tabel_hpp.insert(
                "", "end",
                values=(b["kode"], b["nama"], f"{sisa} {b['satuan']}",
                        angka(b["hpp"]), angka(sisa * b["hpp"])),
            )

        self.pilihan_barang = [
            (f"{b['kode']} · {b['nama']} ({b['satuan']})", b["id"])
            for b in self.daftar_barang]
        self.pilihan_barang.append(("＋ Ukuran ikan baru", None))

        self.barang.configure(values=[p[0] for p in self.pilihan_barang])
        if pilihan_lama in [p[0] for p in self.pilihan_barang]:
            self.barang.set(pilihan_lama)
        elif self.pilihan_barang:
            self.barang.current(0)
        self.ganti_barang()

        kosongkan(self.tabel_riwayat)
        for t in hitung.ambil_semua(
            """SELECT t.no_bukti, t.tanggal,
                      COALESCE(p.nama, '-') AS pemasok,
                      COALESCE(SUM(tb.qty), 0) AS qty,
                      COALESCE(SUM(tb.qty * tb.harga_satuan), 0) AS nilai
                 FROM transaksi t
                 LEFT JOIN pemasok p ON p.id = t.pemasok_id
                 LEFT JOIN transaksi_baris tb ON tb.transaksi_id = t.id
                WHERE t.jenis = 'pembelian'
                GROUP BY t.id
                ORDER BY t.tanggal DESC, t.id DESC
                LIMIT 15"""):
            self.tabel_riwayat.insert(
                "", "end",
                values=(tanggal_rapi(t["tanggal"]), t["no_bukti"], t["pemasok"],
                        t["qty"], angka(t["nilai"])))

    def simpan(self):
        if not self.baris:
            self.kabar("Tambahkan minimal satu baris pembelian.", berhasil=False)
            return

        # Barang ukuran baru dibuat saat disimpan, supaya tidak ada
        # barang kosong kalau pengguna membatalkan pembelian.
        gabung = {}
        for b in self.baris:
            barang_id = b["barang_id"]
            if barang_id is None:
                barang = hitung.barang_ukuran(b["cm"])
                if barang is None:
                    barang_id = hitung.buat_barang_ukuran(
                        b["cm"], b["harga"], b["berat"])
                else:
                    barang_id = barang["id"]

            kunci = (barang_id, b["harga"])
            if kunci in gabung:
                gabung[kunci]["qty"] += b["qty"]
            else:
                gabung[kunci] = {"barang_id": barang_id,
                                 "qty": b["qty"], "harga": b["harga"]}

        no_bukti = hitung.simpan_pembelian(
            teks_dari(self.tanggal),
            self.nilai_pilihan(self.pemasok),
            self.nilai_pilihan(self.kas),
            "",
            list(gabung.values()),
            self.aplikasi.sesi["nama"],
        )

        self.kabar(f"Pembelian {no_bukti} tersimpan. Stok dan HPP diperbarui.")
        self.baris = []
        self.tampilkan_rincian()
        self.muat()
        self.aplikasi.segarkan_semua()

    def simpan_indukan(self):
        jumlah = bulat_dari(self.ind_jumlah)
        if jumlah <= 0:
            self.kabar("Nilai pembelian indukan harus lebih dari nol.",
                       berhasil=False)
            return
        try:
            no_bukti = hitung.simpan_pembelian_indukan(
                teks_dari(self.ind_tanggal),
                self.nilai_pilihan(self.pemasok),
                self.nilai_pilihan(self.kas),
                jumlah,
                teks_dari(self.ind_ket),
                self.aplikasi.sesi["nama"])
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return
        self.kabar(f"Pembelian indukan {no_bukti} tersimpan.")
        self.kosongkan_isian(self.ind_jumlah, self.ind_ket)
        self.muat()
        self.aplikasi.segarkan_semua()

    def void(self):
        terpilih = self.tabel_riwayat.selection()
        if not terpilih:
            self.kabar("Pilih pembelian yang ingin dibatalkan.", berhasil=False)
            return

        if self.aplikasi.sesi["jabatan"] != "Owner":
            self.kabar("Hanya Owner yang boleh membatalkan transaksi lama.",
                       berhasil=False)
            return

        nilai = self.tabel_riwayat.item(terpilih[0], "values")
        no_bukti = nilai[1]

        if not messagebox.askyesno(
            "Batalkan Pembelian",
            f"Batalkan pembelian {no_bukti}?\n\nStok akan berkurang kembali dan "
            "HPP rata-rata dihitung ulang dari pembelian yang tersisa.",
        ):
            return

        try:
            hitung.void_pembelian(no_bukti, self.aplikasi.sesi["jabatan"])
        except (ValueError, PermissionError) as galat:
            self.kabar(str(galat), berhasil=False)
            return

        self.kabar(f"Pembelian {no_bukti} dibatalkan. HPP sudah dihitung ulang.")
        self.muat()
        self.aplikasi.segarkan_semua()


# ------------------------------------------------------------
# 8. HALAMAN KAS
# ------------------------------------------------------------
class HalamanKas(Halaman):
    def __init__(self, induk, aplikasi):
        super().__init__(induk, aplikasi, "Kas Keluar dan Masuk")

        luar, isi = kartu(self.isi, "Catat kas")
        luar.pack(fill="x", pady=(0, 10))

        baris = tk.Frame(isi, bg=LATAR_KARTU)
        baris.pack(fill="x", pady=(0, 10))

        self.jenis = self._pilihan(baris, "Jenis", 0,
                                   [("Kas keluar (beban)", "keluar"),
                                    ("Kas masuk (modal)", "masuk")])
        self.jenis.bind("<<ComboboxSelected>>", lambda e: self.ganti_jenis())

        self.tanggal = self._isian(baris, "Tanggal", 1, lebar=12)
        self.tanggal.insert(0, date.today().isoformat())

        beban = hitung.ambil_semua(
            "SELECT * FROM akun WHERE kelompok = 'Beban' ORDER BY no_akun")
        self.beban = self._pilihan(baris, "Beban untuk", 2,
                                   [(a["nama"], a["id"]) for a in beban])

        self.kas = self._pilihan(baris, "Kas / bank", 3,
                                 [("Kas", hitung.id_akun(AKUN_KAS)),
                                  ("Bank", hitung.id_akun(AKUN_BANK))])

        self.jumlah = self._isian(baris, "Jumlah (Rp)", 4, lebar=14)
        self.ket = self._isian(baris, "Keterangan", 5, lebar=30)

        aksi = tk.Frame(isi, bg=LATAR_KARTU)
        aksi.pack(anchor="w")
        ttk.Button(aksi, text="Simpan baru",
                   command=self.simpan).pack(side="left")
        ttk.Button(aksi, text="Simpan perubahan",
                   command=self.ubah).pack(side="left", padx=(8, 0))
        ttk.Button(aksi, text="Bersihkan",
                   command=self.bersihkan_form).pack(side="left", padx=(8, 0))

        luar, isi = kartu(self.isi, "Catatan terakhir")
        luar.pack(fill="both", expand=True)

        bingkai, self.tabel_catatan = tabel(
            isi, ("Tanggal", "Bukti", "Jenis", "Keterangan", "Jumlah"),
            (110, 90, 100, 260, 120), tinggi=8)
        bingkai.pack(fill="both", expand=True)

        # Memilih baris mengisi formulir, supaya bisa langsung diubah.
        self.tabel_catatan.bind("<<TreeviewSelect>>", lambda e: self.pilih_baris())
        self.no_bukti_terpilih = None

        baris_aksi = tk.Frame(isi, bg=LATAR_KARTU)
        baris_aksi.pack(fill="x", pady=(8, 0))
        ttk.Button(baris_aksi, text="Hapus yang dipilih",
                   command=self.hapus).pack(anchor="w")

        self.muat()

    def ganti_jenis(self):
        """Beban hanya relevan untuk kas keluar."""
        if self.jenis.get().startswith("Kas masuk"):
            self.beban.configure(state="disabled")
        else:
            self.beban.configure(state="readonly")

    def muat(self):
        kosongkan(self.tabel_catatan)

        catatan = hitung.ambil_semua(
            """SELECT t.*,
                      (SELECT COALESCE(SUM(j.debit), 0) FROM jurnal j
                        WHERE j.no_bukti = t.no_bukti AND j.akun_id = t.akun_kas_id) AS debit_kas,
                      (SELECT COALESCE(SUM(j.kredit), 0) FROM jurnal j
                        WHERE j.no_bukti = t.no_bukti AND j.akun_id = t.akun_kas_id) AS kredit_kas
                 FROM transaksi t
                WHERE t.jenis IN ('pengeluaran_kas', 'penerimaan_kas')
                ORDER BY t.tanggal DESC, t.id DESC
                LIMIT 20""")

        for c in catatan:
            masuk = c["debit_kas"] > 0
            jumlah = c["debit_kas"] if masuk else c["kredit_kas"]
            self.tabel_catatan.insert(
                "", "end",
                values=(tanggal_rapi(c["tanggal"]), c["no_bukti"],
                        "Kas masuk" if masuk else "Kas keluar",
                        c["keterangan"], ("+" if masuk else "-") + angka(jumlah)),
            )

    def pilih_baris(self):
        """Mengisi formulir dari transaksi yang dipilih di tabel."""
        terpilih = self.tabel_catatan.selection()
        if not terpilih:
            return

        no_bukti = self.tabel_catatan.item(terpilih[0], "values")[1]
        transaksi = hitung.ambil_satu(
            "SELECT * FROM transaksi WHERE no_bukti = ?", (no_bukti,))
        jurnal = hitung.ambil_semua(
            "SELECT * FROM jurnal WHERE no_bukti = ?", (no_bukti,))

        if transaksi is None or not jurnal:
            return

        debit = next((j for j in jurnal if j["debit"] > 0), None)
        kredit = next((j for j in jurnal if j["kredit"] > 0), None)
        if debit is None or kredit is None:
            return

        masuk = debit["akun_id"] == transaksi["akun_kas_id"]
        akun_lawan = kredit["akun_id"] if masuk else debit["akun_id"]
        jumlah = debit["debit"] if masuk else kredit["kredit"]

        self.no_bukti_terpilih = no_bukti
        self.tanggal.delete(0, "end")
        self.tanggal.insert(0, transaksi["tanggal"])
        self.pilih_nilai(self.jenis, "masuk" if masuk else "keluar")
        self.ganti_jenis()
        self.pilih_nilai(self.kas, transaksi["akun_kas_id"])
        self.pilih_nilai(self.beban, akun_lawan)
        self.jumlah.delete(0, "end")
        self.jumlah.insert(0, str(jumlah))
        self.ket.delete(0, "end")
        self.ket.insert(0, transaksi["keterangan"] or "")

    def bersihkan_form(self):
        """Mengosongkan formulir dan melepas pilihan tabel."""
        self.no_bukti_terpilih = None
        self.tanggal.delete(0, "end")
        self.tanggal.insert(0, date.today().isoformat())
        self.pilih_nilai(self.jenis, "keluar")
        self.ganti_jenis()
        self.kosongkan_isian(self.jumlah, self.ket)
        for baris in self.tabel_catatan.selection():
            self.tabel_catatan.selection_remove(baris)

    def ubah(self):
        """Menyimpan perubahan pada transaksi kas yang sedang dipilih."""
        if not self.no_bukti_terpilih:
            self.kabar("Pilih dulu transaksi pada tabel yang ingin diubah.",
                       berhasil=False)
            return

        jumlah = bulat_dari(self.jumlah)
        if jumlah <= 0:
            self.kabar("Jumlah harus lebih dari nol.", berhasil=False)
            return

        masuk = self.nilai_pilihan(self.jenis) == "masuk"
        akun_lawan = (hitung.id_akun(AKUN_MODAL) if masuk
                      else self.nilai_pilihan(self.beban))

        try:
            hitung.ubah_transaksi_kas(
                self.no_bukti_terpilih, teks_dari(self.tanggal),
                "masuk" if masuk else "keluar", akun_lawan,
                self.nilai_pilihan(self.kas), jumlah,
                teks_dari(self.ket), self.aplikasi.sesi["nama"])
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return

        self.kabar(f"Transaksi {self.no_bukti_terpilih} berhasil diubah.")
        self.bersihkan_form()
        self.muat()
        self.aplikasi.segarkan_semua()

    def simpan(self):
        jumlah = bulat_dari(self.jumlah)

        if jumlah <= 0:
            self.kabar("Jumlah harus lebih dari nol.", berhasil=False)
            return

        if self.nilai_pilihan(self.jenis) == "masuk":
            no_bukti = hitung.simpan_penerimaan(
                teks_dari(self.tanggal), self.nilai_pilihan(self.kas),
                hitung.id_akun(AKUN_MODAL), jumlah,
                teks_dari(self.ket), self.aplikasi.sesi["nama"])
            self.kabar(f"Penerimaan kas {no_bukti} tersimpan.")
        else:
            no_bukti = hitung.simpan_pengeluaran(
                teks_dari(self.tanggal), self.nilai_pilihan(self.beban),
                self.nilai_pilihan(self.kas), jumlah,
                teks_dari(self.ket), self.aplikasi.sesi["nama"])
            self.kabar(f"Pengeluaran kas {no_bukti} tersimpan.")

        self.bersihkan_form()
        self.muat()
        self.aplikasi.segarkan_semua()

    def hapus(self):
        terpilih = self.tabel_catatan.selection()
        if not terpilih:
            self.kabar("Pilih baris pada tabel yang ingin dihapus terlebih dahulu.", berhasil=False)
            return

        nilai = self.tabel_catatan.item(terpilih[0], "values")
        no_bukti = nilai[1]
        keterangan = nilai[3]

        if not messagebox.askyesno(
            "Konfirmasi Hapus",
            f"Yakin ingin menghapus transaksi {no_bukti} ({keterangan})?\n\nJurnal yang terkait juga akan dihapus.",
        ):
            return

        hitung.hapus_transaksi_kas(no_bukti)
        self.kabar(f"Transaksi {no_bukti} berhasil dihapus.")
        self.bersihkan_form()
        self.muat()
        self.aplikasi.segarkan_semua()


# ------------------------------------------------------------
# 9. HALAMAN PENYESUAIAN
# ------------------------------------------------------------
class HalamanPenyesuaian(Halaman):
    def __init__(self, induk, aplikasi):
        super().__init__(induk, aplikasi, "Penyesuaian Akhir Bulan")

        tk.Label(self.isi, text="Dikerjakan sekali di akhir bulan, setelah stok "
                                "opname. Tujuannya supaya laba yang tampil adalah "
                                "laba yang sebenarnya.",
                 bg=LATAR, fg=TEKS_LEMAH, font=FONT_KECIL,
                 wraplength=780, justify="left").pack(anchor="w", pady=(0, 10))

        # --- pakan ---
        luar, isi = kartu(self.isi, "1. Pemakaian pakan")
        luar.pack(fill="x", pady=(0, 10))

        self.info_pakan = tk.Label(isi, text="", bg=LATAR_KARTU, fg=TEKS_LEMAH,
                                   font=FONT_KECIL)
        self.info_pakan.pack(anchor="w", pady=(0, 8))

        baris = tk.Frame(isi, bg=LATAR_KARTU)
        baris.pack(fill="x")

        self.tgl_pakan = self._isian(baris, "Tanggal", 0, lebar=12)
        self.tgl_pakan.insert(0, date.today().replace(day=28).isoformat())
        self.kg = self._isian(baris, "Pakan terpakai (kg)", 1, lebar=10)

        ttk.Button(isi, text="Catat pemakaian pakan",
                   command=self.simpan_pakan).pack(anchor="w", pady=(10, 0))

        # --- penyusutan ---
        luar, isi = kartu(self.isi, "2. Penyusutan peralatan")
        luar.pack(fill="x")

        tk.Label(isi, text="Peralatan kolam Rp1.800.000 disusutkan 3 tahun "
                           "(36 bulan) = sekitar Rp50.000 per bulan.",
                 bg=LATAR_KARTU, fg=TEKS_LEMAH, font=FONT_KECIL,
                 wraplength=700, justify="left").pack(anchor="w", pady=(0, 8))

        baris = tk.Frame(isi, bg=LATAR_KARTU)
        baris.pack(fill="x")

        self.tgl_susut = self._isian(baris, "Tanggal", 0, lebar=12)
        self.tgl_susut.insert(0, date.today().replace(day=28).isoformat())
        self.nilai_susut = self._isian(baris, "Nilai penyusutan (Rp)", 1, lebar=12)
        self.nilai_susut.insert(0, "50000")

        ttk.Button(isi, text="Catat penyusutan",
                   command=self.simpan_susut).pack(anchor="w", pady=(10, 0))

        self.muat()

    def muat(self):
        pakan = hitung.ambil_satu("SELECT * FROM barang WHERE kode = 'PKN01'")
        if pakan:
            stok = hitung.stok_sekarang(pakan["id"])
            self.info_pakan.configure(
                text=f"Stok pakan sekarang: {stok} kg, "
                     f"HPP {rupiah(pakan['hpp'])} / kg.")

    def simpan_pakan(self):
        tanggal = teks_dari(self.tgl_pakan)
        bulan = tanggal[:7]
        kg = bulat_dari(self.kg)

        pakan = hitung.ambil_satu("SELECT * FROM barang WHERE kode = 'PKN01'")
        stok = hitung.stok_sekarang(pakan["id"])

        sudah = hitung.ambil_satu(
            "SELECT COUNT(*) AS n FROM jurnal WHERE no_bukti = ?",
            (f"AJP-PKN-{bulan}",))["n"]

        if sudah > 0:
            self.kabar(f"Pemakaian pakan bulan {bulan} sudah dicatat.", berhasil=False)
            return
        if kg <= 0:
            self.kabar("Isi jumlah pakan yang dipakai.", berhasil=False)
            return
        if kg > stok:
            self.kabar(f"Stok pakan hanya {stok} kg.", berhasil=False)
            return

        nilai = kg * pakan["hpp"]
        no_bukti = f"AJP-PKN-{bulan}"

        # no_bukti ikut disimpan supaya catatan ini bisa dihapus bersama jurnalnya.
        hitung.jalankan(
            """INSERT INTO opname
               (tanggal, barang_id, qty_hilang, jenis, no_bukti, keterangan)
               VALUES (?, ?, ?, 'pakai', ?, ?)""",
            (tanggal, pakan["id"], kg, no_bukti, f"Pemakaian pakan {kg} kg"))

        hitung.simpan_jurnal(tanggal, no_bukti,
                             hitung.id_akun(AKUN_BEBAN_PAKAN), nilai, 0,
                             f"Pemakaian pakan {kg} kg")
        hitung.simpan_jurnal(tanggal, no_bukti,
                             hitung.id_akun(AKUN_PERSEDIAAN_PAKAN), 0, nilai,
                             f"Pemakaian pakan {kg} kg")

        self.kabar(f"Pemakaian pakan {kg} kg tercatat, nilai {rupiah(nilai)}.")
        self.kg.delete(0, "end")
        self.muat()
        self.aplikasi.segarkan_semua()

    def simpan_susut(self):
        tanggal = teks_dari(self.tgl_susut)
        bulan = tanggal[:7]
        nilai = bulat_dari(self.nilai_susut)

        sudah = hitung.ambil_satu(
            "SELECT COUNT(*) AS n FROM jurnal WHERE no_bukti = ?",
            (f"AJP-PNY-{bulan}",))["n"]

        if sudah > 0:
            self.kabar(f"Penyusutan bulan {bulan} sudah dicatat.", berhasil=False)
            return
        if nilai <= 0:
            self.kabar("Isi nilai penyusutan.", berhasil=False)
            return

        hitung.simpan_jurnal(tanggal, f"AJP-PNY-{bulan}",
                             hitung.id_akun(AKUN_BEBAN_PENYUSUTAN), nilai, 0,
                             "Penyusutan peralatan bulan ini")
        hitung.simpan_jurnal(tanggal, f"AJP-PNY-{bulan}",
                             hitung.id_akun(AKUN_AKUM_PENYUSUTAN), 0, nilai,
                             "Penyusutan peralatan bulan ini")

        self.kabar(f"Penyusutan {rupiah(nilai)} tercatat.")
        self.aplikasi.segarkan_semua()


# ------------------------------------------------------------
# 10. HALAMAN JURNAL
# ------------------------------------------------------------
class HalamanJurnal(Halaman):
    def __init__(self, induk, aplikasi):
        super().__init__(induk, aplikasi, "Jurnal dan Neraca Saldo")

        luar, isi = kartu(self.isi, "Neraca saldo")
        luar.pack(fill="both", expand=True, pady=(0, 10))

        bingkai, self.tabel_ns = tabel(
            isi, ("No", "Akun", "Kelompok", "Sebelum D", "Sebelum K",
                  "Sesudah D", "Sesudah K"),
            (60, 220, 110, 95, 95, 95, 95), tinggi=7)
        bingkai.pack(fill="both", expand=True)

        self.status = tk.Label(isi, text="", bg=LATAR_KARTU, font=FONT_KECIL)
        self.status.pack(anchor="w", pady=(6, 0))

        # --- opname ---
        luar, isi = kartu(self.isi, "Stok opname (ikan mati)")
        luar.pack(fill="x", pady=(0, 10))

        baris = tk.Frame(isi, bg=LATAR_KARTU)
        baris.pack(fill="x")

        self.tanggal = self._isian(baris, "Tanggal", 0, lebar=12)
        self.tanggal.insert(0, date.today().isoformat())

        self.ikan = hitung.ambil_semua(
            "SELECT * FROM barang WHERE satuan = 'ekor' ORDER BY kode")
        self.barang = self._pilihan(
            baris, "Jenis ikan", 1,
            [(f"{b['nama']} (stok {hitung.stok_sekarang(b['id'])})", b["id"])
             for b in self.ikan])

        self.qty = self._isian(baris, "Jumlah mati", 2, lebar=8)
        self.ket = self._isian(baris, "Keterangan", 3, lebar=24)
        self.ket.insert(0, "Ikan mati")

        ttk.Button(isi, text="Simpan opname",
                   command=self.simpan_opname).pack(anchor="w", pady=(10, 0))

        bingkai, self.tabel_opname = tabel(
            isi, ("Tanggal", "Barang", "Jumlah", "Jenis", "Bukti"),
            (110, 230, 80, 80, 100), tinggi=4)
        bingkai.pack(fill="x", pady=(8, 0))

        ttk.Button(isi, text="Hapus opname terpilih",
                   command=self.hapus_opname).pack(anchor="w", pady=(8, 0))

        # --- buku jurnal ---
        luar, isi = kartu(self.isi, "Buku jurnal (40 baris terakhir)")
        luar.pack(fill="both", expand=True)

        bingkai, self.tabel_jurnal = tabel(
            isi, ("Tanggal", "Bukti", "Akun", "Keterangan", "Debit", "Kredit"),
            (100, 85, 200, 200, 95, 95), tinggi=8)
        bingkai.pack(fill="both", expand=True)

        self.muat()

    def perbarui_pilihan_ikan(self):
        """Menyusun ulang daftar ikan, termasuk ukuran baru dari Pembelian."""
        self.ikan = hitung.ambil_semua(
            "SELECT * FROM barang WHERE satuan = 'ekor' ORDER BY ukuran_cm, kode")

        pasangan = [
            (f"{b['nama']} (stok {hitung.stok_sekarang(b['id'])})", b["id"])
            for b in self.ikan]
        pilihan_lama = self.barang.get()

        self.barang.configure(values=[p[0] for p in pasangan])
        self.barang.daftar = pasangan
        if pilihan_lama in [p[0] for p in pasangan]:
            self.barang.set(pilihan_lama)
        elif pasangan:
            self.barang.current(0)

    def muat(self):
        self.perbarui_pilihan_ikan()

        # Riwayat opname: bagian "Read" dan "Delete" dari CRUD.
        kosongkan(self.tabel_opname)
        for o in hitung.ambil_semua(
            """SELECT o.*, b.nama AS nama_barang
                 FROM opname o
                 LEFT JOIN barang b ON b.id = o.barang_id
                ORDER BY o.tanggal DESC, o.id DESC
                LIMIT 20"""):
            self.tabel_opname.insert(
                "", "end", iid=str(o["id"]),
                values=(tanggal_rapi(o["tanggal"]), o["nama_barang"],
                        o["qty_hilang"], o["jenis"], o["no_bukti"] or "-"))

        sebelum = {a["no_akun"]: a for a in hitung.neraca_saldo(True)}
        sesudah = hitung.neraca_saldo()
        kosongkan(self.tabel_ns)

        total_sd = total_sk = total_d = total_k = 0
        for a in sesudah:
            b = sebelum.get(a["no_akun"], {"debit": 0, "kredit": 0})
            if not (a["debit"] or a["kredit"] or b["debit"] or b["kredit"]):
                continue
            total_sd += b["debit"]
            total_sk += b["kredit"]
            total_d += a["debit"]
            total_k += a["kredit"]
            self.tabel_ns.insert(
                "", "end",
                values=(a["no_akun"], a["nama"], a["kelompok"],
                        angka(b["debit"]) if b["debit"] else "",
                        angka(b["kredit"]) if b["kredit"] else "",
                        angka(a["debit"]) if a["debit"] else "",
                        angka(a["kredit"]) if a["kredit"] else ""))

        self.tabel_ns.insert(
            "", "end", tags=("total",),
            values=("", "TOTAL", "", angka(total_sd), angka(total_sk),
                    angka(total_d), angka(total_k)))

        if total_d == total_k and total_sd == total_sk:
            self.status.configure(
                text=(f"SEIMBANG  —  sebelum penyesuaian {rupiah(total_sd)}, "
                      f"sesudah penyesuaian {rupiah(total_d)}"),
                fg=HIJAU)
        else:
            selisih = abs(total_d - total_k) + abs(total_sd - total_sk)
            self.status.configure(
                text=f"TIDAK SEIMBANG  —  selisih {rupiah(selisih)}", fg=MERAH)

        kosongkan(self.tabel_jurnal)
        for j in hitung.ambil_semua(
            """SELECT j.*, a.no_akun, a.nama AS nama_akun
               FROM jurnal j JOIN akun a ON a.id = j.akun_id
               ORDER BY j.tanggal DESC, j.id DESC LIMIT 40"""):
            self.tabel_jurnal.insert(
                "", "end",
                values=(tanggal_rapi(j["tanggal"]), j["no_bukti"],
                        f"{j['no_akun']} {j['nama_akun']}", j["keterangan"],
                        angka(j["debit"]) if j["debit"] else "",
                        angka(j["kredit"]) if j["kredit"] else ""))

    def simpan_opname(self):
        barang_id = self.nilai_pilihan(self.barang)
        qty = bulat_dari(self.qty)
        keterangan = teks_dari(self.ket) or "Ikan mati"

        stok = hitung.stok_sekarang(barang_id)

        if qty <= 0:
            self.kabar("Jumlah ikan mati harus lebih dari nol.", berhasil=False)
            return
        if qty > stok:
            self.kabar(f"Jumlah melebihi stok yang ada ({stok} ekor).", berhasil=False)
            return

        barang = hitung.ambil_satu("SELECT * FROM barang WHERE id = ?", (barang_id,))
        nilai = qty * barang["hpp"]

        # Nomor jurnal diambil dari nomor terbesar, bukan dari jumlah baris,
        # supaya tidak bentrok setelah ada opname yang dihapus.
        no_bukti = hitung.nomor_ajp()

        hitung.jalankan(
            """INSERT INTO opname
               (tanggal, barang_id, qty_hilang, jenis, no_bukti, keterangan)
               VALUES (?, ?, ?, 'mati', ?, ?)""",
            (teks_dari(self.tanggal), barang_id, qty, no_bukti, keterangan))

        hitung.simpan_jurnal(teks_dari(self.tanggal), no_bukti,
                             hitung.id_akun(AKUN_BEBAN_IKAN_MATI), nilai, 0,
                             f"{keterangan} ({qty} ekor)")
        hitung.simpan_jurnal(teks_dari(self.tanggal), no_bukti,
                             hitung.id_akun(AKUN_PERSEDIAAN_KOI), 0, nilai,
                             f"{keterangan} ({qty} ekor)")

        self.kabar(f"Opname tersimpan: {qty} ekor, nilai {rupiah(nilai)} "
                   f"(jurnal {no_bukti}).")
        self.qty.delete(0, "end")
        self.muat()
        self.aplikasi.segarkan_semua()

    def hapus_opname(self):
        """Menghapus catatan opname sekaligus jurnal penyesuaiannya."""
        terpilih = self.tabel_opname.selection()
        if not terpilih:
            self.kabar("Pilih catatan opname yang ingin dihapus.", berhasil=False)
            return

        opname_id = int(terpilih[0])
        no_bukti = self.tabel_opname.item(terpilih[0], "values")[4]

        if not messagebox.askyesno(
            "Hapus Opname",
            f"Hapus catatan opname {no_bukti}?\n\nJurnal penyesuaiannya ikut "
            "dihapus dan stok kembali seperti sebelum opname.",
        ):
            return

        try:
            hitung.hapus_opname(opname_id)
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return

        self.kabar(f"Opname {no_bukti} dihapus. Stok sudah kembali.")
        self.muat()
        self.aplikasi.segarkan_semua()


# ------------------------------------------------------------
# 10b. HALAMAN JURNAL UMUM
# ------------------------------------------------------------
class HalamanJurnalUmum(Halaman):
    """Jurnal untuk transaksi non-kas dan koreksi (rancangan bagian 5.5)."""

    def __init__(self, induk, aplikasi):
        super().__init__(induk, aplikasi, "Jurnal Umum")
        self.baris = []

        self.akun = hitung.ambil_semua("SELECT * FROM akun ORDER BY no_akun")
        pasangan = [(f"{a['no_akun']} — {a['nama']}", a["id"]) for a in self.akun]

        luar, isi = kartu(self.isi, "Buat jurnal umum")
        luar.pack(fill="x", pady=(0, 10))

        baris = tk.Frame(isi, bg=LATAR_KARTU)
        baris.pack(fill="x")

        self.ju_tanggal = self._isian(baris, "Tanggal", 0, lebar=12)
        self.ju_tanggal.insert(0, date.today().isoformat())
        self.ju_ket = self._isian(baris, "Keterangan", 1, lebar=44)

        baris2 = tk.Frame(isi, bg=LATAR_KARTU)
        baris2.pack(fill="x", pady=(8, 0))

        self.ju_akun = self._pilihan(baris2, "Akun", 0, pasangan)
        self.ju_akun.configure(width=38)
        self.ju_debit = self._isian(baris2, "Debit", 1, lebar=12)
        self.ju_kredit = self._isian(baris2, "Kredit", 2, lebar=12)

        ttk.Button(baris2, text="Tambah baris",
                   command=self.tambah_baris).grid(
            row=1, column=3, padx=(12, 0), pady=(14, 0))

        bingkai, self.tabel_baris = tabel(
            isi, ("Akun", "Debit", "Kredit"), (300, 110, 110), tinggi=5)
        bingkai.pack(fill="x", pady=(10, 0))

        self.total_label = tk.Label(isi, text="", bg=LATAR_KARTU, fg=TEKS,
                                    font=FONT_KECIL)
        self.total_label.pack(anchor="w", pady=(6, 0))

        aksi = tk.Frame(isi, bg=LATAR_KARTU)
        aksi.pack(anchor="w", pady=(8, 0))
        ttk.Button(aksi, text="Hapus baris terpilih",
                   command=self.hapus_baris).pack(side="left")
        ttk.Button(aksi, text="Simpan jurnal",
                   command=self.simpan).pack(side="left", padx=(8, 0))
        ttk.Button(aksi, text="Bersihkan",
                   command=self.bersihkan).pack(side="left", padx=(8, 0))

        luar, isi = kartu(self.isi, "Riwayat jurnal umum")
        luar.pack(fill="both", expand=True)

        bingkai, self.tabel_riwayat = tabel(
            isi, ("Bukti", "Tanggal", "Keterangan", "Debit", "Kredit"),
            (80, 100, 260, 100, 100), tinggi=6)
        bingkai.pack(fill="both", expand=True)

        self.muat()

    def _nama_akun(self, akun_id):
        for a in self.akun:
            if a["id"] == akun_id:
                return f"{a['no_akun']} — {a['nama']}"
        return str(akun_id)

    def tambah_baris(self):
        akun_id = self.nilai_pilihan(self.ju_akun)
        debit = bulat_dari(self.ju_debit)
        kredit = bulat_dari(self.ju_kredit)
        if (debit > 0) == (kredit > 0):
            self.kabar("Isi debit saja atau kredit saja pada satu baris.",
                       berhasil=False)
            return
        self.baris.append({"akun_id": akun_id, "nama": self._nama_akun(akun_id),
                           "debit": debit, "kredit": kredit})
        self.kosongkan_isian(self.ju_debit, self.ju_kredit)
        self.gambar_baris()

    def hapus_baris(self):
        terpilih = self.tabel_baris.selection()
        if not terpilih:
            self.kabar("Pilih baris yang ingin dihapus.", berhasil=False)
            return
        del self.baris[int(terpilih[0])]
        self.gambar_baris()

    def gambar_baris(self):
        kosongkan(self.tabel_baris)
        for urutan, isi in enumerate(self.baris):
            self.tabel_baris.insert(
                "", "end", iid=str(urutan),
                values=(isi["nama"],
                        angka(isi["debit"]) if isi["debit"] else "",
                        angka(isi["kredit"]) if isi["kredit"] else ""))
        total_debit = sum(b["debit"] for b in self.baris)
        total_kredit = sum(b["kredit"] for b in self.baris)
        status = "seimbang" if total_debit == total_kredit else "BELUM seimbang"
        self.total_label.configure(
            text=f"Debit {rupiah(total_debit)}  —  Kredit "
                 f"{rupiah(total_kredit)}  ({status})")

    def simpan(self):
        if len(self.baris) < 2:
            self.kabar("Jurnal umum minimal dua baris.", berhasil=False)
            return
        try:
            no_bukti = hitung.simpan_jurnal_umum(
                teks_dari(self.ju_tanggal) or date.today().isoformat(),
                teks_dari(self.ju_ket) or "Jurnal umum",
                self.baris, self.aplikasi.sesi["nama"])
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return
        self.kabar(f"Jurnal umum {no_bukti} tersimpan.")
        self.bersihkan()
        self.muat()
        self.aplikasi.segarkan_semua()

    def bersihkan(self):
        self.baris = []
        self.kosongkan_isian(self.ju_ket, self.ju_debit, self.ju_kredit)
        self.gambar_baris()
        for baris in self.tabel_baris.selection():
            self.tabel_baris.selection_remove(baris)

    def muat(self):
        kosongkan(self.tabel_riwayat)
        for b in hitung.ambil_semua(
            """SELECT no_bukti, MIN(tanggal) AS tanggal,
                      MIN(keterangan) AS keterangan,
                      SUM(debit) AS debit, SUM(kredit) AS kredit
                 FROM jurnal
                WHERE no_bukti LIKE 'JU-%'
                GROUP BY no_bukti
                ORDER BY MIN(tanggal) DESC, no_bukti DESC"""):
            self.tabel_riwayat.insert(
                "", "end",
                values=(b["no_bukti"], tanggal_rapi(b["tanggal"]),
                        b["keterangan"] or "", angka(b["debit"]),
                        angka(b["kredit"])))


# ------------------------------------------------------------
# 10c. HALAMAN KAS KECIL
# ------------------------------------------------------------
class HalamanKasKecil(Halaman):
    """Kas kecil dengan sistem dana tetap (rancangan bagian 5.6)."""

    def __init__(self, induk, aplikasi):
        super().__init__(induk, aplikasi, "Kas Kecil")
        self.sumber = [
            ("Kas", hitung.id_akun("1101")),
            ("Bank", hitung.id_akun("1102")),
        ]
        self.akun_beban = hitung.ambil_semua(
            "SELECT * FROM akun WHERE kelompok = 'Beban' ORDER BY no_akun")

        self.saldo_label = tk.Label(self.isi, text="", bg=LATAR,
                                    fg=AKSEN, font=("DejaVu Sans", 16, "bold"))
        self.saldo_label.pack(anchor="w", pady=(0, 10))

        luar, isi = kartu(self.isi, "Isi dana kas kecil")
        luar.pack(fill="x", pady=(0, 10))
        baris = tk.Frame(isi, bg=LATAR_KARTU)
        baris.pack(fill="x")
        self.kk_tanggal = self._isian(baris, "Tanggal", 0, lebar=12)
        self.kk_tanggal.insert(0, date.today().isoformat())
        self.kk_jumlah = self._isian(baris, "Jumlah", 1, lebar=12)
        self.kk_sumber = self._pilihan(baris, "Sumber dana", 2, self.sumber)
        self.kk_ket = self._isian(baris, "Keterangan", 3, lebar=28)
        self.kk_ket.insert(0, "Pengisian kas kecil")
        ttk.Button(isi, text="Isi dana",
                   command=self.isi_dana).pack(anchor="w", pady=(10, 0))

        luar, isi = kartu(self.isi, "Belanja dari kas kecil")
        luar.pack(fill="x", pady=(0, 10))
        baris = tk.Frame(isi, bg=LATAR_KARTU)
        baris.pack(fill="x")
        self.kk2_tanggal = self._isian(baris, "Tanggal", 0, lebar=12)
        self.kk2_tanggal.insert(0, date.today().isoformat())
        self.kk2_akun = self._pilihan(
            baris, "Akun beban", 1,
            [(f"{a['no_akun']} — {a['nama']}", a["id"])
             for a in self.akun_beban])
        self.kk2_akun.configure(width=30)
        self.kk2_jumlah = self._isian(baris, "Jumlah", 2, lebar=12)
        self.kk2_ket = self._isian(baris, "Keterangan", 3, lebar=28)
        ttk.Button(isi, text="Catat belanja",
                   command=self.belanja).pack(anchor="w", pady=(10, 0))

        luar, isi = kartu(self.isi, "Riwayat kas kecil")
        luar.pack(fill="both", expand=True)
        bingkai, self.tabel_riwayat = tabel(
            isi, ("Bukti", "Tanggal", "Keterangan", "Masuk", "Keluar"),
            (80, 100, 260, 100, 100), tinggi=7)
        bingkai.pack(fill="both", expand=True)
        ttk.Button(isi, text="Hapus transaksi terpilih",
                   command=self.hapus).pack(anchor="w", pady=(8, 0))

        self.muat()

    def muat(self):
        self.saldo_label.configure(
            text=f"Saldo kas kecil: {rupiah(hitung.saldo_kas_kecil())}")
        kosongkan(self.tabel_riwayat)
        for b in hitung.riwayat_kas_kecil():
            self.tabel_riwayat.insert(
                "", "end", iid=b["no_bukti"],
                values=(b["no_bukti"], tanggal_rapi(b["tanggal"]),
                        b["keterangan"] or "",
                        angka(b["debit"]) if b["debit"] else "",
                        angka(b["kredit"]) if b["kredit"] else ""))

    def isi_dana(self):
        try:
            hitung.isi_kas_kecil(
                teks_dari(self.kk_tanggal) or date.today().isoformat(),
                bulat_dari(self.kk_jumlah),
                self.nilai_pilihan(self.kk_sumber),
                teks_dari(self.kk_ket),
                self.aplikasi.sesi["nama"])
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return
        self.kabar("Dana kas kecil ditambahkan.")
        self.kosongkan_isian(self.kk_jumlah)
        self.muat()
        self.aplikasi.segarkan_semua()

    def belanja(self):
        try:
            hitung.belanja_kas_kecil(
                teks_dari(self.kk2_tanggal) or date.today().isoformat(),
                self.nilai_pilihan(self.kk2_akun),
                bulat_dari(self.kk2_jumlah),
                teks_dari(self.kk2_ket) or "Belanja kas kecil",
                self.aplikasi.sesi["nama"])
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return
        self.kabar("Belanja kas kecil dicatat.")
        self.kosongkan_isian(self.kk2_jumlah, self.kk2_ket)
        self.muat()
        self.aplikasi.segarkan_semua()

    def hapus(self):
        terpilih = self.tabel_riwayat.selection()
        if not terpilih:
            self.kabar("Pilih transaksi yang ingin dihapus.", berhasil=False)
            return
        if not messagebox.askyesno("Hapus Kas Kecil",
                                   "Hapus transaksi kas kecil ini?"):
            return
        try:
            hitung.hapus_kas_kecil(terpilih[0], self.aplikasi.sesi["nama"])
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return
        self.kabar("Transaksi kas kecil dihapus.")
        self.muat()
        self.aplikasi.segarkan_semua()


# ------------------------------------------------------------
# 10f. EKSPOR EXCEL TANPA PUSTAKA TAMBAHAN
# ------------------------------------------------------------
# Berkas .xlsx sebenarnya hanya arsip ZIP berisi beberapa berkas XML.
# Jadi aplikasi tetap memakai pustaka standar: zipfile dan xml.
GAYA_NORMAL = 0
GAYA_TEBAL = 1
GAYA_UANG = 2
GAYA_UANG_TEBAL = 3
GAYA_JUDUL = 4
GAYA_KEPALA = 5

GAYA_XLSX = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0;[Red](#,##0);&quot;-&quot;"/></numFmts>
<fonts count="3">
<font><sz val="10"/><name val="Arial"/></font>
<font><b/><sz val="10"/><name val="Arial"/></font>
<font><b/><sz val="12"/><name val="Arial"/></font>
</fonts>
<fills count="3">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFE4D9C6"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="2">
<border><left/><right/><top/><bottom/><diagonal/></border>
<border><left style="thin"><color rgb="FFB9AE9C"/></left><right style="thin"><color rgb="FFB9AE9C"/></right><top style="thin"><color rgb="FFB9AE9C"/></top><bottom style="thin"><color rgb="FFB9AE9C"/></bottom><diagonal/></border>
</borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="6">
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"/>
<xf numFmtId="0" fontId="1" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1"/>
<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1"/>
<xf numFmtId="164" fontId="1" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1"/>
<xf numFmtId="0" fontId="2" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>
"""


def _huruf_kolom(nomor):
    """1 -> A, 2 -> B, 27 -> AA."""
    hasil = ""
    while nomor:
        nomor, sisa = divmod(nomor - 1, 26)
        hasil = chr(65 + sisa) + hasil
    return hasil


def _sel_xml(baris, kolom, isi):
    """Satu sel Excel. Isi boleh nilai biasa atau pasangan (nilai, gaya)."""
    if isinstance(isi, tuple):
        nilai, gaya = isi
    else:
        nilai, gaya = isi, GAYA_NORMAL

    if nilai is None or nilai == "":
        return ""

    alamat = f"{_huruf_kolom(kolom)}{baris}"
    if isinstance(nilai, bool):
        nilai = "YA" if nilai else "TIDAK"
    if isinstance(nilai, (int, float)):
        return f'<c r="{alamat}" s="{gaya}"><v>{nilai}</v></c>'

    teks = escape(str(nilai))
    return (f'<c r="{alamat}" s="{gaya}" t="inlineStr">'
            f'<is><t xml:space="preserve">{teks}</t></is></c>')


def _lembar_xml(baris, lebar):
    """Satu worksheet. baris = list of list sel; lebar = lebar kolom."""
    kolom = "".join(
        f'<col min="{i}" max="{i}" width="{w}" customWidth="1"/>'
        for i, w in enumerate(lebar, start=1))

    isi = []
    for nomor, isi_baris in enumerate(baris, start=1):
        sel = "".join(
            _sel_xml(nomor, urutan, nilai)
            for urutan, nilai in enumerate(isi_baris, start=1))
        isi.append(f'<row r="{nomor}">{sel}</row>')

    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<worksheet xmlns="http://schemas.openxmlformats.org/'
            'spreadsheetml/2006/main">'
            f'<cols>{kolom}</cols><sheetData>{"".join(isi)}</sheetData>'
            '</worksheet>')


def tulis_xlsx(berkas, daftar_lembar):
    """
    Menulis berkas Excel dari daftar (nama, lebar, baris).

    Tidak memakai openpyxl. Semua bagian .xlsx dibuat dari teks XML
    lalu dibungkus zipfile, jadi aplikasi tetap Python murni.
    """
    jumlah = len(daftar_lembar)
    if jumlah == 0:
        raise ValueError("Tidak ada lembar untuk ditulis.")

    overrides = "".join(
        f'<Override PartName="/xl/worksheets/sheet{i}.xml" '
        'ContentType="application/vnd.openxmlformats-officedocument.'
        'spreadsheetml.worksheet+xml"/>'
        for i in range(1, jumlah + 1))

    isi_berkas = {
        "[Content_Types].xml": (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/'
            'content-types">'
            '<Default Extension="rels" ContentType="application/'
            'vnd.openxmlformats-package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/>'
            '<Override PartName="/xl/workbook.xml" ContentType="application/'
            'vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            '<Override PartName="/xl/styles.xml" ContentType="application/'
            'vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            f'{overrides}</Types>'),
        "_rels/.rels": (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/'
            '2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/'
            'officeDocument/2006/relationships/officeDocument" '
            'Target="xl/workbook.xml"/></Relationships>'),
        "xl/workbook.xml": (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/'
            '2006/main" xmlns:r="http://schemas.openxmlformats.org/'
            'officeDocument/2006/relationships"><sheets>'
            + "".join(
                f'<sheet name="{escape(nama, {chr(34): "&quot;"})}" '
                f'sheetId="{i}" r:id="rId{i}"/>'
                for i, (nama, _, _) in enumerate(daftar_lembar, start=1))
            + '</sheets></workbook>'),
        "xl/_rels/workbook.xml.rels": (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/'
            '2006/relationships">'
            + "".join(
                f'<Relationship Id="rId{i}" Type="http://schemas.'
                'openxmlformats.org/officeDocument/2006/relationships/'
                f'worksheet" Target="worksheets/sheet{i}.xml"/>'
                for i in range(1, jumlah + 1))
            + f'<Relationship Id="rId{jumlah + 1}" Type="http://schemas.'
            'openxmlformats.org/officeDocument/2006/relationships/styles" '
            'Target="styles.xml"/></Relationships>'),
        "xl/styles.xml": GAYA_XLSX,
    }

    for i, (_, lebar, baris) in enumerate(daftar_lembar, start=1):
        isi_berkas[f"xl/worksheets/sheet{i}.xml"] = _lembar_xml(baris, lebar)

    with ZipFile(berkas, "w", ZIP_DEFLATED) as arsip:
        for nama, isi in isi_berkas.items():
            arsip.writestr(nama, isi)


def data_laporan():
    """Angka yang dipakai halaman Laporan dan ekspor Excel."""
    laba = hitung.laba_rugi()
    ns = hitung.neraca_saldo()

    lancar, tetap, kewajiban = [], [], []
    modal_akun = 0
    for akun in ns:
        nilai = akun["debit"] - akun["kredit"]
        if akun["kelompok"] == "Aset Lancar":
            lancar.append((akun["nama"], nilai))
        elif akun["kelompok"] == "Aset Tetap":
            tetap.append((akun["nama"], nilai))
        elif akun["kelompok"] == "Kewajiban":
            kewajiban.append((akun["nama"], -nilai))
        elif akun["kelompok"] == "Ekuitas" and akun["no_akun"] == AKUN_MODAL:
            modal_akun = akun["kredit"] - akun["debit"]

    modal_awal = 14720000
    modal_akhir = modal_akun + laba["laba_bersih"]
    total_lancar = sum(n for _, n in lancar)
    total_tetap = sum(n for _, n in tetap)
    total_aset = total_lancar + total_tetap
    total_kewajiban = sum(n for _, n in kewajiban)

    return {
        "laba": laba,
        "lancar": lancar,
        "tetap": tetap,
        "kewajiban": kewajiban,
        "modal_awal": modal_awal,
        "modal_akun": modal_akun,
        "modal_akhir": modal_akhir,
        "total_lancar": total_lancar,
        "total_tetap": total_tetap,
        "total_aset": total_aset,
        "total_kewajiban": total_kewajiban,
        "seimbang": round(total_aset) == round(total_kewajiban + modal_akhir),
    }


def _baris_laba_rugi(laba):
    baris = [
        [("LAPORAN LABA RUGI", GAYA_JUDUL)],
        [],
        [("Keterangan", GAYA_KEPALA), ("Jumlah", GAYA_KEPALA)],
        [("Pendapatan", GAYA_TEBAL)],
        [("  Penjualan ikan", GAYA_NORMAL),
         (laba["penjualan_koi"], GAYA_UANG)],
        [("  Pendapatan ongkos kirim", GAYA_NORMAL),
         (laba["pendapatan_ongkir"], GAYA_UANG)],
        [("Total pendapatan", GAYA_TEBAL), (laba["pendapatan"], GAYA_UANG_TEBAL)],
        [],
        [("Harga pokok penjualan", GAYA_TEBAL)],
        [("  HPP ikan", GAYA_NORMAL), (laba["hpp"], GAYA_UANG)],
        [("Laba kotor", GAYA_TEBAL), (laba["laba_kotor"], GAYA_UANG_TEBAL)],
        [],
        [("Beban operasional", GAYA_TEBAL)],
    ]
    for beban in laba["rincian_beban"]:
        baris.append([("  " + beban["nama"], GAYA_NORMAL),
                      (beban["debit"], GAYA_UANG)])
    baris.extend([
        [("Total beban", GAYA_TEBAL), (laba["beban"], GAYA_UANG_TEBAL)],
        [],
        [("LABA BERSIH", GAYA_TEBAL), (laba["laba_bersih"], GAYA_UANG_TEBAL)],
    ])
    return baris


def _baris_modal(data):
    laba = data["laba"]
    return [
        [("LAPORAN PERUBAHAN MODAL", GAYA_JUDUL)],
        [],
        [("Keterangan", GAYA_KEPALA), ("Jumlah", GAYA_KEPALA)],
        [("Modal awal (1 Oktober 2026)", GAYA_NORMAL),
         (data["modal_awal"], GAYA_UANG)],
        [("Setoran modal tambahan", GAYA_NORMAL),
         (data["modal_akun"] - data["modal_awal"], GAYA_UANG)],
        [("Laba bersih periode ini", GAYA_NORMAL),
         (laba["laba_bersih"], GAYA_UANG)],
        [("Prive", GAYA_NORMAL), (0, GAYA_UANG)],
        [("Modal akhir", GAYA_TEBAL), (data["modal_akhir"], GAYA_UANG_TEBAL)],
    ]


def _baris_posisi(data):
    baris = [
        [("LAPORAN POSISI KEUANGAN", GAYA_JUDUL)],
        [],
        [("Keterangan", GAYA_KEPALA), ("Jumlah", GAYA_KEPALA)],
        [("ASET LANCAR", GAYA_TEBAL)],
    ]
    for nama, nilai in data["lancar"]:
        if nilai:
            baris.append([("  " + nama, GAYA_NORMAL), (nilai, GAYA_UANG)])
    baris.extend([
        [("Total aset lancar", GAYA_TEBAL),
         (data["total_lancar"], GAYA_UANG_TEBAL)],
        [],
        [("ASET TETAP", GAYA_TEBAL)],
    ])
    for nama, nilai in data["tetap"]:
        if nilai:
            baris.append([("  " + nama, GAYA_NORMAL), (nilai, GAYA_UANG)])
    baris.extend([
        [("Total aset tetap", GAYA_TEBAL),
         (data["total_tetap"], GAYA_UANG_TEBAL)],
        [("TOTAL ASET", GAYA_TEBAL), (data["total_aset"], GAYA_UANG_TEBAL)],
        [],
        [("KEWAJIBAN", GAYA_TEBAL)],
    ])
    if data["total_kewajiban"] == 0:
        baris.append([("  Tidak ada utang", GAYA_NORMAL), (0, GAYA_UANG)])
    else:
        for nama, nilai in data["kewajiban"]:
            baris.append([("  " + nama, GAYA_NORMAL), (nilai, GAYA_UANG)])
    baris.extend([
        [("MODAL", GAYA_TEBAL)],
        [("  Modal akhir", GAYA_NORMAL), (data["modal_akhir"], GAYA_UANG)],
        [("TOTAL KEWAJIBAN + MODAL", GAYA_TEBAL),
         (data["total_kewajiban"] + data["modal_akhir"], GAYA_UANG_TEBAL)],
        [],
        [("NERACA SEIMBANG" if data["seimbang"] else "NERACA TIDAK SEIMBANG",
          GAYA_TEBAL)],
    ])
    return baris


def ekspor_laporan_excel(induk, sesi):
    """Meminta lokasi berkas lalu menulis laporan ke Excel. Hasil: path/None."""
    berkas = filedialog.asksaveasfilename(
        parent=induk,
        defaultextension=".xlsx",
        filetypes=[("Berkas Excel", "*.xlsx")],
        initialfile="laporan-sikoi.xlsx",
        title="Ekspor laporan ke Excel")
    if not berkas:
        return None

    data = data_laporan()
    tulis_xlsx(berkas, [
        ("Laba Rugi", [48, 20], _baris_laba_rugi(data["laba"])),
        ("Perubahan Modal", [48, 20], _baris_modal(data)),
        ("Posisi Keuangan", [48, 20], _baris_posisi(data)),
    ])
    hitung.catat_audit("laporan", "ekspor", None, berkas, sesi["nama"])
    return berkas


# ------------------------------------------------------------
# 11. HALAMAN LAPORAN
# ------------------------------------------------------------
class HalamanLaporan(Halaman):
    def __init__(self, induk, aplikasi):
        super().__init__(induk, aplikasi, "Laporan Keuangan")

        tk.Label(self.isi, text="Semua angka dihitung dari jurnal. Tidak ada yang "
                                "diketik manual, sehingga laporan selalu sama dengan "
                                "transaksi yang tercatat.",
                 bg=LATAR, fg=TEKS_LEMAH, font=FONT_KECIL,
                 wraplength=780, justify="left").pack(anchor="w", pady=(0, 8))

        # Status ditaruh di atas supaya selalu terlihat tanpa menggulir.
        self.status = tk.Label(self.isi, text="", bg=LATAR, font=("DejaVu Sans", 10, "bold"))
        self.status.pack(anchor="w", pady=(0, 8))

        aksi = tk.Frame(self.isi, bg=LATAR)
        aksi.pack(fill="x", pady=(0, 6))
        ttk.Button(aksi, text="Ekspor ke Excel",
                   command=self.ekspor_excel).pack(side="right")

        bingkai = tk.Frame(self.isi, bg=LATAR_KARTU, highlightbackground=GARIS,
                           highlightthickness=1)
        bingkai.pack(fill="both", expand=True)

        self.teks = tk.Text(bingkai, wrap="word", font=("DejaVu Sans Mono", 9),
                            bg=LATAR_KARTU, fg=TEKS, relief="flat",
                            padx=16, pady=12)
        gulir = ttk.Scrollbar(bingkai, orient="vertical", command=self.teks.yview)
        self.teks.configure(yscrollcommand=gulir.set)
        self.teks.pack(side="left", fill="both", expand=True)
        gulir.pack(side="right", fill="y")

        self.teks.tag_configure("judul", font=("DejaVu Sans", 11, "bold"))
        self.teks.tag_configure("total", font=("DejaVu Sans Mono", 9, "bold"))
        self.teks.tag_configure("baik", foreground=HIJAU)
        self.teks.tag_configure("buruk", foreground=MERAH)

        self.muat()

    def tulis(self, teks, tag=None):
        self.teks.insert("end", teks, tag or ())

    def baris(self, kiri, kanan, tag=None):
        self.tulis(f"{kiri:<46}{kanan:>16}\n", tag)

    def ekspor_excel(self):
        """Menyimpan tiga laporan keuangan ke berkas Excel yang dipilih."""
        try:
            berkas = ekspor_laporan_excel(self, self.aplikasi.sesi)
        except OSError as galat:
            self.status.configure(text=f"Gagal menyimpan: {galat}", fg=MERAH)
            return

        if berkas:
            self.status.configure(
                text=f"Laporan disimpan ke {berkas}", fg=HIJAU)

    def muat(self):
        self.teks.configure(state="normal")
        self.teks.delete("1.0", "end")

        data = data_laporan()
        laba = data["laba"]

        # ---------- laba rugi ----------
        self.tulis("LAPORAN LABA RUGI\n", "judul")
        self.tulis("=" * 62 + "\n\n")
        self.baris("Penjualan", angka(laba["penjualan_koi"]))
        self.baris("Harga Pokok Penjualan", f"({angka(laba['hpp'])})")
        self.baris("Laba Kotor", akun(laba["laba_kotor"]), "total")
        self.tulis("\n")
        self.baris("Pendapatan Ongkos Kirim", angka(laba["pendapatan_ongkir"]))

        for b in laba["rincian_beban"]:
            if b["debit"]:
                self.baris(b["nama"], f"({angka(b['debit'])})")

        self.baris("Total beban", f"({angka(laba['beban'])})", "total")
        self.tulis("\n")
        self.baris("LABA BERSIH", rupiah_akun(laba["laba_bersih"]), "total")

        # ---------- perubahan modal ----------
        aset_lancar = data["lancar"]
        aset_tetap = data["tetap"]
        kewajiban = data["kewajiban"]
        modal_awal = data["modal_awal"]
        modal_akhir = data["modal_akhir"]

        self.tulis("\n\nLAPORAN PERUBAHAN MODAL\n", "judul")
        self.tulis("=" * 62 + "\n\n")
        self.baris("Modal awal (1 Okt 2026)", angka(modal_awal))
        self.baris("Setoran modal tambahan",
                   angka(data["modal_akun"] - modal_awal))
        self.baris("Laba bersih", akun(laba["laba_bersih"]))
        self.baris("Prive", "0")
        self.baris("Modal akhir", angka(modal_akhir), "total")

        # ---------- posisi keuangan ----------
        self.tulis("\n\nLAPORAN POSISI KEUANGAN\n", "judul")
        self.tulis("=" * 62 + "\n\n")

        self.tulis("ASET LANCAR\n", "total")
        for nama, nilai in aset_lancar:
            if nilai:
                self.baris("  " + nama, angka(nilai))
        total_lancar = data["total_lancar"]
        self.baris("Total aset lancar", angka(total_lancar), "total")

        self.tulis("\nASET TETAP\n", "total")
        for nama, nilai in aset_tetap:
            if nilai:
                self.baris("  " + nama, akun(nilai))
        total_tetap = data["total_tetap"]
        self.baris("Total aset tetap", angka(total_tetap), "total")

        total_aset = data["total_aset"]
        self.baris("TOTAL ASET", angka(total_aset), "total")

        self.tulis("\nKEWAJIBAN\n", "total")
        total_kewajiban = data["total_kewajiban"]
        if total_kewajiban == 0:
            self.baris("  Tidak ada utang (semua tunai)", "0")
        else:
            for nama, nilai in kewajiban:
                self.baris("  " + nama, angka(nilai))

        self.tulis("\nMODAL\n", "total")
        self.baris("  Modal akhir", angka(modal_akhir))

        self.baris("TOTAL KEWAJIBAN + MODAL",
                   angka(total_kewajiban + modal_akhir), "total")

        self.tulis("\n")
        if round(total_aset) == round(total_kewajiban + modal_akhir):
            self.tulis("  NERACA SEIMBANG\n", "baik")
            self.status.configure(
                text=f"NERACA SEIMBANG  —  total aset {rupiah(total_aset)}  =  "
                     f"kewajiban + modal {rupiah(total_kewajiban + modal_akhir)}",
                fg=HIJAU)
        else:
            selisih = total_aset - (total_kewajiban + modal_akhir)
            self.tulis(f"  NERACA TIDAK SEIMBANG (selisih {rupiah(selisih)})\n",
                       "buruk")
            self.status.configure(
                text=f"NERACA TIDAK SEIMBANG  —  selisih {rupiah(selisih)}",
                fg=MERAH)

        self.teks.configure(state="disabled")


# ------------------------------------------------------------
# 11a. HALAMAN NERACA LAJUR
# ------------------------------------------------------------
class HalamanNeracaLajur(Halaman):
    """Neraca lajur 10 kolom (rancangan bagian 8)."""

    def __init__(self, induk, aplikasi):
        super().__init__(induk, aplikasi, "Neraca Lajur")
        tk.Label(self.isi, text="Neraca saldo, penyesuaian, saldo setelah "
                                "penyesuaian, laba rugi, dan neraca.",
                 bg=LATAR, fg=TEKS_LEMAH, font=FONT_KECIL).pack(
            anchor="w", pady=(0, 8))

        luar, isi = kartu(self.isi, "Neraca lajur (worksheet)")
        luar.pack(fill="both", expand=True)

        bingkai, self.tabel_lajur = tabel(
            isi,
            ("No", "Akun", "NS D", "NS K", "Pen D", "Pen K",
             "NSSD D", "NSSD K", "LR D", "LR K", "Neraca D", "Neraca K"),
            (55, 170, 75, 75, 70, 70, 75, 75, 70, 70, 80, 80),
            tinggi=13)
        bingkai.pack(fill="both", expand=True)

        self.laba = tk.Label(isi, text="", bg=LATAR_KARTU, fg=TEKS,
                             font=("DejaVu Sans", 10, "bold"))
        self.laba.pack(anchor="w", pady=(8, 0))

        self.muat()

    def muat(self):
        lajur = hitung.neraca_lajur()
        kosongkan(self.tabel_lajur)

        for b in lajur["baris"]:
            if not any(b[k] for k in ("ns_d", "ns_k", "pen_d", "pen_k",
                                      "nssd_d", "nssd_k")):
                continue
            self.tabel_lajur.insert(
                "", "end",
                values=(b["no_akun"], b["nama"],
                        angka(b["ns_d"]) if b["ns_d"] else "",
                        angka(b["ns_k"]) if b["ns_k"] else "",
                        angka(b["pen_d"]) if b["pen_d"] else "",
                        angka(b["pen_k"]) if b["pen_k"] else "",
                        angka(b["nssd_d"]) if b["nssd_d"] else "",
                        angka(b["nssd_k"]) if b["nssd_k"] else "",
                        angka(b["lr_d"]) if b["lr_d"] else "",
                        angka(b["lr_k"]) if b["lr_k"] else "",
                        angka(b["neraca_d"]) if b["neraca_d"] else "",
                        angka(b["neraca_k"]) if b["neraca_k"] else ""))

        self.tabel_lajur.insert(
            "", "end", tags=("total",),
            values=("", "TOTAL",
                    angka(lajur["ns_d"]), angka(lajur["ns_k"]),
                    angka(lajur["pen_d"]), angka(lajur["pen_k"]),
                    angka(lajur["nssd_d"]), angka(lajur["nssd_k"]),
                    angka(lajur["lr_d"]), angka(lajur["lr_k"]),
                    angka(lajur["neraca_d"]), angka(lajur["neraca_k"])))

        seimbang = (lajur["nssd_d"] == lajur["nssd_k"]
                    and lajur["lr_d"] == lajur["lr_k"]
                    and lajur["neraca_d"] == lajur["neraca_k"])
        self.laba.configure(
            text=f"Laba bersih {rupiah(lajur['laba_bersih'])} — "
                 + ("semua kolom seimbang." if seimbang else "ADA YANG TIDAK SEIMBANG."),
            fg=HIJAU if seimbang else MERAH)


# ------------------------------------------------------------
# 11b. HALAMAN ARUS KAS
# ------------------------------------------------------------
class HalamanArusKas(Halaman):
    """Laporan arus kas metode langsung (rancangan bagian 9D)."""

    def __init__(self, induk, aplikasi):
        super().__init__(induk, aplikasi, "Arus Kas")

        luar, isi = kartu(self.isi, "Laporan arus kas (metode langsung)")
        luar.pack(fill="both", expand=True)

        self.teks = tk.Text(isi, wrap="word", font=("DejaVu Sans Mono", 9),
                            bg=LATAR_KARTU, fg=TEKS, relief="flat",
                            padx=16, pady=12)
        gulir = ttk.Scrollbar(isi, orient="vertical", command=self.teks.yview)
        self.teks.configure(yscrollcommand=gulir.set)
        self.teks.pack(side="left", fill="both", expand=True)
        gulir.pack(side="right", fill="y")
        self.teks.tag_configure("judul", font=("DejaVu Sans", 11, "bold"))
        self.teks.tag_configure("total", font=("DejaVu Sans Mono", 9, "bold"))

        self.muat()

    def tulis(self, teks, tag=None):
        self.teks.insert("end", teks, tag or ())

    def baris(self, kiri, kanan, tag=None):
        self.tulis(f"{kiri:<46}{kanan:>16}\n", tag)

    def muat(self):
        self.teks.configure(state="normal")
        self.teks.delete("1.0", "end")

        kas = hitung.arus_kas()
        self.tulis("LAPORAN ARUS KAS (METODE LANGSUNG)\n", "judul")
        self.tulis("=" * 62 + "\n\n")

        self.tulis("ARUS KAS DARI KEGIATAN OPERASI\n", "total")
        self.baris("Penerimaan dari penjualan",
                   angka(kas["penerimaan_penjualan"]))
        self.baris("Pembelian bibit", f"({angka(kas['pembelian_bibit'])})")
        self.baris("Pembelian pakan", f"({angka(kas['pembelian_pakan'])})")
        self.baris("Beban operasional",
                   f"({angka(kas['beban_operasional'])})")
        if kas["lain"]:
            self.baris("Arus kas lain", akun(kas["lain"]))
        self.baris("Arus kas bersih dari operasi",
                   angka(kas["arus_operasi"]), "total")

        self.tulis("\nARUS KAS DARI KEGIATAN PENDANAAN\n", "total")
        self.baris("Setoran modal", angka(kas["setoran_modal"]))
        self.baris("Prive", f"({angka(kas['prive'])})")

        self.tulis("\n")
        self.baris("Kenaikan kas bersih", angka(kas["kenaikan"]), "total")
        self.baris("Saldo kas awal", angka(kas["saldo_awal"]))
        self.baris("SALDO KAS AKHIR", angka(kas["saldo_akhir"]), "total")


# ------------------------------------------------------------
# 12. HALAMAN DATA MASTER
# ------------------------------------------------------------
class HalamanData(Halaman):
    def __init__(self, induk, aplikasi):
        super().__init__(induk, aplikasi, "Data Master")

        tab = ttk.Notebook(self.isi)
        tab.pack(fill="both", expand=True)

        # Menyimpan id baris yang sedang dipilih pada setiap tab.
        self.id_barang = None
        self.id_pelanggan = None
        self.id_pemasok = None
        self.id_akun = None
        self.id_kolam = None
        self.id_anggota = None

        # ---------- barang ----------
        halaman = ttk.Frame(tab, padding=10)
        tab.add(halaman, text="Barang")

        bingkai, self.tabel_barang = tabel(
            halaman,
            ("Kode", "Nama", "Ukuran", "Stok", "HPP", "Harga acuan", "Minimum", "Berat"),
            (80, 190, 70, 80, 90, 100, 80, 70), tinggi=7)
        bingkai.pack(fill="both", expand=True)
        self.tabel_barang.bind("<<TreeviewSelect>>",
                               lambda e: self.pilih_barang())

        luar = tk.Frame(halaman, bg=LATAR_KARTU, highlightbackground=GARIS,
                        highlightthickness=1)
        luar.pack(fill="x", pady=(10, 0))
        isi = tk.Frame(luar, bg=LATAR_KARTU)
        isi.pack(fill="x", padx=10, pady=10)

        tk.Label(isi, text="Tambah / ubah barang", bg=LATAR_KARTU, fg=TEKS,
                 font=("DejaVu Sans", 9, "bold")).grid(
            row=0, column=0, columnspan=5, sticky="w", pady=(0, 6))

        self.b_kode = self._isian(isi, "Kode", 0, lebar=10, baris=1)
        self.b_nama = self._isian(isi, "Nama", 1, lebar=20, baris=1)
        self.b_satuan = self._pilihan(
            isi, "Satuan", 2, [("ekor", "ekor"), ("kg", "kg")], baris=1)
        self.b_ukuran = self._isian(isi, "Ukuran (cm)", 3, lebar=8, baris=1)

        self.b_hpp = self._isian(isi, "HPP awal", 0, lebar=10, baris=2)
        self.b_jual = self._isian(isi, "Harga acuan", 1, lebar=10, baris=2)
        self.b_min = self._isian(isi, "Stok minimum", 2, lebar=8, baris=2)
        self.b_berat = self._isian(isi, "Berat/satuan (kg)", 3, lebar=8, baris=2)
        self.b_kolam = self._pilihan(
            isi, "Kolam", 0,
            [("-", None)] + [(k["kode"], k["id"]) for k in hitung.daftar_kolam()],
            baris=3)

        self.tombol_barang = self._tombol_crud(isi, 8, self.tambah_barang,
                                               self.ubah_barang, self.hapus_barang,
                                               self.bersihkan_barang)

        # ---------- pelanggan ----------
        halaman = ttk.Frame(tab, padding=10)
        tab.add(halaman, text="Pelanggan")

        bingkai, self.tabel_pelanggan = tabel(
            halaman, ("Kode", "Nama", "Jenis"), (90, 320, 160), tinggi=9)
        bingkai.pack(fill="both", expand=True)
        self.tabel_pelanggan.bind("<<TreeviewSelect>>",
                                  lambda e: self.pilih_pelanggan())

        luar = tk.Frame(halaman, bg=LATAR_KARTU, highlightbackground=GARIS,
                        highlightthickness=1)
        luar.pack(fill="x", pady=(10, 0))
        isi = tk.Frame(luar, bg=LATAR_KARTU)
        isi.pack(fill="x", padx=10, pady=10)

        tk.Label(isi, text="Tambah / ubah pelanggan", bg=LATAR_KARTU, fg=TEKS,
                 font=("DejaVu Sans", 9, "bold")).grid(
            row=0, column=0, columnspan=3, sticky="w", pady=(0, 6))

        self.p_nama = self._isian(isi, "Nama pelanggan", 0, lebar=28, baris=1)
        self.p_jenis = self._isian(isi, "Jenis", 1, lebar=16, baris=1)
        self.p_jenis.insert(0, "Customer")

        self._tombol_crud(isi, 4, self.tambah_pelanggan, self.ubah_pelanggan,
                          self.hapus_pelanggan, self.bersihkan_pelanggan)

        # ---------- pemasok ----------
        halaman = ttk.Frame(tab, padding=10)
        tab.add(halaman, text="Pemasok")

        bingkai, self.tabel_pemasok = tabel(
            halaman, ("Kode", "Nama", "Jenis"), (90, 320, 160), tinggi=9)
        bingkai.pack(fill="both", expand=True)
        self.tabel_pemasok.bind("<<TreeviewSelect>>",
                                lambda e: self.pilih_pemasok())

        luar = tk.Frame(halaman, bg=LATAR_KARTU, highlightbackground=GARIS,
                        highlightthickness=1)
        luar.pack(fill="x", pady=(10, 0))
        isi = tk.Frame(luar, bg=LATAR_KARTU)
        isi.pack(fill="x", padx=10, pady=10)

        tk.Label(isi, text="Tambah / ubah pemasok", bg=LATAR_KARTU, fg=TEKS,
                 font=("DejaVu Sans", 9, "bold")).grid(
            row=0, column=0, columnspan=3, sticky="w", pady=(0, 6))

        self.m_nama = self._isian(isi, "Nama pemasok", 0, lebar=28, baris=1)
        self.m_jenis = self._isian(isi, "Jenis", 1, lebar=16, baris=1)
        self.m_jenis.insert(0, "Supplier")

        self._tombol_crud(isi, 4, self.tambah_pemasok, self.ubah_pemasok,
                          self.hapus_pemasok, self.bersihkan_pemasok)

        # ---------- akun ----------
        halaman = ttk.Frame(tab, padding=10)
        tab.add(halaman, text="Akun")

        bingkai, self.tabel_akun = tabel(
            halaman, ("No", "Nama akun", "Kelompok", "Saldo normal", "Keterangan"),
            (80, 240, 140, 110, 240), tinggi=10)
        bingkai.pack(fill="both", expand=True)
        self.tabel_akun.bind("<<TreeviewSelect>>", lambda e: self.pilih_akun())

        luar = tk.Frame(halaman, bg=LATAR_KARTU, highlightbackground=GARIS,
                        highlightthickness=1)
        luar.pack(fill="x", pady=(10, 0))
        isi = tk.Frame(luar, bg=LATAR_KARTU)
        isi.pack(fill="x", padx=10, pady=10)

        tk.Label(isi, text="Tambah / ubah akun", bg=LATAR_KARTU, fg=TEKS,
                 font=("DejaVu Sans", 9, "bold")).grid(
            row=0, column=0, columnspan=4, sticky="w", pady=(0, 6))

        self.a_no = self._isian(isi, "No akun", 0, lebar=10, baris=1)
        self.a_nama = self._isian(isi, "Nama akun", 1, lebar=26, baris=1)
        self.a_kelompok = self._pilihan(
            isi, "Kelompok", 2,
            [(k, k) for k in ("Aset Lancar", "Aset Tetap", "Kewajiban",
                              "Ekuitas", "Pendapatan", "HPP", "Beban")],
            baris=1)
        self.a_saldo = self._pilihan(
            isi, "Saldo normal", 3,
            [("Debit", "Debit"), ("Kredit", "Kredit")], baris=1)
        self.a_ket = self._isian(isi, "Keterangan", 4, lebar=30, baris=1)

        self._tombol_crud(isi, 4, self.tambah_akun, self.ubah_akun,
                          self.hapus_akun, self.bersihkan_akun)

        # ---------- kolam ----------
        halaman = ttk.Frame(tab, padding=10)
        tab.add(halaman, text="Kolam")

        bingkai, self.tabel_kolam = tabel(
            halaman, ("Kode", "Ukuran", "Penanggung jawab", "Jenis ikan"),
            (90, 100, 220, 140), tinggi=8)
        bingkai.pack(fill="both", expand=True)
        self.tabel_kolam.bind("<<TreeviewSelect>>",
                              lambda e: self.pilih_kolam())

        luar = tk.Frame(halaman, bg=LATAR_KARTU, highlightbackground=GARIS,
                        highlightthickness=1)
        luar.pack(fill="x", pady=(10, 0))
        isi = tk.Frame(luar, bg=LATAR_KARTU)
        isi.pack(fill="x", padx=10, pady=10)

        tk.Label(isi, text="Tambah / ubah kolam", bg=LATAR_KARTU, fg=TEKS,
                 font=("DejaVu Sans", 9, "bold")).grid(
            row=0, column=0, columnspan=4, sticky="w", pady=(0, 6))

        self.k_kode = self._isian(isi, "Kode", 0, lebar=10, baris=1)
        self.k_ukuran = self._isian(isi, "Ukuran", 1, lebar=14, baris=1)
        self.k_anggota = self._pilihan(
            isi, "Penanggung jawab", 2,
            [(a["nama"], a["id"]) for a in hitung.daftar_anggota()], baris=1)
        self.k_anggota.configure(width=22)
        self.k_jenis = self._isian(isi, "Jenis ikan", 3, lebar=14, baris=1)
        self.k_jenis.insert(0, "Kohaku")

        self._tombol_crud(isi, 4, self.tambah_kolam, self.ubah_kolam,
                          self.hapus_kolam, self.bersihkan_kolam)

        # ---------- anggota ----------
        halaman = ttk.Frame(tab, padding=10)
        tab.add(halaman, text="Anggota")

        bingkai, self.tabel_anggota = tabel(
            halaman, ("Kode", "Nama", "Kontak"), (90, 260, 220), tinggi=9)
        bingkai.pack(fill="both", expand=True)
        self.tabel_anggota.bind("<<TreeviewSelect>>",
                                lambda e: self.pilih_anggota())

        luar = tk.Frame(halaman, bg=LATAR_KARTU, highlightbackground=GARIS,
                        highlightthickness=1)
        luar.pack(fill="x", pady=(10, 0))
        isi = tk.Frame(luar, bg=LATAR_KARTU)
        isi.pack(fill="x", padx=10, pady=10)

        tk.Label(isi, text="Tambah / ubah anggota", bg=LATAR_KARTU, fg=TEKS,
                 font=("DejaVu Sans", 9, "bold")).grid(
            row=0, column=0, columnspan=4, sticky="w", pady=(0, 6))

        self.g_kode = self._isian(isi, "Kode", 0, lebar=10, baris=1)
        self.g_nama = self._isian(isi, "Nama", 1, lebar=24, baris=1)
        self.g_kontak = self._isian(isi, "Kontak", 2, lebar=20, baris=1)

        self._tombol_crud(isi, 4, self.tambah_anggota, self.ubah_anggota,
                          self.hapus_anggota, self.bersihkan_anggota)

        # ---------- kebijakan ----------
        halaman = ttk.Frame(tab, padding=10)
        tab.add(halaman, text="Kebijakan")

        bingkai, self.tabel_kebijakan = tabel(
            halaman, ("Kunci", "Nilai", "Keterangan"), (200, 180, 300),
            tinggi=8)
        bingkai.pack(fill="both", expand=True)
        self.tabel_kebijakan.bind("<<TreeviewSelect>>",
                                  lambda e: self.pilih_kebijakan())

        luar = tk.Frame(halaman, bg=LATAR_KARTU, highlightbackground=GARIS,
                        highlightthickness=1)
        luar.pack(fill="x", pady=(10, 0))
        isi = tk.Frame(luar, bg=LATAR_KARTU)
        isi.pack(fill="x", padx=10, pady=10)

        tk.Label(isi, text="Ubah kebijakan akuntansi", bg=LATAR_KARTU, fg=TEKS,
                 font=("DejaVu Sans", 9, "bold")).grid(
            row=0, column=0, columnspan=4, sticky="w", pady=(0, 6))

        self.kb_kunci = self._isian(isi, "Kunci", 0, lebar=24, baris=1)
        self.kb_nilai = self._isian(isi, "Nilai", 1, lebar=20, baris=1)
        self.kb_ket = self._isian(isi, "Keterangan", 2, lebar=34, baris=1)
        ttk.Button(isi, text="Simpan",
                   command=self.simpan_kebijakan).grid(
            row=3, column=0, columnspan=4, sticky="w", pady=(10, 0))

        # ---------- ongkir ----------
        halaman = ttk.Frame(tab, padding=10)
        tab.add(halaman, text="Ongkir")

        bingkai, self.tabel_ongkir = tabel(
            halaman, ("Zona", "Tarif", "Keterangan"), (120, 120, 340),
            tinggi=8)
        bingkai.pack(fill="both", expand=True)
        self.tabel_ongkir.bind("<<TreeviewSelect>>",
                               lambda e: self.pilih_ongkir())

        luar = tk.Frame(halaman, bg=LATAR_KARTU, highlightbackground=GARIS,
                        highlightthickness=1)
        luar.pack(fill="x", pady=(10, 0))
        isi = tk.Frame(luar, bg=LATAR_KARTU)
        isi.pack(fill="x", padx=10, pady=10)

        tk.Label(isi, text="Ubah tarif ongkir", bg=LATAR_KARTU, fg=TEKS,
                 font=("DejaVu Sans", 9, "bold")).grid(
            row=0, column=0, columnspan=4, sticky="w", pady=(0, 6))

        self.o_zona = self._isian(isi, "Zona", 0, lebar=16, baris=1)
        self.o_tarif = self._isian(isi, "Tarif (Rp)", 1, lebar=14, baris=1)
        self.o_ket = self._isian(isi, "Keterangan", 2, lebar=34, baris=1)
        ttk.Button(isi, text="Simpan",
                   command=self.simpan_ongkir).grid(
            row=3, column=0, columnspan=4, sticky="w", pady=(10, 0))

        self.muat()

    def _tombol_crud(self, induk, baris, tambah, ubah, hapus, bersihkan):
        """Deretan tombol Create / Update / Delete / bersihkan."""
        bingkai = tk.Frame(induk, bg=LATAR_KARTU)
        bingkai.grid(row=baris, column=0, columnspan=5, sticky="w", pady=(10, 0))
        ttk.Button(bingkai, text="Tambah",
                   command=tambah).pack(side="left")
        ttk.Button(bingkai, text="Simpan perubahan",
                   command=ubah).pack(side="left", padx=(8, 0))
        ttk.Button(bingkai, text="Hapus",
                   command=hapus).pack(side="left", padx=(8, 0))
        ttk.Button(bingkai, text="Bersihkan",
                   command=bersihkan).pack(side="left", padx=(8, 0))
        return bingkai

    def muat(self):
        kosongkan(self.tabel_barang)
        for b in hitung.ambil_semua("SELECT * FROM barang ORDER BY kode"):
            sisa = hitung.stok_sekarang(b["id"])
            self.tabel_barang.insert(
                "", "end", iid=str(b["id"]),
                values=(b["kode"], b["nama"],
                        b["ukuran_cm"] or "-", f"{sisa} {b['satuan']}",
                        angka(b["hpp"]),
                        angka(b["harga_jual"]) if b["harga_jual"] else "-",
                        b["stok_minimum"], f"{b['berat']:.2f}"))

        kosongkan(self.tabel_pelanggan)
        for p in hitung.ambil_semua("SELECT * FROM pelanggan ORDER BY kode"):
            self.tabel_pelanggan.insert(
                "", "end", iid=str(p["id"]),
                values=(p["kode"], p["nama"], p["jenis"]))

        kosongkan(self.tabel_pemasok)
        for p in hitung.ambil_semua("SELECT * FROM pemasok ORDER BY kode"):
            self.tabel_pemasok.insert(
                "", "end", iid=str(p["id"]),
                values=(p["kode"], p["nama"], p["jenis"]))

        kosongkan(self.tabel_akun)
        for a in hitung.ambil_semua("SELECT * FROM akun ORDER BY no_akun"):
            self.tabel_akun.insert(
                "", "end", iid=str(a["id"]),
                values=(a["no_akun"], a["nama"], a["kelompok"],
                        a["saldo_normal"], a["keterangan"]))

        kosongkan(self.tabel_kolam)
        for k in hitung.daftar_kolam():
            self.tabel_kolam.insert(
                "", "end", iid=str(k["id"]),
                values=(k["kode"], k["ukuran"], k["nama_anggota"] or "-",
                        k["jenis_ikan"]))

        kosongkan(self.tabel_anggota)
        for g in hitung.daftar_anggota():
            self.tabel_anggota.insert(
                "", "end", iid=str(g["id"]),
                values=(g["kode"], g["nama"], g["kontak"]))

        kosongkan(self.tabel_kebijakan)
        for b in hitung.daftar_kebijakan():
            self.tabel_kebijakan.insert(
                "", "end", iid=b["kunci"],
                values=(b["kunci"], b["nilai"], b["keterangan"]))

        kosongkan(self.tabel_ongkir)
        for b in hitung.daftar_ongkir():
            self.tabel_ongkir.insert(
                "", "end", iid=b["zona"],
                values=(b["zona"], angka(b["tarif"]), b["keterangan"]))

        # Daftar pilihan ikut berubah kalau ada kolam/anggota baru.
        pasangan_kolam = ([("-", None)]
                          + [(k["kode"], k["id"]) for k in hitung.daftar_kolam()])
        self.b_kolam.configure(values=[p[0] for p in pasangan_kolam])
        self.b_kolam.daftar = pasangan_kolam

        pasangan_anggota = [(a["nama"], a["id"])
                            for a in hitung.daftar_anggota()]
        self.k_anggota.configure(values=[p[0] for p in pasangan_anggota])
        self.k_anggota.daftar = pasangan_anggota

    # ---------- barang ----------
    def pilih_barang(self):
        terpilih = self.tabel_barang.selection()
        if not terpilih:
            return

        self.id_barang = int(terpilih[0])
        b = hitung.ambil_satu("SELECT * FROM barang WHERE id = ?", (self.id_barang,))
        if b is None:
            return

        self.kosongkan_isian(self.b_kode, self.b_nama, self.b_ukuran,
                             self.b_hpp, self.b_jual, self.b_min, self.b_berat)
        self.b_kode.insert(0, b["kode"])
        self.b_nama.insert(0, b["nama"])
        self.b_ukuran.insert(0, str(b["ukuran_cm"] or ""))
        self.b_hpp.insert(0, str(b["hpp"]))
        self.b_jual.insert(0, str(b["harga_jual"]))
        self.b_min.insert(0, str(b["stok_minimum"]))
        self.b_berat.insert(0, str(b["berat"]))
        self.pilih_nilai(self.b_satuan, b["satuan"])
        self.pilih_nilai(self.b_kolam, b["kolam_id"])

    def bersihkan_barang(self):
        self.id_barang = None
        self.kosongkan_isian(self.b_kode, self.b_nama, self.b_ukuran,
                             self.b_hpp, self.b_jual, self.b_min, self.b_berat)
        self.pilih_nilai(self.b_satuan, "ekor")
        self.pilih_nilai(self.b_kolam, None)
        for baris in self.tabel_barang.selection():
            self.tabel_barang.selection_remove(baris)

    def _baca_form_barang(self):
        """Membaca dan memeriksa isi formulir barang."""
        kode = teks_dari(self.b_kode)
        nama = teks_dari(self.b_nama)
        if not kode or not nama:
            raise ValueError("Kode dan nama barang harus diisi.")

        satuan = self.nilai_pilihan(self.b_satuan)
        ukuran = bulat_dari(self.b_ukuran)
        if satuan == "ekor" and ukuran <= 0:
            raise ValueError("Ikan harus punya ukuran dalam cm.")

        try:
            berat = float(teks_dari(self.b_berat).replace(",", ".") or 0)
        except ValueError:
            raise ValueError("Berat harus berupa angka, misal 0,05.")

        return {
            "kode": kode, "nama": nama, "satuan": satuan,
            "ukuran_cm": ukuran, "hpp": bulat_dari(self.b_hpp),
            "harga_jual": bulat_dari(self.b_jual),
            "stok_minimum": bulat_dari(self.b_min), "berat": berat,
            "kolam_id": self.nilai_pilihan(self.b_kolam),
        }

    def tambah_barang(self):
        try:
            isi = self._baca_form_barang()
            akun_id = hitung.id_akun(
                AKUN_PERSEDIAAN_PAKAN if isi["satuan"] == "kg"
                else AKUN_PERSEDIAAN_KOI)
            hitung.tambah_barang(
                isi["kode"], isi["nama"], isi["satuan"], isi["ukuran_cm"],
                isi["hpp"], isi["harga_jual"], isi["stok_minimum"],
                isi["berat"], akun_id, isi["kolam_id"])
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return

        self.kabar(f"Barang {isi['nama']} ditambahkan.")
        self.bersihkan_barang()
        self.muat()
        self.aplikasi.segarkan_semua()

    def ubah_barang(self):
        if self.id_barang is None:
            self.kabar("Pilih barang pada tabel yang ingin diubah.", berhasil=False)
            return

        try:
            isi = self._baca_form_barang()
            hitung.ubah_barang(
                self.id_barang, isi["kode"], isi["nama"], isi["satuan"],
                isi["ukuran_cm"], isi["hpp"], isi["harga_jual"],
                isi["stok_minimum"], isi["berat"], isi["kolam_id"])
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return

        self.kabar(f"Barang {isi['nama']} diperbarui.")
        self.bersihkan_barang()
        self.muat()
        self.aplikasi.segarkan_semua()

    def hapus_barang(self):
        if self.id_barang is None:
            self.kabar("Pilih barang pada tabel yang ingin dihapus.", berhasil=False)
            return

        if not messagebox.askyesno("Hapus Barang", "Hapus barang yang dipilih?"):
            return

        try:
            hitung.hapus_barang(self.id_barang)
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return

        self.kabar("Barang dihapus.")
        self.bersihkan_barang()
        self.muat()
        self.aplikasi.segarkan_semua()

    # ---------- pelanggan ----------
    def pilih_pelanggan(self):
        terpilih = self.tabel_pelanggan.selection()
        if not terpilih:
            return
        self.id_pelanggan = int(terpilih[0])
        p = hitung.ambil_satu("SELECT * FROM pelanggan WHERE id = ?",
                              (self.id_pelanggan,))
        if p is None:
            return
        self.p_nama.delete(0, "end")
        self.p_nama.insert(0, p["nama"])
        self.p_jenis.delete(0, "end")
        self.p_jenis.insert(0, p["jenis"])

    def bersihkan_pelanggan(self):
        self.id_pelanggan = None
        self.p_nama.delete(0, "end")
        self.p_jenis.delete(0, "end")
        self.p_jenis.insert(0, "Customer")
        for baris in self.tabel_pelanggan.selection():
            self.tabel_pelanggan.selection_remove(baris)

    def tambah_pelanggan(self):
        nama = teks_dari(self.p_nama)
        if not nama:
            self.kabar("Nama pelanggan harus diisi.", berhasil=False)
            return

        jalan = hitung.jalankan
        kode = hitung.kode_berikut("pelanggan", "C")
        jalan("INSERT INTO pelanggan (kode, nama, jenis) VALUES (?, ?, ?)",
              (kode, nama, teks_dari(self.p_jenis) or "Customer"))

        self.kabar(f"Pelanggan {nama} ditambahkan ({kode}).")
        self.bersihkan_pelanggan()
        self.muat()
        self.aplikasi.segarkan_semua()

    def ubah_pelanggan(self):
        if self.id_pelanggan is None:
            self.kabar("Pilih pelanggan yang ingin diubah.", berhasil=False)
            return
        nama = teks_dari(self.p_nama)
        if not nama:
            self.kabar("Nama pelanggan harus diisi.", berhasil=False)
            return

        hitung.ubah_pelanggan(self.id_pelanggan, nama,
                              teks_dari(self.p_jenis) or "Customer")
        self.kabar(f"Pelanggan {nama} diperbarui.")
        self.bersihkan_pelanggan()
        self.muat()
        self.aplikasi.segarkan_semua()

    def hapus_pelanggan(self):
        if self.id_pelanggan is None:
            self.kabar("Pilih pelanggan yang ingin dihapus.", berhasil=False)
            return
        if not messagebox.askyesno("Hapus Pelanggan",
                                   "Hapus pelanggan yang dipilih?"):
            return
        try:
            hitung.hapus_pelanggan(self.id_pelanggan)
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return
        self.kabar("Pelanggan dihapus.")
        self.bersihkan_pelanggan()
        self.muat()
        self.aplikasi.segarkan_semua()

    # ---------- pemasok ----------
    def pilih_pemasok(self):
        terpilih = self.tabel_pemasok.selection()
        if not terpilih:
            return
        self.id_pemasok = int(terpilih[0])
        p = hitung.ambil_satu("SELECT * FROM pemasok WHERE id = ?",
                              (self.id_pemasok,))
        if p is None:
            return
        self.m_nama.delete(0, "end")
        self.m_nama.insert(0, p["nama"])
        self.m_jenis.delete(0, "end")
        self.m_jenis.insert(0, p["jenis"])

    def bersihkan_pemasok(self):
        self.id_pemasok = None
        self.m_nama.delete(0, "end")
        self.m_jenis.delete(0, "end")
        self.m_jenis.insert(0, "Supplier")
        for baris in self.tabel_pemasok.selection():
            self.tabel_pemasok.selection_remove(baris)

    def tambah_pemasok(self):
        nama = teks_dari(self.m_nama)
        if not nama:
            self.kabar("Nama pemasok harus diisi.", berhasil=False)
            return

        kode = hitung.kode_berikut("pemasok", "S")
        hitung.tambah_pemasok(nama, teks_dari(self.m_jenis) or "Supplier")
        self.kabar(f"Pemasok {nama} ditambahkan ({kode}).")
        self.bersihkan_pemasok()
        self.muat()
        self.aplikasi.segarkan_semua()

    def ubah_pemasok(self):
        if self.id_pemasok is None:
            self.kabar("Pilih pemasok yang ingin diubah.", berhasil=False)
            return
        nama = teks_dari(self.m_nama)
        if not nama:
            self.kabar("Nama pemasok harus diisi.", berhasil=False)
            return

        hitung.ubah_pemasok(self.id_pemasok, nama,
                            teks_dari(self.m_jenis) or "Supplier")
        self.kabar(f"Pemasok {nama} diperbarui.")
        self.bersihkan_pemasok()
        self.muat()
        self.aplikasi.segarkan_semua()

    def hapus_pemasok(self):
        if self.id_pemasok is None:
            self.kabar("Pilih pemasok yang ingin dihapus.", berhasil=False)
            return
        if not messagebox.askyesno("Hapus Pemasok",
                                   "Hapus pemasok yang dipilih?"):
            return
        try:
            hitung.hapus_pemasok(self.id_pemasok)
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return
        self.kabar("Pemasok dihapus.")
        self.bersihkan_pemasok()
        self.muat()
        self.aplikasi.segarkan_semua()

    # ---------- akun ----------
    def pilih_akun(self):
        terpilih = self.tabel_akun.selection()
        if not terpilih:
            return
        self.id_akun = int(terpilih[0])
        a = hitung.ambil_satu("SELECT * FROM akun WHERE id = ?", (self.id_akun,))
        if a is None:
            return
        self.a_no.delete(0, "end")
        self.a_no.insert(0, a["no_akun"])
        self.a_nama.delete(0, "end")
        self.a_nama.insert(0, a["nama"])
        self.pilih_nilai(self.a_kelompok, a["kelompok"])
        self.pilih_nilai(self.a_saldo, a["saldo_normal"])
        self.a_ket.delete(0, "end")
        self.a_ket.insert(0, a["keterangan"])

    def bersihkan_akun(self):
        self.id_akun = None
        self.a_no.delete(0, "end")
        self.a_nama.delete(0, "end")
        self.a_ket.delete(0, "end")
        for baris in self.tabel_akun.selection():
            self.tabel_akun.selection_remove(baris)

    def _baca_form_akun(self):
        no_akun = teks_dari(self.a_no)
        nama = teks_dari(self.a_nama)
        if not no_akun or not nama:
            raise ValueError("Nomor dan nama akun harus diisi.")
        return {
            "no_akun": no_akun, "nama": nama,
            "kelompok": self.nilai_pilihan(self.a_kelompok),
            "saldo_normal": self.nilai_pilihan(self.a_saldo),
            "keterangan": teks_dari(self.a_ket),
        }

    def tambah_akun(self):
        try:
            isi = self._baca_form_akun()
            hitung.tambah_akun(isi["no_akun"], isi["nama"], isi["kelompok"],
                               isi["saldo_normal"], isi["keterangan"])
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return
        self.kabar(f"Akun {isi['no_akun']} {isi['nama']} ditambahkan.")
        self.bersihkan_akun()
        self.muat()
        self.aplikasi.segarkan_semua()

    def ubah_akun(self):
        if self.id_akun is None:
            self.kabar("Pilih akun yang ingin diubah.", berhasil=False)
            return
        try:
            isi = self._baca_form_akun()
            hitung.ubah_akun(self.id_akun, isi["no_akun"], isi["nama"],
                             isi["kelompok"], isi["saldo_normal"],
                             isi["keterangan"])
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return
        self.kabar(f"Akun {isi['no_akun']} diperbarui.")
        self.bersihkan_akun()
        self.muat()
        self.aplikasi.segarkan_semua()

    def hapus_akun(self):
        if self.id_akun is None:
            self.kabar("Pilih akun yang ingin dihapus.", berhasil=False)
            return
        if not messagebox.askyesno("Hapus Akun", "Hapus akun yang dipilih?"):
            return
        try:
            hitung.hapus_akun(self.id_akun)
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return
        self.kabar("Akun dihapus.")
        self.bersihkan_akun()
        self.muat()
        self.aplikasi.segarkan_semua()

    # ---------- kolam ----------
    def pilih_kolam(self):
        terpilih = self.tabel_kolam.selection()
        if not terpilih:
            return
        self.id_kolam = int(terpilih[0])
        k = hitung.ambil_satu("SELECT * FROM kolam WHERE id = ?",
                              (self.id_kolam,))
        if k is None:
            return
        self.kosongkan_isian(self.k_kode, self.k_ukuran, self.k_jenis)
        self.k_kode.insert(0, k["kode"])
        self.k_ukuran.insert(0, k["ukuran"])
        self.k_jenis.insert(0, k["jenis_ikan"])
        self.pilih_nilai(self.k_anggota, k["anggota_id"])

    def bersihkan_kolam(self):
        self.id_kolam = None
        self.kosongkan_isian(self.k_kode, self.k_ukuran, self.k_jenis)
        self.k_jenis.insert(0, "Kohaku")
        for baris in self.tabel_kolam.selection():
            self.tabel_kolam.selection_remove(baris)

    def _baca_form_kolam(self):
        kode = teks_dari(self.k_kode)
        ukuran = teks_dari(self.k_ukuran)
        if not kode or not ukuran:
            raise ValueError("Kode dan ukuran kolam harus diisi.")
        return (kode, ukuran, self.nilai_pilihan(self.k_anggota),
                teks_dari(self.k_jenis) or "Kohaku")

    def tambah_kolam(self):
        try:
            kode, ukuran, anggota_id, jenis = self._baca_form_kolam()
            hitung.tambah_kolam(kode, ukuran, anggota_id, jenis)
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return
        self.kabar(f"Kolam {kode} ditambahkan.")
        self.bersihkan_kolam()
        self.muat()

    def ubah_kolam(self):
        if self.id_kolam is None:
            self.kabar("Pilih kolam yang ingin diubah.", berhasil=False)
            return
        try:
            kode, ukuran, anggota_id, jenis = self._baca_form_kolam()
            hitung.ubah_kolam(self.id_kolam, kode, ukuran, anggota_id, jenis)
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return
        self.kabar(f"Kolam {kode} diperbarui.")
        self.bersihkan_kolam()
        self.muat()

    def hapus_kolam(self):
        if self.id_kolam is None:
            self.kabar("Pilih kolam yang ingin dihapus.", berhasil=False)
            return
        if not messagebox.askyesno("Hapus Kolam", "Hapus kolam yang dipilih?"):
            return
        try:
            hitung.hapus_kolam(self.id_kolam)
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return
        self.kabar("Kolam dihapus.")
        self.bersihkan_kolam()
        self.muat()

    # ---------- anggota ----------
    def pilih_anggota(self):
        terpilih = self.tabel_anggota.selection()
        if not terpilih:
            return
        self.id_anggota = int(terpilih[0])
        g = hitung.ambil_satu("SELECT * FROM anggota WHERE id = ?",
                              (self.id_anggota,))
        if g is None:
            return
        self.kosongkan_isian(self.g_kode, self.g_nama, self.g_kontak)
        self.g_kode.insert(0, g["kode"])
        self.g_nama.insert(0, g["nama"])
        self.g_kontak.insert(0, g["kontak"])

    def bersihkan_anggota(self):
        self.id_anggota = None
        self.kosongkan_isian(self.g_kode, self.g_nama, self.g_kontak)
        for baris in self.tabel_anggota.selection():
            self.tabel_anggota.selection_remove(baris)

    def _baca_form_anggota(self):
        kode = teks_dari(self.g_kode)
        nama = teks_dari(self.g_nama)
        if not kode or not nama:
            raise ValueError("Kode dan nama anggota harus diisi.")
        return kode, nama, teks_dari(self.g_kontak)

    def tambah_anggota(self):
        try:
            kode, nama, kontak = self._baca_form_anggota()
            hitung.tambah_anggota(kode, nama, kontak)
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return
        self.kabar(f"Anggota {nama} ditambahkan.")
        self.bersihkan_anggota()
        self.muat()

    def ubah_anggota(self):
        if self.id_anggota is None:
            self.kabar("Pilih anggota yang ingin diubah.", berhasil=False)
            return
        try:
            kode, nama, kontak = self._baca_form_anggota()
            hitung.ubah_anggota(self.id_anggota, kode, nama, kontak)
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return
        self.kabar(f"Anggota {nama} diperbarui.")
        self.bersihkan_anggota()
        self.muat()

    def hapus_anggota(self):
        if self.id_anggota is None:
            self.kabar("Pilih anggota yang ingin dihapus.", berhasil=False)
            return
        if not messagebox.askyesno("Hapus Anggota",
                                   "Hapus anggota yang dipilih?"):
            return
        try:
            hitung.hapus_anggota(self.id_anggota)
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return
        self.kabar("Anggota dihapus.")
        self.bersihkan_anggota()
        self.muat()

    # ---------- kebijakan ----------
    def pilih_kebijakan(self):
        terpilih = self.tabel_kebijakan.selection()
        if not terpilih:
            return
        b = hitung.ambil_satu(
            "SELECT * FROM kebijakan WHERE kunci = ?", (terpilih[0],))
        if b is None:
            return
        self.kosongkan_isian(self.kb_kunci, self.kb_nilai, self.kb_ket)
        self.kb_kunci.insert(0, b["kunci"])
        self.kb_nilai.insert(0, b["nilai"])
        self.kb_ket.insert(0, b["keterangan"])

    def simpan_kebijakan(self):
        kunci = teks_dari(self.kb_kunci)
        if not kunci:
            self.kabar("Kunci kebijakan harus diisi.", berhasil=False)
            return
        hitung.simpan_kebijakan(kunci, teks_dari(self.kb_nilai),
                                teks_dari(self.kb_ket))
        self.kabar(f"Kebijakan {kunci} disimpan.")
        self.kosongkan_isian(self.kb_kunci, self.kb_nilai, self.kb_ket)
        self.muat()

    # ---------- ongkir ----------
    def pilih_ongkir(self):
        terpilih = self.tabel_ongkir.selection()
        if not terpilih:
            return
        b = hitung.ambil_satu(
            "SELECT * FROM ongkir_zona WHERE zona = ?", (terpilih[0],))
        if b is None:
            return
        self.kosongkan_isian(self.o_zona, self.o_tarif, self.o_ket)
        self.o_zona.insert(0, b["zona"])
        self.o_tarif.insert(0, str(b["tarif"]))
        self.o_ket.insert(0, b["keterangan"])

    def simpan_ongkir(self):
        zona = teks_dari(self.o_zona)
        if not zona:
            self.kabar("Zona ongkir harus diisi.", berhasil=False)
            return
        try:
            hitung.simpan_ongkir(zona, bulat_dari(self.o_tarif),
                                 teks_dari(self.o_ket))
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return
        self.kabar(f"Tarif zona {zona} disimpan.")
        self.kosongkan_isian(self.o_zona, self.o_tarif, self.o_ket)
        self.muat()


# ------------------------------------------------------------
# 13. HALAMAN PENGGUNA (khusus Owner)
# ------------------------------------------------------------
class HalamanPengguna(Halaman):
    """Mengelola akun Owner/Karyawan dan menampilkan jejak login."""

    def __init__(self, induk, aplikasi):
        super().__init__(induk, aplikasi, "Pengguna")
        self.id_pengguna = None

        bingkai, self.tabel_pengguna = tabel(
            self.isi, ("Nama", "Jabatan", "Aktif"), (240, 140, 80), tinggi=6)
        bingkai.pack(fill="both", expand=True)
        self.tabel_pengguna.bind("<<TreeviewSelect>>",
                                 lambda e: self.pilih_pengguna())

        luar, isi = kartu(self.isi, "Tambah / ubah pengguna")
        luar.pack(fill="x", pady=(10, 0))

        self.u_nama = self._isian(isi, "Nama", 0, lebar=24, baris=1)
        self.u_jabatan = self._pilihan(
            isi, "Jabatan", 1,
            [("Owner", "Owner"), ("Karyawan", "Karyawan")], baris=1)
        self.u_pin = self._isian(isi, "PIN (kosongkan bila tetap)", 2, lebar=16,
                                 baris=1)
        self.u_pin.configure(show="*")

        bingkai_tombol = tk.Frame(isi, bg=LATAR_KARTU)
        bingkai_tombol.grid(row=3, column=0, columnspan=3, sticky="w",
                            pady=(10, 0))
        ttk.Button(bingkai_tombol, text="Tambah",
                   command=self.tambah).pack(side="left")
        ttk.Button(bingkai_tombol, text="Simpan perubahan",
                   command=self.ubah).pack(side="left", padx=(8, 0))
        ttk.Button(bingkai_tombol, text="Hapus",
                   command=self.hapus).pack(side="left", padx=(8, 0))
        ttk.Button(bingkai_tombol, text="Bersihkan",
                   command=self.bersihkan).pack(side="left", padx=(8, 0))

        luar_log, _ = kartu(self.isi, "Jejak login terakhir")
        luar_log.pack(fill="both", expand=True, pady=(10, 0))
        isi_log = luar_log.winfo_children()[-1]
        bingkai, self.tabel_login = tabel(
            isi_log, ("Nama", "Jabatan", "Waktu"), (200, 120, 200), tinggi=4)
        bingkai.pack(fill="both", expand=True)

        self.muat()

    def muat(self):
        kosongkan(self.tabel_pengguna)
        for p in hitung.daftar_pengguna():
            self.tabel_pengguna.insert(
                "", "end", iid=str(p["id"]),
                values=(p["nama"], p["jabatan"],
                        "Ya" if p["aktif"] else "Tidak"))

        kosongkan(self.tabel_login)
        for b in hitung.ambil_semua(
                "SELECT nama, jabatan, waktu FROM login_log "
                "ORDER BY id DESC LIMIT 20"):
            self.tabel_login.insert(
                "", "end", values=(b["nama"], b["jabatan"],
                                   tanggal_rapi(b["waktu"][:10])
                                   + " " + b["waktu"][11:19]))

    def pilih_pengguna(self):
        terpilih = self.tabel_pengguna.selection()
        if not terpilih:
            return
        self.id_pengguna = int(terpilih[0])
        p = hitung.ambil_satu("SELECT * FROM pengguna WHERE id = ?",
                              (self.id_pengguna,))
        if p is None:
            return
        self.kosongkan_isian(self.u_nama, self.u_pin)
        self.u_nama.insert(0, p["nama"])
        self.pilih_nilai(self.u_jabatan, p["jabatan"])

    def bersihkan(self):
        self.id_pengguna = None
        self.kosongkan_isian(self.u_nama, self.u_pin)
        self.pilih_nilai(self.u_jabatan, "Karyawan")
        for baris in self.tabel_pengguna.selection():
            self.tabel_pengguna.selection_remove(baris)

    def _baca_form(self, wajib_pin):
        nama = teks_dari(self.u_nama)
        if not nama:
            raise ValueError("Nama pengguna harus diisi.")
        pin = teks_dari(self.u_pin)
        if wajib_pin and not pin:
            raise ValueError("PIN harus diisi untuk pengguna baru.")
        if pin and (not pin.isdigit() or len(pin) < 4):
            raise ValueError("PIN minimal 4 angka.")
        return nama, self.nilai_pilihan(self.u_jabatan), pin

    def tambah(self):
        try:
            nama, jabatan, pin = self._baca_form(True)
            hitung.tambah_pengguna(nama, jabatan, pin)
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return
        hitung.catat_audit("pengguna", "tambah", None, f"Tambah {nama}",
                           self.aplikasi.sesi["nama"])
        self.kabar(f"Pengguna {nama} ditambahkan.")
        self.bersihkan()
        self.muat()

    def ubah(self):
        if self.id_pengguna is None:
            self.kabar("Pilih pengguna yang ingin diubah.", berhasil=False)
            return
        try:
            nama, jabatan, pin = self._baca_form(False)
            hitung.ubah_pengguna(self.id_pengguna, nama, jabatan,
                                 pin or None)
        except ValueError as galat:
            self.kabar(str(galat), berhasil=False)
            return
        hitung.catat_audit("pengguna", "ubah", self.id_pengguna,
                           f"Ubah {nama}", self.aplikasi.sesi["nama"])
        self.kabar(f"Pengguna {nama} diperbarui.")
        self.bersihkan()
        self.muat()

    def hapus(self):
        if self.id_pengguna is None:
            self.kabar("Pilih pengguna yang ingin dihapus.", berhasil=False)
            return
        if self.id_pengguna == 1:
            self.kabar("Akun Owner utama tidak boleh dihapus.", berhasil=False)
            return
        if not messagebox.askyesno("Hapus Pengguna",
                                   "Hapus pengguna yang dipilih?"):
            return
        hitung.hapus_pengguna(self.id_pengguna)
        hitung.catat_audit("pengguna", "hapus", self.id_pengguna, "Hapus akun",
                           self.aplikasi.sesi["nama"])
        self.kabar("Pengguna dihapus.")
        self.bersihkan()
        self.muat()


# ------------------------------------------------------------
# 14. JENDELA UTAMA
# ------------------------------------------------------------
class Aplikasi(tk.Tk):
    """Jendela utama: menu di kiri, halaman di kanan."""

    def __init__(self):
        super().__init__()

        self.title(JUDUL)
        self.geometry("1180x760")
        self.configure(bg=LATAR)

        self.ikon = muat_logo(64)
        if self.ikon is not None:
            try:
                self.iconphoto(True, self.ikon)
            except tk.TclError:
                pass

        self.sesi = None
        self.wadah = None
        self.menu = None
        self.halaman = {}
        self.tombol = {}

        self.tampilkan_masuk()

    # ---------- jendela masuk ----------
    def tampilkan_masuk(self):
        self.bersihkan()
        JendelaMasuk(self, self).pack(fill="both", expand=True)

    # ---------- jendela utama ----------
    def tampilkan_utama(self):
        self.bersihkan()

        self.menu = tk.Frame(self, bg="#3b3228", width=190)
        self.menu.pack(side="left", fill="y")
        self.menu.pack_propagate(False)

        logo_menu = muat_logo(56)
        if logo_menu is not None:
            tk.Label(self.menu, image=logo_menu, bg="#3b3228").pack(
                anchor="w", padx=18, pady=(18, 4))

        tk.Label(self.menu, text="SiKoi", bg="#3b3228", fg="#f0e6d6",
                 font=("DejaVu Sans", 18, "bold")).pack(
                     anchor="w", padx=18, pady=(0 if logo_menu else 20, 2))
        tk.Label(self.menu, text="Akuntansi budidaya koi", bg="#3b3228",
                 fg="#a89b8a", font=("DejaVu Sans", 8)).pack(anchor="w", padx=18,
                                                             pady=(0, 16))

        self.wadah = tk.Frame(self, bg=LATAR)
        self.wadah.pack(side="right", fill="both", expand=True)

        # Halaman dibuat semua, ditampilkan satu per satu.
        jenis = [
            ("dashboard", "Dashboard", HalamanDashboard, True),
            ("penjualan", "Penjualan", HalamanPenjualan, False),
            ("pembelian", "Pembelian", HalamanPembelian, False),
            ("kas", "Kas", HalamanKas, True),
            ("kas_kecil", "Kas Kecil", HalamanKasKecil, True),
            ("penyesuaian", "Penyesuaian", HalamanPenyesuaian, True),
            ("jurnal", "Jurnal", HalamanJurnal, True),
            ("jurnal_umum", "Jurnal Umum", HalamanJurnalUmum, True),
            ("laporan", "Laporan", HalamanLaporan, True),
            ("lajur", "Neraca Lajur", HalamanNeracaLajur, True),
            ("arus_kas", "Arus Kas", HalamanArusKas, True),
            ("data", "Data Master", HalamanData, True),
            ("pengguna", "Pengguna", HalamanPengguna, True),
        ]

        milik_owner = self.sesi["jabatan"] == "Owner"

        for kunci, label, kelas, khusus_owner in jenis:
            if khusus_owner and not milik_owner:
                continue

            halaman = kelas(self.wadah, self)
            self.halaman[kunci] = halaman

            tombol = tk.Button(
                self.menu, text=label, anchor="w", relief="flat", bd=0,
                bg="#3b3228", fg="#e7ddcd", activebackground="#57493a",
                activeforeground="#ffffff", font=FONT,
                padx=18, pady=8, cursor="hand2",
                command=lambda k=kunci: self.buka(k))
            tombol.pack(fill="x")
            self.tombol[kunci] = tombol

        # Pengguna yang sedang masuk.
        kaki = tk.Frame(self.menu, bg="#3b3228")
        kaki.pack(side="bottom", fill="x", pady=14)

        tk.Label(kaki, text=self.sesi["nama"], bg="#3b3228", fg="#f0e6d6",
                 font=FONT_KECIL).pack(anchor="w", padx=18)
        tk.Label(kaki, text=self.sesi["jabatan"], bg="#3b3228", fg="#a89b8a",
                 font=("DejaVu Sans", 8)).pack(anchor="w", padx=18)

        tk.Button(kaki, text="Keluar", anchor="w", relief="flat", bd=0,
                  bg="#3b3228", fg="#e0a887", activebackground="#57493a",
                  font=FONT_KECIL, padx=18, pady=4, cursor="hand2",
                  command=self.keluar).pack(fill="x", pady=(8, 0))

        pertama = "dashboard" if milik_owner else "penjualan"
        self.buka(pertama)

    def buka(self, kunci):
        """Menampilkan satu halaman dan menandai menunya."""
        for k, halaman in self.halaman.items():
            halaman.pack_forget()
            self.tombol[k].configure(bg="#3b3228")

        halaman = self.halaman[kunci]
        halaman.pack(fill="both", expand=True)
        self.tombol[kunci].configure(bg="#57493a")

        # Muat ulang supaya angkanya selalu terbaru.
        if hasattr(halaman, "muat"):
            halaman.muat()

    def segarkan_semua(self):
        """Dipanggil setelah menyimpan transaksi."""
        for halaman in self.halaman.values():
            if hasattr(halaman, "muat"):
                halaman.muat()

    def keluar(self):
        self.sesi = None
        self.tampilkan_masuk()

    def bersihkan(self):
        for anak in self.winfo_children():
            anak.destroy()
        self.halaman = {}
        self.tombol = {}


# ------------------------------------------------------------
# 13b. AREA ISI YANG BISA DIGULIR
# ------------------------------------------------------------
def siapkan_gulir(halaman):
    """
    Membuat wadah isi halaman yang bisa digulir.

    Kalau isi lebih tinggi dari jendela (layar kecil, atau taskbar
    Windows memakan ruang), penggulung muncul sendiri. Kalau isinya
    muat, tampilan tetap seperti biasa: isi ditarik memenuhi jendela.
    """
    wadah = ttk.Frame(halaman)
    wadah.pack(fill="both", expand=True)

    kanvas = tk.Canvas(wadah, bg=LATAR, highlightthickness=0, bd=0)
    gulir = ttk.Scrollbar(wadah, orient="vertical", command=kanvas.yview)
    kanvas.configure(yscrollcommand=gulir.set)
    kanvas.pack(side="left", fill="both", expand=True)

    isi = ttk.Frame(kanvas)
    jendela = kanvas.create_window((0, 0), window=isi, anchor="nw")

    halaman.kanvas = kanvas
    halaman.gulir = gulir

    def ukur(_=None):
        """Menghitung daerah gulir dan memunculkan penggulung bila perlu."""
        lebar = kanvas.winfo_width()
        tinggi_layar = kanvas.winfo_height()
        if lebar <= 1 or tinggi_layar <= 1:
            return

        perlu = isi.winfo_reqheight()
        tinggi = max(perlu, tinggi_layar)
        kanvas.itemconfigure(jendela, width=lebar, height=tinggi)
        kanvas.configure(scrollregion=(0, 0, lebar, tinggi))

        if perlu > tinggi_layar + 2:
            if not gulir.winfo_ismapped():
                gulir.pack(side="right", fill="y")
        elif perlu <= tinggi_layar and gulir.winfo_ismapped():
            gulir.pack_forget()
            kanvas.yview_moveto(0)

    def roda(kejadian):
        """Roda mouse menggulir halaman, kecuali di atas tabel atau teks."""
        try:
            if not halaman.winfo_ismapped() or not kanvas.winfo_ismapped():
                return
        except tk.TclError:
            return

        widget = halaman.winfo_containing(kejadian.x_root, kejadian.y_root)
        while widget is not None and widget is not halaman:
            if widget.winfo_class() in ("Treeview", "Text", "Listbox",
                                        "TCombobox", "TScrollbar"):
                return
            widget = widget.master

        nomor = getattr(kejadian, "num", None)
        if nomor == 4:
            langkah = -1
        elif nomor == 5:
            langkah = 1
        else:
            langkah = -1 if getattr(kejadian, "delta", 0) > 0 else 1
        kanvas.yview_scroll(langkah * 3, "units")

    isi.bind("<Configure>", ukur)
    kanvas.bind("<Configure>", ukur)

    for urutan in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
        halaman.bind_all(urutan, roda, add="+")

    return isi


# ------------------------------------------------------------
# 14. MENJALANKAN
# ------------------------------------------------------------
if __name__ == "__main__":
    import os
    import sys

    if not os.path.exists(hitung.NAMA_DATABASE):
        print("Database belum ada.")
        print("Jalankan dua perintah ini lebih dulu:")
        print("    python buat_database.py")
        print("    python isi_contoh.py")
        sys.exit(1)

    # Menambahkan kolom baru kalau database ini dibuat versi lama.
    hitung.pastikan_skema()

    aplikasi = Aplikasi()
    aplikasi.mainloop()
